# Fortis Invicta Solar System — Production Upgrade & Enterprise Architecture Pack

![Version](https://img.shields.io/badge/version-2.5.0--production-emerald)
![Security](https://img.shields.io/badge/security-hardened-blue)
![Database](https://img.shields.io/badge/database-PostgreSQL%2FSupabase-teal)
![Monitoring](https://img.shields.io/badge/monitoring-Sentry%20Tracing-purple)

## Table of Contents
1. [Architecture Overview](#1-architecture-overview)
2. [Authentication & RBAC](#2-authentication--rbac)
3. [Database Schema & Supabase RLS](#3-database-schema--supabase-rls)
4. [Deployment Infrastructure & Cloud Run](#4-deployment-infrastructure--cloud-run)
5. [Security Hardening](#5-security-hardening)
6. [Sentry Observability & Alert Rules](#6-sentry-observability--alert-rules)
7. [Step-by-Step Production Migration Plan](#7-step-by-step-production-migration-plan)

---

## 1. Architecture Overview

The **Fortis Invicta Solar Platform** is an enterprise-grade full-stack solar deployment and fintech management system built for The Gambia and West Africa. It features direct bank transfer & teller upload verification, institutional union integrations (GTUCCU, NAGNMC), engineering site assessments, and client management.

```
                     +---------------------------------------+
                     |          Client Browser / SPA         |
                     |  (React 18 + Vite + Tailwind + Sentry)|
                     +-------------------+-------------------+
                                         |
                                         | HTTPS / WSS
                                         v
                     +---------------------------------------+
                     |         Nginx / Cloud Run Proxy       |
                     |     (SSL / Port 3000 Ingress Routing) |
                     +-------------------+-------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |       Express.js Application Server   |
                     |  - Security Headers (Helmet-grade)    |
                     |  - Strict Rate Limiting (IP/Token)    |
                     |  - Zod Request Body Validation        |
                     |  - JWT Bearer & HTTP-Only Auth        |
                     |  - Gemini AI Resilient Service        |
                     |  - Sentry Backend Tracing Middleware  |
                     +-------------------+-------------------+
                                         |
                       +-----------------+-----------------+
                       |                                   |
                       v                                   v
        +-------------------------------+   +-------------------------------+
        |  PostgreSQL / Supabase Cloud  |   |  Google Gemini 2.5 AI Engine  |
        |  - users, clients, projects   |   |  - System sizing & load audit |
        |  - payments (teller slips)    |   |  - Exponential backoff/retry  |
        |  - Row Level Security (RLS)   |   |  - Structured JSON schema     |
        +-------------------------------+   +-------------------------------+
```

---

## 2. Authentication & RBAC

### Security & Token Strategy
- **Access Tokens**: Short-lived (15 minutes), signed with `HS256` using `JWT_SECRET`.
- **Refresh Tokens**: Long-lived (7 days), signed with `JWT_REFRESH_SECRET`, stored in secure `httpOnly`, `SameSite=Strict`, `secure=true` cookies.
- **Password Hashing**: `bcryptjs` with standard 12 salt rounds.
- **RBAC Roles**:
  - `admin`: Full system control, financial oversight, database administration.
  - `finance_officer`: Verifies bank teller deposits, manages payments, ledger auditing.
  - `project_manager`: Solar installation scheduling, timeline tracking, engineer dispatch.
  - `engineer`: Mobile site assessments, load calculations, commissioning logs.
  - `institutional_admin`: Union member verification (GTUCCU, NAGNMC), credit pre-approvals.
  - `client`: Project dashboard, personal payment history, teller slip uploads.

### Auth API Endpoints
- `POST /api/auth/signup`: Validates input with Zod, checks duplicates, returns JWT pair.
- `POST /api/auth/login`: Authenticates credentials with bcrypt, issues session cookies and bearer tokens.
- `POST /api/auth/refresh`: Verifies refresh token and issues a new access token.
- `POST /api/auth/logout`: Revokes active tokens and clears session cookies.
- `GET /api/auth/me`: Returns authenticated user profile and roles.

---

## 3. Database Schema & Supabase RLS

The database is built on PostgreSQL 15+ / Supabase.

### Core Tables
1. `users`: Master credential and role table.
2. `clients`: Solar prospective and confirmed customers with financial balances.
3. `projects`: Solar installations, capacity specifications, GPS coordinates, and stage.
4. `payments`: Payment transactions supporting `DIRECT_TRANSFER` and `BANK_TELLER` receipt slips with `PENDING_VERIFICATION`, `APPROVED`, and `REJECTED` states.
5. `site_assessments`: Rooftop surveys, azimuth/tilt, daily kWh load audit, and photo arrays.
6. `verification_records`: Institutional GTUCCU/NAGNMC member validation ledger.
7. `audit_logs`: Immutable security action logs.

### Row-Level Security (RLS) Rules
- **Isolation**: Clients can only query and insert records associated with their own `user_id`.
- **Privilege Separation**: Only `admin` and `finance_officer` roles can execute `UPDATE` operations on payment status (`APPROVED`, `REJECTED`).
- **Audit**: Site assessments can only be modified by assigned engineers or administrators.

---

## 4. Deployment Infrastructure & Cloud Run

### Docker Multi-Stage Build
The production `Dockerfile` uses Node.js 22 LTS on Alpine Linux:
- **Stage 1 (Builder)**: Compiles Vite frontend SPA and bundles backend into `dist/server.cjs` via `esbuild`.
- **Stage 2 (Runner)**: Prunes development dependencies, drops root privileges to `nodejs` user (`uid 1001`), configures healthcheck (`/api/health`), and launches on port `3000`.

### Deploying to Google Cloud Run
```bash
# 1. Build and push container
gcloud builds submit --tag gcr.io/[PROJECT_ID]/fortis-invicta-solar:latest

# 2. Deploy to Cloud Run
gcloud run deploy fortis-invicta-solar \
  --image gcr.io/[PROJECT_ID]/fortis-invicta-solar:latest \
  --platform managed \
  --region europe-west2 \
  --allow-unauthenticated \
  --port 3000 \
  --set-env-vars NODE_ENV=production,PORT=3000 \
  --set-secrets JWT_SECRET=fortis-jwt-secret:latest,SUPABASE_URL=supabase-url:latest,SUPABASE_SERVICE_ROLE_KEY=supabase-key:latest
```

---

## 5. Security Hardening

- **CORS Protection**: Explicit allowlist supporting production domain, staging previews, and secure credentials.
- **Rate Limiting**:
  - Auth routes (`/api/auth/*`): 10 attempts per 15 minutes.
  - Institutional verification: 30 requests per 10 minutes.
  - API routes: 300 requests per 15 minutes.
- **HTTP Security Headers**: `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: strict-origin-when-cross-origin`, and Strict CSP.
- **Payload Limits**: JSON body parsing capped at 15MB to prevent memory exhaustion DoS during teller slip uploads.

---

## 6. Sentry Observability & Alert Rules

### Integration
- **Server**: Initialized in `src/server/monitoring.ts` with global `uncaughtException` and `unhandledRejection` hooks.
- **Client**: Initialized in `src/services/sentry.ts` wrapped by `SentryErrorBoundary` component.

### Recommended Sentry Alert Rules
1. **P0 - Authentication Failure Spike**: Alert if `/api/auth/login` returns `401` > 25 times in 5 minutes (Brute-force indicator).
2. **P0 - Database Connection Drop**: Alert immediately on any error from `getSupabaseAdminClient()`.
3. **P1 - Gemini AI Fallback Triggered**: Alert when Gemini API returns 3 consecutive rate-limits or 500 errors.
4. **P1 - Unhandled Client Exception**: Alert if React ErrorBoundary catches > 5 errors in 10 minutes.

---

## 7. Step-by-Step Production Migration Plan

1. **Step 1: Provision Cloud Database**:
   Execute `/src/db/schema.sql` in your Supabase SQL Editor.
2. **Step 2: Set Secrets in Cloud Secret Manager**:
   Add `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `JWT_SECRET`, `JWT_REFRESH_SECRET`, `GEMINI_API_KEY`, and `SENTRY_DSN`.
3. **Step 3: Trigger CI/CD Pipeline**:
   Push to `main` branch to trigger GitHub Actions build, test, and Cloud Run deployment.
4. **Step 4: Execute Sanity Probes**:
   Verify `GET /api/health` returns `status: ok` and `database: supabase-connected`.
