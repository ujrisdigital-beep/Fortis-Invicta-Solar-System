// Fortis Invicta Solar - Offline-First Service Worker
const CACHE_NAME = 'fortis-solar-v2.5.0';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      console.log('[ServiceWorker] Pre-caching offline application shell');
      for (const asset of STATIC_ASSETS) {
        try {
          await cache.add(asset);
        } catch (err) {
          // Individual asset pre-cache fallback
        }
      }
    }).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[ServiceWorker] Clearing legacy cache:', key);
            return caches.delete(key).catch(() => {});
          }
        })
      );
    }).catch(() => {})
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (!request || request.method !== 'GET') {
    return;
  }

  let url;
  try {
    url = new URL(request.url);
  } catch {
    return;
  }

  // Network-first with Cache fallback for HTML and API GETs
  if (request.mode === 'navigate' || url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            try {
              const copy = response.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(request, copy).catch(() => {})).catch(() => {});
            } catch {}
          }
          return response;
        })
        .catch(async () => {
          try {
            const cached = await caches.match(request).catch(() => null);
            if (cached) return cached;
            if (request.mode === 'navigate') {
              const indexCached = await caches.match('/index.html').catch(() => null);
              if (indexCached) return indexCached;
            }
          } catch {}
          return new Response(JSON.stringify({ error: 'Offline mode active', offline: true }), {
            headers: { 'Content-Type': 'application/json' }
          });
        })
    );
    return;
  }

  // Cache-first for static scripts, fonts, and assets
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) return cachedResponse;

      return fetch(request).then((networkResponse) => {
        if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
          return networkResponse;
        }
        try {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, responseToCache).catch(() => {});
          }).catch(() => {});
        } catch {}
        return networkResponse;
      }).catch(() => {
        return new Response('', { status: 408, statusText: 'Request Timeout' });
      });
    }).catch(() => {
      return fetch(request).catch(() => new Response('', { status: 503 }));
    })
  );
});

// Background Sync Event Listener
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-assessments') {
    console.log('[ServiceWorker] Background sync triggered: sync-assessments');
    event.waitUntil(
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          try {
            client.postMessage({ type: 'TRIGGER_BACKGROUND_SYNC' });
          } catch {}
        });
      }).catch(() => {})
    );
  }
});
