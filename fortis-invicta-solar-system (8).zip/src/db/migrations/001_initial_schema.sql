-- =============================================================================
-- FORTIS INVICTA SOLAR ENTERPRISE - BASELINE INITIAL MIGRATION (001)
-- Target: PostgreSQL 15+ / Supabase
-- =============================================================================

-- 0. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. ENUMS & DOMAINS
DO $$ BEGIN
  CREATE TYPE user_role_enum AS ENUM (
    'client',
    'engineer',
    'project_manager',
    'finance_officer',
    'institutional_admin',
    'admin'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE project_stage_enum AS ENUM (
    'LEAD',
    'SITE_SURVEY',
    'PROPOSAL_APPROVED',
    'DEPOSIT_RECEIVED',
    'EQUIPMENT_ALLOCATED',
    'INSTALLATION_IN_PROGRESS',
    'COMMISSIONED',
    'MAINTENANCE'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE payment_status_enum AS ENUM (
    'PENDING',
    'PENDING_VERIFICATION',
    'APPROVED',
    'REJECTED',
    'CONFIRMED',
    'FAILED',
    'REFUNDED'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE payment_method_enum AS ENUM (
    'DIRECT_TRANSFER',
    'BANK_TELLER',
    'ECOBANK_PAY',
    'SALARY_DEDUCTION',
    'CASH_OFFICE'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE deduction_status_enum AS ENUM (
    'NOT_APPLICABLE',
    'PENDING_SUBMISSION',
    'SUBMITTED_TO_UNION',
    'PRE_APPROVED',
    'ACTIVE_DEDUCTION',
    'COMPLETED',
    'DEFAULTED'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE rag_status_enum AS ENUM (
    'GREEN',
    'AMBER',
    'RED'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- 2. CORE TABLES

-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role user_role_enum NOT NULL DEFAULT 'client',
  phone VARCHAR(50),
  institution_id VARCHAR(50),
  institution_name VARCHAR(255),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- CLIENTS TABLE
CREATE TABLE IF NOT EXISTS clients (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  full_name VARCHAR(255) NOT NULL,
  phone VARCHAR(50) NOT NULL,
  email VARCHAR(255),
  address TEXT NOT NULL,
  region VARCHAR(100) NOT NULL,
  institution_id VARCHAR(50),
  institution_member_id VARCHAR(100),
  stage project_stage_enum NOT NULL DEFAULT 'LEAD',
  rag_status rag_status_enum NOT NULL DEFAULT 'GREEN',
  selected_package_id VARCHAR(50) NOT NULL,
  total_contract_gmd NUMERIC(12, 2) NOT NULL CHECK (total_contract_gmd > 0),
  deposit_paid_gmd NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (deposit_paid_gmd >= 0),
  outstanding_gmd NUMERIC(12, 2) NOT NULL CHECK (outstanding_gmd >= 0),
  deduction_status deduction_status_enum NOT NULL DEFAULT 'NOT_APPLICABLE',
  monthly_deduction_gmd NUMERIC(10, 2) CHECK (monthly_deduction_gmd >= 0),
  gdpr_consent BOOLEAN NOT NULL DEFAULT TRUE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- PROJECTS TABLE
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  assigned_engineer_id UUID REFERENCES users(id) ON DELETE SET NULL,
  package_id VARCHAR(50) NOT NULL,
  package_name VARCHAR(255) NOT NULL,
  system_capacity_kva NUMERIC(5, 2) NOT NULL CHECK (system_capacity_kva > 0),
  battery_capacity_kwh NUMERIC(5, 2) NOT NULL CHECK (battery_capacity_kwh > 0),
  stage project_stage_enum NOT NULL DEFAULT 'LEAD',
  installation_date TIMESTAMPTZ,
  commissioning_date TIMESTAMPTZ,
  warranty_years INT NOT NULL DEFAULT 5,
  gps_latitude NUMERIC(9, 6),
  gps_longitude NUMERIC(9, 6),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  amount_gmd NUMERIC(12, 2) NOT NULL CHECK (amount_gmd > 0),
  payment_type VARCHAR(100) NOT NULL,
  payment_method payment_method_enum NOT NULL DEFAULT 'DIRECT_TRANSFER',
  channel VARCHAR(50) NOT NULL DEFAULT 'BANK_TRANSFER',
  status payment_status_enum NOT NULL DEFAULT 'PENDING_VERIFICATION',
  teller_reference_number VARCHAR(100),
  teller_receipt_url TEXT,
  admin_notes TEXT,
  ecobank_merchant_code VARCHAR(50) DEFAULT '505825057',
  ecobank_terminal_id VARCHAR(50) DEFAULT '32680928',
  transaction_ref VARCHAR(100),
  confirmed_at TIMESTAMPTZ,
  confirmed_by VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- MANUAL PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS public.manual_payments (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  client_id UUID NOT NULL,
  amount NUMERIC(12, 2) NOT NULL,
  reference_code TEXT NOT NULL,
  deposit_date DATE NOT NULL DEFAULT CURRENT_DATE,
  proof_url TEXT,
  status TEXT DEFAULT 'PENDING_VERIFICATION',
  payment_method TEXT DEFAULT 'ECOBANK_DIRECT_TRANSFER',
  verified_by UUID,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- FINANCIAL LEDGER TABLE
CREATE TABLE IF NOT EXISTS public.financial_ledger (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  payment_id UUID REFERENCES payments(id) ON DELETE SET NULL,
  entry_type VARCHAR(20) NOT NULL CHECK (entry_type IN ('DEBIT', 'CREDIT', 'ADJUSTMENT', 'REFUND')),
  amount_gmd NUMERIC(12, 2) NOT NULL CHECK (amount_gmd > 0),
  balance_after_gmd NUMERIC(12, 2) NOT NULL CHECK (balance_after_gmd >= 0),
  description TEXT NOT NULL,
  actor_id UUID REFERENCES users(id) ON DELETE SET NULL,
  actor_role VARCHAR(50) NOT NULL DEFAULT 'finance_officer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- EQUIPMENT CATALOGUE TABLE
CREATE TABLE IF NOT EXISTS public.equipment_catalogue (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  manufacturer VARCHAR(100) NOT NULL,
  model VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL CHECK (category IN ('SOLAR_PANEL', 'INVERTER', 'BATTERY', 'MOUNTING', 'ACCESSORY')),
  rated_power_w NUMERIC(8, 2),
  nominal_voltage_v NUMERIC(8, 2),
  capacity_kwh NUMERIC(8, 2),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  datasheet_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- INVENTORY ITEMS TABLE
CREATE TABLE IF NOT EXISTS public.inventory_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  catalogue_id UUID NOT NULL REFERENCES equipment_catalogue(id) ON DELETE CASCADE,
  serial_number VARCHAR(100) UNIQUE NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'IN_STOCK' CHECK (status IN ('IN_STOCK', 'RESERVED', 'ALLOCATED_TO_PROJECT', 'INSTALLED', 'MAINTENANCE', 'DECOMMISSIONED')),
  allocated_project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
  warehouse_location VARCHAR(100) NOT NULL DEFAULT 'Brikama Central Warehouse',
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- COMMISSIONING RECORDS TABLE
CREATE TABLE IF NOT EXISTS public.commissioning_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  engineer_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  voc_measured_v NUMERIC(6, 2) NOT NULL,
  vmp_measured_v NUMERIC(6, 2) NOT NULL,
  inverter_fw_version VARCHAR(50),
  battery_soc_percent NUMERIC(5, 2) NOT NULL,
  earthing_resistance_ohms NUMERIC(6, 2) NOT NULL,
  grid_failover_tested BOOLEAN NOT NULL DEFAULT TRUE,
  customer_accepted BOOLEAN NOT NULL DEFAULT FALSE,
  customer_signature_date TIMESTAMPTZ,
  commissioning_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  notes TEXT
);

-- WARRANTIES TABLE
CREATE TABLE IF NOT EXISTS public.warranties (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  inventory_item_id UUID NOT NULL REFERENCES inventory_items(id) ON DELETE RESTRICT,
  serial_number VARCHAR(100) NOT NULL,
  warranty_start_date DATE NOT NULL,
  warranty_end_date DATE NOT NULL,
  terms TEXT NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'CLAIMED', 'EXPIRED', 'VOIDED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- SERVICE TICKETS TABLE
CREATE TABLE IF NOT EXISTS public.service_tickets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
  assigned_technician_id UUID REFERENCES users(id) ON DELETE SET NULL,
  issue_description TEXT NOT NULL,
  priority VARCHAR(20) NOT NULL DEFAULT 'MEDIUM' CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
  status VARCHAR(30) NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'IN_PROGRESS', 'WAITING_PARTS', 'RESOLVED', 'CLOSED')),
  resolution_notes TEXT,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- SITE ASSESSMENTS TABLE
CREATE TABLE IF NOT EXISTS site_assessments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  assessor_id UUID REFERENCES users(id) ON DELETE SET NULL,
  roof_type VARCHAR(100) NOT NULL,
  roof_azimuth_degrees INT NOT NULL DEFAULT 180 CHECK (roof_azimuth_degrees BETWEEN 0 AND 360),
  tilt_angle_degrees INT NOT NULL DEFAULT 15 CHECK (tilt_angle_degrees BETWEEN 0 AND 90),
  shading_level VARCHAR(50) NOT NULL DEFAULT 'none',
  nawec_grid_stability VARCHAR(100) NOT NULL,
  daily_energy_kwh NUMERIC(6, 2) NOT NULL CHECK (daily_energy_kwh > 0),
  recommended_kva NUMERIC(5, 2) NOT NULL CHECK (recommended_kva > 0),
  recommended_panels INT NOT NULL CHECK (recommended_panels > 0),
  recommended_batteries INT NOT NULL DEFAULT 0 CHECK (recommended_batteries >= 0),
  photos JSONB DEFAULT '[]'::jsonb,
  notes TEXT,
  assessed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- VERIFICATION RECORDS TABLE
CREATE TABLE IF NOT EXISTS verification_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  institution_id VARCHAR(50) NOT NULL,
  member_id VARCHAR(100) NOT NULL,
  member_name VARCHAR(255) NOT NULL,
  is_verified BOOLEAN NOT NULL DEFAULT FALSE,
  max_credit_gmd NUMERIC(12, 2),
  proof_token_hash VARCHAR(255) NOT NULL,
  verified_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  actor_name VARCHAR(255) NOT NULL,
  actor_role VARCHAR(50) NOT NULL,
  action VARCHAR(100) NOT NULL,
  details JSONB NOT NULL,
  ip_address VARCHAR(45),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. INDEXES
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_clients_institution ON clients(institution_id, institution_member_id);
CREATE INDEX IF NOT EXISTS idx_clients_stage ON clients(stage);
CREATE INDEX IF NOT EXISTS idx_clients_rag ON clients(rag_status);
CREATE INDEX IF NOT EXISTS idx_projects_client_id ON projects(client_id);
CREATE INDEX IF NOT EXISTS idx_payments_client_id ON payments(client_id);
CREATE INDEX IF NOT EXISTS idx_payments_txref ON payments(transaction_ref);
CREATE INDEX IF NOT EXISTS idx_assessments_client_id ON site_assessments(client_id);
CREATE INDEX IF NOT EXISTS idx_verifications_member ON verification_records(institution_id, member_id);

-- 4. ROW LEVEL SECURITY
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE manual_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE financial_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE equipment_catalogue ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE commissioning_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE warranties ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE verification_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
