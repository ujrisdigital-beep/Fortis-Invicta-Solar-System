import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { getEnvConfig } from '../server/envConfig.js';

let supabaseClient: SupabaseClient | null = null;
let supabaseAdminClient: SupabaseClient | null = null;

/**
 * Public Anonymous Client (Subject to RLS)
 */
export function getSupabaseClient(): SupabaseClient | null {
  const config = getEnvConfig();
  if (!config.SUPABASE_URL || !config.SUPABASE_ANON_KEY) {
    return null;
  }

  if (!supabaseClient) {
    supabaseClient = createClient(config.SUPABASE_URL, config.SUPABASE_ANON_KEY, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    });
  }

  return supabaseClient;
}

/**
 * Service Role Admin Client (Bypasses RLS for secure backend operations)
 */
export function getSupabaseAdminClient(): SupabaseClient | null {
  const config = getEnvConfig();
  const serviceKey = config.SUPABASE_SERVICE_ROLE_KEY || config.SUPABASE_ANON_KEY;

  if (!config.SUPABASE_URL || !serviceKey) {
    return null;
  }

  if (!supabaseAdminClient) {
    supabaseAdminClient = createClient(config.SUPABASE_URL, serviceKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    });
  }

  return supabaseAdminClient;
}
