import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserRole } from '../types';

export interface AuthUser {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
  institutionId?: string | null;
  phone?: string | null;
  isEmailVerified?: boolean;
}

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string; requiresVerification?: boolean; email?: string }>;
  signup: (data: { email: string; password: string; fullName: string; role?: UserRole; institutionId?: string; phone?: string }) => Promise<{ success: boolean; error?: string; requiresVerification?: boolean; email?: string; verificationCodeDemo?: string }>;
  verifyEmail: (email: string, code: string) => Promise<{ success: boolean; error?: string }>;
  resendVerification: (email: string) => Promise<{ success: boolean; error?: string; verificationCodeDemo?: string }>;
  logout: () => Promise<void>;
  hasRole: (roles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Normalize role string format
function normalizeRole(r: string): UserRole {
  const clean = String(r).toLowerCase().trim();
  if (clean === 'admin' || clean === 'super_admin') return 'super_admin';
  if (clean === 'finance' || clean === 'finance_officer') return 'finance_officer';
  if (clean === 'engineer' || clean === 'site_inspector') return 'site_inspector';
  if (clean === 'installer') return 'installer';
  if (clean === 'project_manager') return 'project_manager';
  if (clean === 'institutional_admin' || clean === 'institutional') return 'institutional_admin';
  return 'client';
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(() => {
    const saved = localStorage.getItem('fortis_auth_user');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...parsed,
          role: normalizeRole(parsed.role)
        };
      } catch {
        return null;
      }
    }
    return null;
  });
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('fortis_auth_token'));
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const verifySession = async () => {
      if (!token) {
        setIsLoading(false);
        return;
      }

      try {
        const res = await fetch('/api/auth/me', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        if (res.ok) {
          const data = await res.json();
          const normUser: AuthUser = {
            ...data.user,
            role: normalizeRole(data.user.role)
          };
          setUser(normUser);
          localStorage.setItem('fortis_auth_user', JSON.stringify(normUser));
        } else {
          // Token expired or invalid
          setUser(null);
          setToken(null);
          localStorage.removeItem('fortis_auth_user');
          localStorage.removeItem('fortis_auth_token');
        }
      } catch (err) {
        console.warn('Session verification error:', err);
      } finally {
        setIsLoading(false);
      }
    };

    verifySession().catch((err) => {
      console.warn('[Auth] verifySession unhandled error caught:', err);
    });
  }, [token]);

  const login = async (email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim().toLowerCase(), password })
      });

      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: data.error || 'Login failed',
          requiresVerification: !!data.requiresVerification,
          email: data.email || email.trim().toLowerCase()
        };
      }

      const normUser: AuthUser = {
        ...data.user,
        role: normalizeRole(data.user.role)
      };

      setUser(normUser);
      setToken(data.accessToken || data.token);
      localStorage.setItem('fortis_auth_user', JSON.stringify(normUser));
      localStorage.setItem('fortis_auth_token', data.accessToken || data.token);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network connection failed' };
    }
  };

  const signup = async (formData: { email: string; password: string; fullName: string; role?: UserRole; institutionId?: string; phone?: string }) => {
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          email: formData.email.trim().toLowerCase()
        })
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Signup failed' };
      }

      if (data.requiresVerification) {
        return {
          success: true,
          requiresVerification: true,
          email: data.email,
          verificationCodeDemo: data.verificationCodeDemo
        };
      }

      if (data.user) {
        const normUser: AuthUser = {
          ...data.user,
          role: normalizeRole(data.user.role)
        };
        setUser(normUser);
        setToken(data.accessToken || data.token);
        localStorage.setItem('fortis_auth_user', JSON.stringify(normUser));
        localStorage.setItem('fortis_auth_token', data.accessToken || data.token);
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network connection failed' };
    }
  };

  const verifyEmail = async (email: string, code: string) => {
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim().toLowerCase(), code: code.trim() })
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Email verification failed' };
      }

      const normUser: AuthUser = {
        ...data.user,
        role: normalizeRole(data.user.role)
      };

      setUser(normUser);
      setToken(data.accessToken || data.token);
      localStorage.setItem('fortis_auth_user', JSON.stringify(normUser));
      localStorage.setItem('fortis_auth_token', data.accessToken || data.token);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Verification connection failed' };
    }
  };

  const resendVerification = async (email: string) => {
    try {
      const res = await fetch('/api/auth/resend-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim().toLowerCase() })
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to resend verification code' };
      }

      return {
        success: true,
        verificationCodeDemo: data.verificationCodeDemo
      };
    } catch (err: any) {
      return { success: false, error: err.message || 'Resend request failed' };
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch (err) {
      console.warn('Logout error:', err);
    }
    setUser(null);
    setToken(null);
    localStorage.removeItem('fortis_auth_user');
    localStorage.removeItem('fortis_auth_token');
  };

  const hasRole = (allowedRoles: UserRole[]) => {
    if (!user) return false;
    return allowedRoles.includes(user.role);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        login,
        signup,
        verifyEmail,
        resendVerification,
        logout,
        hasRole
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
