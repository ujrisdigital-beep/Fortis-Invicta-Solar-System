import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Lazy-initialize Supabase client to prevent startup crashes when keys are absent
let supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  if (supabaseInstance) return supabaseInstance;

  const url = typeof process !== 'undefined' && process.env?.SUPABASE_URL
    ? process.env.SUPABASE_URL
    : (import.meta as any).env?.VITE_SUPABASE_URL;

  const anonKey = typeof process !== 'undefined' && process.env?.SUPABASE_ANON_KEY
    ? process.env.SUPABASE_ANON_KEY
    : (import.meta as any).env?.VITE_SUPABASE_ANON_KEY;

  if (url && anonKey) {
    try {
      supabaseInstance = createClient(url, anonKey);
      return supabaseInstance;
    } catch (err) {
      console.warn('Failed to initialize Supabase client:', err);
      return null;
    }
  }

  return null;
}

export const isSupabaseConfigured = (): boolean => {
  return getSupabaseClient() !== null;
};
