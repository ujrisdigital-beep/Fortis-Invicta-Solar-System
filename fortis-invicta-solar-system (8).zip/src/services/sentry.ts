import * as Sentry from '@sentry/react';

/**
 * Frontend Sentry & Telemetry Client Initializer
 */

interface SentryInitOptions {
  dsn?: string;
  environment?: string;
  release?: string;
  tracesSampleRate?: number;
}

let isFrontendSentryReady = false;
let isListenersAttached = false;

export function initFrontendSentry(options?: SentryInitOptions) {
  const dsn = options?.dsn || (import.meta as any).env?.VITE_SENTRY_DSN;
  const environment = options?.environment || (import.meta as any).env?.MODE || 'production';

  if (dsn && !isFrontendSentryReady) {
    try {
      Sentry.init({
        dsn,
        environment,
        release: 'fortis-invicta-solar-client@2.5.0',
        tracesSampleRate: environment === 'production' ? 0.2 : 1.0,
      });
      console.info(`[Frontend Sentry] Initialized with React SDK in ${environment} environment.`);
      isFrontendSentryReady = true;
    } catch (e: any) {
      console.warn('[Frontend Sentry] Initialization warning:', e?.message);
    }
  } else if (!isFrontendSentryReady) {
    console.info('[Frontend Sentry] Ready with fallback client telemetry.');
  }

  if (isListenersAttached || typeof window === 'undefined') {
    return;
  }
  isListenersAttached = true;

  // Global window error listener
  window.addEventListener('error', (event) => {
    // Suppress benign resize observer or script injection errors in sandbox
    if (
      event.message?.includes('ResizeObserver') ||
      event.message?.includes('Script error') ||
      !event.error
    ) {
      if (typeof event.preventDefault === 'function') event.preventDefault();
      return;
    }

    if (isFrontendSentryReady && event.error) {
      try {
        Sentry.captureException(event.error);
      } catch {
        // Safe fallback
      }
    }
  });

  // Handler for unhandled promise rejections
  const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
    try {
      // Prevent unhandled promise rejections from bubbling up to browser host/iframe console
      if (event && typeof event.preventDefault === 'function') {
        event.preventDefault();
      }
      if (event && typeof (event as any).stopImmediatePropagation === 'function') {
        (event as any).stopImmediatePropagation();
      }
      if (event && typeof (event as any).stopPropagation === 'function') {
        (event as any).stopPropagation();
      }
    } catch {
      // Safe fallback
    }

    if (!event || !event.reason) {
      return true;
    }

    const reasonStr = typeof event.reason === 'string' ? event.reason : event.reason?.message || '';
    if (
      event.reason?.name === 'AbortError' ||
      reasonStr.includes('ResizeObserver') ||
      reasonStr.includes('aborted') ||
      reasonStr.includes('canceled') ||
      reasonStr.includes('Failed to fetch') ||
      reasonStr.includes('ServiceWorker') ||
      reasonStr.includes('service worker') ||
      reasonStr.includes('SecurityError') ||
      reasonStr.includes('IndexedDB') ||
      reasonStr.includes('indexedDB') ||
      reasonStr.includes('denied') ||
      reasonStr.includes('The operation was aborted') ||
      reasonStr.includes('Load failed') ||
      reasonStr.includes('NetworkError')
    ) {
      return true;
    }

    if (isFrontendSentryReady && event.reason instanceof Error) {
      try {
        Sentry.captureException(event.reason);
      } catch {
        // Safe fallback
      }
    }
    return true;
  };

  // Global unhandled promise rejection listeners (capture & bubble & direct)
  window.addEventListener('unhandledrejection', handleUnhandledRejection, true);
  window.addEventListener('unhandledrejection', handleUnhandledRejection, false);
  try {
    (window as any).onunhandledrejection = handleUnhandledRejection;
  } catch {}
}

export function reportClientError(error: Error, componentStack?: string) {
  console.error('[Client Error Boundary Caught Error]:', {
    name: error.name,
    message: error.message,
    stack: error.stack,
    componentStack
  });
  if (isFrontendSentryReady) {
    Sentry.captureException(error, { extra: { componentStack } });
  }
}
