/**
 * Fortis Invicta Central API Orchestrator
 *
 * Direct typed client for live Docker-hosted backend services:
 * - Directus CMS (http://localhost:8055)
 * - ERPNext HR & ERP (http://localhost:8000)
 * - Moodle LMS Academy (http://localhost:8080)
 * - ThingsBoard IoT Telemetry (http://localhost:9090)
 * - Postal Mail Server (http://localhost:5000/api/v1)
 * - OpenSearch Audit & Indexing (http://localhost:9200)
 */

export const ORCHESTRATOR_ENV = {
  DIRECTUS_URL: 'http://localhost:8055',
  DIRECTUS_API_KEY: 'fortis_cms_tok_9f3a8b1c2d4e5f6a7b8c9d0e1f2a3b4c',
  ERPNEXT_URL: 'http://localhost:8000',
  ERPNEXT_API_KEY: 'e4d3c2b1a0987654',
  ERPNEXT_API_SECRET: '9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d',
  MOODLE_URL: 'http://localhost:8080',
  MOODLE_API_KEY: 'a1b2c3d4e5f67890123456789abcdef0',
  THINGSBOARD_URL: 'http://localhost:9090',
  THINGSBOARD_API_TOKEN: 'tb_sec_90812736451029384756102938475612',
  SOLAR_DEVICE_ID: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890',
  POSTAL_API_URL: 'http://localhost:5000/api/v1',
  POSTAL_API_KEY: 'postal-api-key-f8e7d6c5b4a3210987654321fedcba98',
  OPENSEARCH_URL: 'http://localhost:9200'
};

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  serviceUrl?: string;
  statusCode?: number;
}

export interface EmployeeRosterItem {
  name: string;
  employee_name: string;
  designation: string;
  department: string;
  status: string;
  cell_number?: string;
  company_email?: string;
}

export interface DirectusContentItem {
  id: string | number;
  name?: string;
  title?: string;
  description?: string;
  status: string;
  [key: string]: any;
}

export interface ThingsBoardLiveTelemetry {
  deviceId: string;
  timestamp: string;
  pvPowerWatts: number;
  gridVoltageVolts: number;
  batterySocPercent: number;
  batteryVoltageVolts: number;
  loadPowerWatts: number;
  dailyYieldKWh: number;
  inverterStatus: 'normal' | 'warning' | 'fault' | 'offline';
  temperatureCelsius: number;
}

export interface MoodleCertificate {
  installerId: string;
  installerName: string;
  courseName: string;
  certificationStatus: 'certified' | 'in_training' | 'recertification_due';
  completionDate?: string;
  grade?: number;
}

export interface PostalEmailRequest {
  to: string[];
  subject: string;
  htmlBody: string;
  plainBody?: string;
}

export interface OpenSearchAuditRecord {
  id?: string;
  timestamp?: string;
  actorEmail?: string;
  actorRole?: string;
  action: string;
  category: 'AUTH' | 'PAYMENT' | 'AUDIT' | 'ASSESSMENT' | 'SECURITY' | 'COMMISSIONING';
  severity: 'INFO' | 'WARNING' | 'ALERT' | 'CRITICAL';
  details: string;
  metadata?: Record<string, any>;
}

/**
 * Unified Safe Fetch Wrapper for Live Docker Endpoints
 */
async function safeFetch<T>(
  url: string,
  serviceName: string,
  serviceBaseUrl: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const isBrowser = typeof window !== 'undefined';
    let fullUrl = url;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      if (isBrowser) {
        fullUrl = `${window.location.origin}${url.startsWith('/') ? '' : '/'}${url}`;
      } else {
        fullUrl = `http://localhost:3000${url.startsWith('/') ? '' : '/'}${url}`;
      }
    }

    const timeoutSignal =
      typeof AbortSignal !== 'undefined' && typeof AbortSignal.timeout === 'function'
        ? AbortSignal.timeout(5000)
        : undefined;

    const res = await fetch(fullUrl, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...(options.headers || {})
      },
      signal: timeoutSignal
    }).catch(() => null);

    if (!res) {
      return {
        success: false,
        error: `Service Offline: ${serviceName} on ${serviceBaseUrl}`,
        serviceUrl: serviceBaseUrl,
        statusCode: 503
      };
    }

    if (!res.ok) {
      const errorText = await res.text().catch(() => res.statusText);
      return {
        success: false,
        error: `Service Offline: ${serviceName} on ${serviceBaseUrl} (HTTP ${res.status}: ${errorText})`,
        serviceUrl: serviceBaseUrl,
        statusCode: res.status
      };
    }

    const json = await res.json().catch(() => null);
    if (!json) {
      return {
        success: false,
        error: `Invalid response format from ${serviceName}`,
        serviceUrl: serviceBaseUrl,
        statusCode: res.status
      };
    }
    return {
      success: true,
      data: (json.data !== undefined ? json.data : json) as T,
      serviceUrl: serviceBaseUrl,
      statusCode: res.status
    };
  } catch (err: any) {
    return {
      success: false,
      error: `Service Offline: ${serviceName} on ${serviceBaseUrl} (${err.message || 'Connection Refused'})`,
      serviceUrl: serviceBaseUrl,
      statusCode: 503
    };
  }
}

export class ApiOrchestrator {
  /**
   * 1. ERPNEXT: Fetch Staff / Employee Roster (/api/resource/Employee)
   */
  static async fetchStaffRoster(): Promise<ApiResponse<EmployeeRosterItem[]>> {
    // Queries via backend ecosystem proxy or direct ERPNext API
    const proxyUrl = '/api/ecosystem/erpnext/employees';
    const res = await safeFetch<{ source: string; data: EmployeeRosterItem[] } | EmployeeRosterItem[]>(
      proxyUrl,
      'ERPNext HR',
      ORCHESTRATOR_ENV.ERPNEXT_URL
    );

    if (res.success && res.data) {
      const items = Array.isArray(res.data) ? res.data : (res.data as any).data || [];
      return {
        success: true,
        data: items,
        serviceUrl: ORCHESTRATOR_ENV.ERPNEXT_URL
      };
    }
    return {
      success: false,
      error: res.error || `Service Offline: ERPNext on ${ORCHESTRATOR_ENV.ERPNEXT_URL}`,
      serviceUrl: ORCHESTRATOR_ENV.ERPNEXT_URL,
      statusCode: res.statusCode
    };
  }

  /**
   * 2. DIRECTUS CMS: Fetch Published Packages & Documents
   */
  static async fetchDirectusContent(collection = 'solar_packages'): Promise<ApiResponse<DirectusContentItem[]>> {
    const proxyUrl = collection === 'solar_packages' 
      ? '/api/ecosystem/directus/packages'
      : '/api/ecosystem/directus/articles';

    const res = await safeFetch<any>(
      proxyUrl,
      'Directus CMS',
      ORCHESTRATOR_ENV.DIRECTUS_URL
    );

    if (res.success && res.data) {
      const dataArray = Array.isArray(res.data) ? res.data : (res.data.data || []);
      return {
        success: true,
        data: dataArray,
        serviceUrl: ORCHESTRATOR_ENV.DIRECTUS_URL
      };
    }

    return {
      success: false,
      error: res.error || `Service Offline: Directus on ${ORCHESTRATOR_ENV.DIRECTUS_URL}`,
      serviceUrl: ORCHESTRATOR_ENV.DIRECTUS_URL,
      statusCode: res.statusCode
    };
  }

  /**
   * 3. THINGSBOARD IOT: Fetch Live Telemetry (/api/plugins/telemetry/DEVICE/...)
   */
  static async fetchTelemetry(deviceId = ORCHESTRATOR_ENV.SOLAR_DEVICE_ID): Promise<ApiResponse<ThingsBoardLiveTelemetry>> {
    const proxyUrl = `/api/ecosystem/thingsboard/telemetry/${encodeURIComponent(deviceId)}`;
    const res = await safeFetch<any>(
      proxyUrl,
      'ThingsBoard IoT',
      ORCHESTRATOR_ENV.THINGSBOARD_URL
    );

    if (res.success && res.data) {
      const telemetry = res.data.telemetry || res.data;
      return {
        success: true,
        data: telemetry,
        serviceUrl: ORCHESTRATOR_ENV.THINGSBOARD_URL
      };
    }

    return {
      success: false,
      error: res.error || `Service Offline: ThingsBoard on ${ORCHESTRATOR_ENV.THINGSBOARD_URL}`,
      serviceUrl: ORCHESTRATOR_ENV.THINGSBOARD_URL,
      statusCode: res.statusCode
    };
  }

  /**
   * 4. MOODLE LMS: Fetch & Verify Technician Certifications (/webservice/rest/server.php)
   */
  static async fetchCertifications(email?: string): Promise<ApiResponse<MoodleCertificate[]>> {
    const q = email ? `?email=${encodeURIComponent(email)}` : '';
    const proxyUrl = `/api/ecosystem/moodle/certifications${q}`;
    const res = await safeFetch<any>(
      proxyUrl,
      'Moodle LMS Academy',
      ORCHESTRATOR_ENV.MOODLE_URL
    );

    if (res.success && res.data) {
      const certs = Array.isArray(res.data) ? res.data : (res.data.data || []);
      return {
        success: true,
        data: certs,
        serviceUrl: ORCHESTRATOR_ENV.MOODLE_URL
      };
    }

    return {
      success: false,
      error: res.error || `Service Offline: Moodle on ${ORCHESTRATOR_ENV.MOODLE_URL}`,
      serviceUrl: ORCHESTRATOR_ENV.MOODLE_URL,
      statusCode: res.statusCode
    };
  }

  /**
   * 5. POSTAL MAIL: Dispatch Outbound Transactional Email (/v1/send/message)
   */
  static async dispatchEmail(emailReq: PostalEmailRequest): Promise<ApiResponse<{ messageId: string }>> {
    const proxyUrl = '/api/ecosystem/postal/send';
    const res = await safeFetch<any>(
      proxyUrl,
      'Postal Mail Server',
      ORCHESTRATOR_ENV.POSTAL_API_URL,
      {
        method: 'POST',
        body: JSON.stringify(emailReq)
      }
    );

    if (res.success && res.data) {
      return {
        success: true,
        data: { messageId: res.data.messageId || `msg-${Date.now()}` },
        serviceUrl: ORCHESTRATOR_ENV.POSTAL_API_URL
      };
    }

    return {
      success: false,
      error: res.error || `Service Offline: Postal on ${ORCHESTRATOR_ENV.POSTAL_API_URL}`,
      serviceUrl: ORCHESTRATOR_ENV.POSTAL_API_URL,
      statusCode: res.statusCode
    };
  }

  /**
   * 6. OPENSEARCH: Index Audit Record (/audit-logs/_doc)
   */
  static async logAuditEvent(record: OpenSearchAuditRecord): Promise<ApiResponse<{ eventId: string }>> {
    const proxyUrl = '/api/ecosystem/opensearch/audit';
    const res = await safeFetch<any>(
      proxyUrl,
      'OpenSearch Cluster',
      ORCHESTRATOR_ENV.OPENSEARCH_URL,
      {
        method: 'POST',
        body: JSON.stringify(record)
      }
    );

    if (res.success && res.data) {
      return {
        success: true,
        data: { eventId: res.data.eventId || `audit-${Date.now()}` },
        serviceUrl: ORCHESTRATOR_ENV.OPENSEARCH_URL
      };
    }

    return {
      success: false,
      error: res.error || `Service Offline: OpenSearch on ${ORCHESTRATOR_ENV.OPENSEARCH_URL}`,
      serviceUrl: ORCHESTRATOR_ENV.OPENSEARCH_URL,
      statusCode: res.statusCode
    };
  }
}
