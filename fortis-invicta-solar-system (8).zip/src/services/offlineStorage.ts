import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { AssessmentReport } from '../types';

export interface OfflineAssessmentRecord extends AssessmentReport {
  syncStatus: 'synced' | 'pending_sync' | 'sync_failed';
  offlineCreatedAt: string;
  lastSyncAttempt?: string;
  syncError?: string;
  gpsCoordinates?: {
    latitude: number;
    longitude: number;
    accuracyMeters?: number;
    altitudeMeters?: number;
  };
  photos?: Array<{
    id: string;
    caption: string;
    dataUrl: string;
    timestamp: string;
  }>;
  loadInventory?: Array<{
    name: string;
    category: 'resistive' | 'motor_small' | 'motor_heavy' | 'electronic';
    nominalWatts: number;
    surgeMultiplier: number;
    quantity: number;
    hoursPerDay: number;
  }>;
}

export interface SyncQueueItem {
  id: string;
  action: 'CREATE_ASSESSMENT' | 'UPDATE_ASSESSMENT' | 'UPLOAD_PHOTOS';
  entityId: string;
  payload: any;
  timestamp: string;
  retryCount: number;
  lastError?: string;
}

interface FortisOfflineDB extends DBSchema {
  assessments: {
    key: string;
    value: OfflineAssessmentRecord;
    indexes: {
      'by-syncStatus': string;
      'by-clientId': string;
      'by-date': string;
    };
  };
  syncQueue: {
    key: string;
    value: SyncQueueItem;
    indexes: {
      'by-timestamp': string;
    };
  };
  photos: {
    key: string;
    value: {
      id: string;
      assessmentId: string;
      caption: string;
      blobDataUrl: string;
      createdAt: string;
    };
    indexes: {
      'by-assessmentId': string;
    };
  };
}

const DB_NAME = 'fortis_solar_offline_db';
const DB_VERSION = 1;

let isIndexedDBAvailable: boolean | null = null;
let dbPromise: Promise<IDBPDatabase<FortisOfflineDB> | null> | null = null;

// In-Memory / LocalStorage fallback storage when IndexedDB is blocked
const memoryStore = {
  assessments: new Map<string, OfflineAssessmentRecord>(),
  syncQueue: new Map<string, SyncQueueItem>(),
  photos: new Map<string, any>()
};

function checkIndexedDBAvailability(): boolean {
  if (isIndexedDBAvailable !== null) return isIndexedDBAvailable;
  try {
    if (typeof window === 'undefined' || !window.indexedDB) {
      isIndexedDBAvailable = false;
      return false;
    }
    isIndexedDBAvailable = true;
    return true;
  } catch {
    isIndexedDBAvailable = false;
    return false;
  }
}

async function getDB(): Promise<IDBPDatabase<FortisOfflineDB> | null> {
  if (!checkIndexedDBAvailability()) {
    return null;
  }

  if (!dbPromise) {
    dbPromise = openDB<FortisOfflineDB>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        // 1. Assessments store
        if (!db.objectStoreNames.contains('assessments')) {
          const assessStore = db.createObjectStore('assessments', { keyPath: 'id' });
          assessStore.createIndex('by-syncStatus', 'syncStatus');
          assessStore.createIndex('by-clientId', 'clientId');
          assessStore.createIndex('by-date', 'completedDate');
        }

        // 2. Sync Queue store
        if (!db.objectStoreNames.contains('syncQueue')) {
          const queueStore = db.createObjectStore('syncQueue', { keyPath: 'id' });
          queueStore.createIndex('by-timestamp', 'timestamp');
        }

        // 3. Photos store
        if (!db.objectStoreNames.contains('photos')) {
          const photoStore = db.createObjectStore('photos', { keyPath: 'id' });
          photoStore.createIndex('by-assessmentId', 'assessmentId');
        }
      }
    }).catch((err) => {
      console.warn('[OfflineStorage] IndexedDB initialization bypassed, using memory fallback:', err);
      isIndexedDBAvailable = false;
      return null;
    });
  }

  return dbPromise;
}

export const OfflineStorage = {
  // Save or update assessment offline
  async saveAssessment(assessment: OfflineAssessmentRecord): Promise<void> {
    try {
      const db = await getDB();
      if (db) {
        await db.put('assessments', assessment);

        if (assessment.syncStatus === 'pending_sync') {
          const queueItem: SyncQueueItem = {
            id: `sync-${assessment.id}-${Date.now()}`,
            action: 'CREATE_ASSESSMENT',
            entityId: assessment.id,
            payload: assessment,
            timestamp: new Date().toISOString(),
            retryCount: 0
          };
          await db.put('syncQueue', queueItem);
        }
        return;
      }
    } catch (err) {
      console.warn('[OfflineStorage] Error writing to IndexedDB, fallback to memory:', err);
    }

    // Memory Fallback
    memoryStore.assessments.set(assessment.id, assessment);
    if (assessment.syncStatus === 'pending_sync') {
      memoryStore.syncQueue.set(`sync-${assessment.id}`, {
        id: `sync-${assessment.id}-${Date.now()}`,
        action: 'CREATE_ASSESSMENT',
        entityId: assessment.id,
        payload: assessment,
        timestamp: new Date().toISOString(),
        retryCount: 0
      });
    }
  },

  // Get all assessments from IndexedDB / Fallback
  async getAllAssessments(): Promise<OfflineAssessmentRecord[]> {
    try {
      const db = await getDB().catch(() => null);
      if (db) {
        return await db.getAll('assessments').catch(() => Array.from(memoryStore.assessments.values()));
      }
    } catch (err) {
      console.info('[OfflineStorage] Memory store used for all assessments');
    }

    return Array.from(memoryStore.assessments.values());
  },

  // Get pending assessments awaiting cloud sync
  async getPendingAssessments(): Promise<OfflineAssessmentRecord[]> {
    try {
      const db = await getDB().catch(() => null);
      if (db) {
        try {
          return await db.getAllFromIndex('assessments', 'by-syncStatus', 'pending_sync');
        } catch {
          const all = await db.getAll('assessments').catch(() => []);
          return all.filter((a) => a.syncStatus === 'pending_sync');
        }
      }
    } catch (err) {
      console.info('[OfflineStorage] Memory store used for pending assessments');
    }

    return Array.from(memoryStore.assessments.values()).filter((a) => a.syncStatus === 'pending_sync');
  },

  // Mark assessment as synced
  async markAsSynced(assessmentId: string): Promise<void> {
    try {
      const db = await getDB().catch(() => null);
      if (db) {
        const existing = await db.get('assessments', assessmentId).catch(() => null);
        if (existing) {
          existing.syncStatus = 'synced';
          existing.lastSyncAttempt = new Date().toISOString();
          delete existing.syncError;
          await db.put('assessments', existing).catch(() => {});
        }

        const queueItems = await db.getAll('syncQueue').catch(() => []);
        for (const item of queueItems) {
          if (item.entityId === assessmentId) {
            await db.delete('syncQueue', item.id).catch(() => {});
          }
        }
        return;
      }
    } catch (err) {
      console.info('[OfflineStorage] Synced status marked in memory store');
    }

    const memItem = memoryStore.assessments.get(assessmentId);
    if (memItem) {
      memItem.syncStatus = 'synced';
      memItem.lastSyncAttempt = new Date().toISOString();
      delete memItem.syncError;
    }
    memoryStore.syncQueue.delete(`sync-${assessmentId}`);
  },

  // Mark assessment as sync failed
  async markSyncFailed(assessmentId: string, errorMessage: string): Promise<void> {
    try {
      const db = await getDB().catch(() => null);
      if (db) {
        const existing = await db.get('assessments', assessmentId).catch(() => null);
        if (existing) {
          existing.syncStatus = 'sync_failed';
          existing.lastSyncAttempt = new Date().toISOString();
          existing.syncError = errorMessage;
          await db.put('assessments', existing).catch(() => {});
        }
        return;
      }
    } catch (err) {
      console.info('[OfflineStorage] Sync failed status recorded in memory store');
    }

    const memItem = memoryStore.assessments.get(assessmentId);
    if (memItem) {
      memItem.syncStatus = 'sync_failed';
      memItem.lastSyncAttempt = new Date().toISOString();
      memItem.syncError = errorMessage;
    }
  },

  // Store photo offline
  async savePhoto(assessmentId: string, caption: string, blobDataUrl: string): Promise<string> {
    const id = `photo-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    try {
      const db = await getDB().catch(() => null);
      if (db) {
        await db.put('photos', {
          id,
          assessmentId,
          caption,
          blobDataUrl,
          createdAt: new Date().toISOString()
        }).catch(() => {});
        return id;
      }
    } catch (err) {
      console.info('[OfflineStorage] Photo saved to fallback store');
    }

    memoryStore.photos.set(id, { id, assessmentId, caption, blobDataUrl, createdAt: new Date().toISOString() });
    return id;
  },

  // Get photos for assessment
  async getPhotosForAssessment(assessmentId: string) {
    try {
      const db = await getDB().catch(() => null);
      if (db) {
        try {
          return await db.getAllFromIndex('photos', 'by-assessmentId', assessmentId);
        } catch {
          const all = await db.getAll('photos').catch(() => []);
          return all.filter((p) => p.assessmentId === assessmentId);
        }
      }
    } catch (err) {
      console.info('[OfflineStorage] Photos retrieved from fallback store');
    }

    return Array.from(memoryStore.photos.values()).filter((p) => p.assessmentId === assessmentId);
  },

  // Get count of unsynced items
  async getUnsyncedCount(): Promise<number> {
    try {
      const db = await getDB().catch(() => null);
      if (db) {
        try {
          const pending = await db.getAllFromIndex('assessments', 'by-syncStatus', 'pending_sync');
          const failed = await db.getAllFromIndex('assessments', 'by-syncStatus', 'sync_failed');
          return pending.length + failed.length;
        } catch {
          const all = await db.getAll('assessments').catch(() => []);
          return all.filter((a) => a.syncStatus === 'pending_sync' || a.syncStatus === 'sync_failed').length;
        }
      }
    } catch (err) {
      console.info('[OfflineStorage] Unsynced count retrieved from fallback store');
    }

    const pendingMem = Array.from(memoryStore.assessments.values()).filter(
      (a) => a.syncStatus === 'pending_sync' || a.syncStatus === 'sync_failed'
    );
    return pendingMem.length;
  }
};
