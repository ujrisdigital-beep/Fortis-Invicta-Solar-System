import { OfflineStorage, OfflineAssessmentRecord } from './offlineStorage';

export type SyncState = 'idle' | 'syncing' | 'synced' | 'offline' | 'error';

class BackgroundSyncService {
  private isOnline: boolean = typeof navigator !== 'undefined' ? navigator.onLine : true;
  private isSyncing: boolean = false;
  private listeners: Set<(state: { isOnline: boolean; syncState: SyncState; unsyncedCount: number; lastSyncTime?: string }) => void> = new Set();
  private lastSyncTime?: string;

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        window.addEventListener('online', this.handleOnline.bind(this));
        window.addEventListener('offline', this.handleOffline.bind(this));

        // Listen to Service Worker message safely
        try {
          if ('serviceWorker' in navigator && navigator.serviceWorker && typeof navigator.serviceWorker.addEventListener === 'function') {
            navigator.serviceWorker.addEventListener('message', (event) => {
              if (event.data?.type === 'TRIGGER_BACKGROUND_SYNC') {
                this.syncPendingData().catch(() => {});
              }
            });
          }
        } catch {
          // Bypassed in iframe sandbox
        }

        // Initial check after 3 seconds
        setTimeout(() => {
          this.syncPendingData().catch(() => {});
        }, 3000);
      } catch (err) {
        console.info('[BackgroundSync] Setup bypassed:', err);
      }
    }
  }

  public subscribe(callback: (state: { isOnline: boolean; syncState: SyncState; unsyncedCount: number; lastSyncTime?: string }) => void) {
    this.listeners.add(callback);
    this.notifyState('idle').catch(() => {});
    return () => {
      this.listeners.delete(callback);
    };
  }

  private async notifyState(syncState: SyncState) {
    try {
      const unsyncedCount = await OfflineStorage.getUnsyncedCount().catch(() => 0);
      const state = {
        isOnline: this.isOnline,
        syncState,
        unsyncedCount,
        lastSyncTime: this.lastSyncTime
      };
      this.listeners.forEach((fn) => {
        try {
          fn(state);
        } catch (err) {
          console.warn('[BackgroundSync] Listener error:', err);
        }
      });
    } catch (err) {
      console.warn('[BackgroundSync] notifyState error:', err);
    }
  }

  private handleOnline() {
    this.isOnline = true;
    console.log('[Network] Cellular / Wi-Fi connection restored. Initiating automatic background sync.');
    this.syncPendingData().catch(() => {});
  }

  private handleOffline() {
    this.isOnline = false;
    console.log('[Network] Device offline. Field assessments will be queued in IndexedDB.');
    this.notifyState('offline').catch(() => {});
  }

  public async syncPendingData(): Promise<{ success: boolean; syncedCount: number; errors: string[] }> {
    if (!this.isOnline || this.isSyncing) {
      return { success: false, syncedCount: 0, errors: ['Offline or sync in progress'] };
    }

    this.isSyncing = true;
    this.notifyState('syncing');

    const pending = await OfflineStorage.getPendingAssessments();
    if (pending.length === 0) {
      this.isSyncing = false;
      this.lastSyncTime = new Date().toLocaleTimeString();
      this.notifyState('idle');
      return { success: true, syncedCount: 0, errors: [] };
    }

    let syncedCount = 0;
    const errors: string[] = [];

    for (const assessment of pending) {
      try {
        const response = await fetch('/api/v2/assessments', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            clientId: assessment.clientId,
            roofType: assessment.roofType,
            roofCondition: assessment.roofCondition,
            sunExposureHours: assessment.sunExposureHours,
            shadingLevel: assessment.shadingLevel,
            nawecGridStability: 'Intermittent',
            dailyEnergyKWh: assessment.recommendedPanelCapacityKW * 4.2,
            recommendedKVA: assessment.recommendedInverterKVA,
            recommendedPanels: Math.ceil((assessment.recommendedPanelCapacityKW * 1000) / 550),
            recommendedBatteries: Math.ceil(assessment.recommendedBatteryKWH / 4.8),
            notes: `[OFFLINE SYNCED] ${assessment.notes}`,
            gpsCoordinates: assessment.gpsCoordinates
          })
        });

        if (response.ok) {
          await OfflineStorage.markAsSynced(assessment.id);
          syncedCount++;
        } else {
          const errData = await response.json().catch(() => ({}));
          const errMsg = errData.error || `HTTP ${response.status}`;
          await OfflineStorage.markSyncFailed(assessment.id, errMsg);
          errors.push(`Failed for ${assessment.clientName}: ${errMsg}`);
        }
      } catch (err: any) {
        await OfflineStorage.markSyncFailed(assessment.id, err.message || 'Network fetch error');
        errors.push(`Network error for ${assessment.clientName}: ${err.message}`);
      }
    }

    this.isSyncing = false;
    this.lastSyncTime = new Date().toLocaleTimeString();
    this.notifyState(errors.length === 0 ? 'synced' : 'error');

    return {
      success: errors.length === 0,
      syncedCount,
      errors
    };
  }

  public getStatus() {
    return {
      isOnline: this.isOnline,
      isSyncing: this.isSyncing,
      lastSyncTime: this.lastSyncTime
    };
  }
}

export const BackgroundSync = new BackgroundSyncService();
