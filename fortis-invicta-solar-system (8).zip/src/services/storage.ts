import {
  Client,
  PaymentRecord,
  AssessmentReport,
  InstallationLog,
  InstitutionalMember,
  AuditLogItem,
  ProjectStage,
  PaymentStatus,
  UserRole,
  UnionConfig,
  MultimediaRecord,
  SolarPackage,
  ForexInflationConfig,
  Team
} from '../types';
import {
  INITIAL_CLIENTS,
  INITIAL_PAYMENTS,
  INITIAL_ASSESSMENTS,
  INITIAL_INSTALLATIONS,
  INSTITUTIONAL_MEMBERS_DATABASE,
  INITIAL_AUDIT_LOGS,
  INITIAL_UNIONS,
  INITIAL_MULTIMEDIA,
  SOLAR_PACKAGES,
  INITIAL_TEAMS
} from '../data/mockData';
import { OfflineStorage, OfflineAssessmentRecord } from './offlineStorage';
import { BackgroundSync } from './backgroundSync';

const CLIENTS_KEY = 'fortis_invicta_clients_v1';
const PAYMENTS_KEY = 'fortis_invicta_payments_v1';
const ASSESSMENTS_KEY = 'fortis_invicta_assessments_v1';
const INSTALLATIONS_KEY = 'fortis_invicta_installations_v1';
const MEMBERS_KEY = 'fortis_invicta_members_v1';
const AUDIT_KEY = 'fortis_invicta_audit_v1';
const UNIONS_KEY = 'fortis_invicta_unions_v1';
const MULTIMEDIA_KEY = 'fortis_invicta_multimedia_v1';
const PACKAGES_KEY = 'fortis_invicta_packages_v1';
const FOREX_KEY = 'fortis_invicta_forex_v1';
const TEAMS_KEY = 'fortis_invicta_teams_v1';

function generateUniqueId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

export class StorageService {
  // --- CLIENTS ---
  static getClients(): Client[] {
    const data = localStorage.getItem(CLIENTS_KEY);
    if (!data) {
      localStorage.setItem(CLIENTS_KEY, JSON.stringify(INITIAL_CLIENTS));
      return INITIAL_CLIENTS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_CLIENTS;
    }
  }

  static getClientById(id: string): Client | undefined {
    return this.getClients().find((c) => c.id === id);
  }

  static saveClient(client: Client, actorName = 'System Admin', actorRole: UserRole = 'project_manager'): Client {
    const clients = this.getClients();
    const existingIndex = clients.findIndex((c) => c.id === client.id);
    const updatedClient = {
      ...client,
      updatedAt: new Date().toISOString()
    };

    if (existingIndex >= 0) {
      clients[existingIndex] = updatedClient;
      this.addAuditLog({
        id: generateUniqueId('log'),
        timestamp: new Date().toISOString(),
        actorName,
        actorRole,
        action: 'CLIENT_UPDATED',
        details: `Updated client details for ${client.fullName}`,
        clientId: client.id
      });
    } else {
      clients.unshift(updatedClient);
      this.addAuditLog({
        id: generateUniqueId('log'),
        timestamp: new Date().toISOString(),
        actorName,
        actorRole,
        action: 'CLIENT_CREATED',
        details: `Onboarded new client ${client.fullName} (${client.clientSegment})`,
        clientId: client.id
      });
    }

    localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
    return updatedClient;
  }

  static updateClientStage(
    clientId: string,
    newStage: ProjectStage,
    actorName = 'Project Manager',
    actorRole: UserRole = 'project_manager'
  ): Client | null {
    const clients = this.getClients();
    const client = clients.find((c) => c.id === clientId);
    if (!client) return null;

    const oldStage = client.projectStage;
    client.projectStage = newStage;
    client.updatedAt = new Date().toISOString();

    localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));

    this.addAuditLog({
      id: generateUniqueId('log'),
      timestamp: new Date().toISOString(),
      actorName,
      actorRole,
      action: 'STAGE_CHANGED',
      details: `Changed stage of ${client.fullName} from ${oldStage.toUpperCase()} to ${newStage.toUpperCase()}`,
      clientId
    });

    return client;
  }

  // --- PAYMENTS ---
  static getPayments(): PaymentRecord[] {
    const data = localStorage.getItem(PAYMENTS_KEY);
    if (!data) {
      localStorage.setItem(PAYMENTS_KEY, JSON.stringify(INITIAL_PAYMENTS));
      return INITIAL_PAYMENTS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_PAYMENTS;
    }
  }

  static recordPayment(payment: Omit<PaymentRecord, 'id' | 'createdAt' | 'ecobankMerchantCode' | 'ecobankTerminalId'>): PaymentRecord {
    const payments = this.getPayments();
    const newPayment: PaymentRecord = {
      ...payment,
      id: generateUniqueId('pay'),
      ecobankMerchantCode: '505825057',
      ecobankTerminalId: '32680928',
      createdAt: new Date().toISOString()
    };

    payments.unshift(newPayment);
    localStorage.setItem(PAYMENTS_KEY, JSON.stringify(payments));

    // Update Client financials
    const clients = this.getClients();
    const client = clients.find((c) => c.id === payment.clientId);
    if (client) {
      if (payment.status === 'confirmed') {
        client.totalPaidGMD += payment.amountGMD;
        client.outstandingBalanceGMD = Math.max(0, client.totalQuotedGMD - client.totalPaidGMD);
        client.paymentStatus =
          client.outstandingBalanceGMD === 0 ? 'confirmed' : 'partially_paid';
      } else {
        client.paymentStatus = 'confirmation_required';
      }
      client.updatedAt = new Date().toISOString();
      localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
    }

    this.addAuditLog({
      id: generateUniqueId('log'),
      timestamp: new Date().toISOString(),
      actorName: payment.clientName,
      actorRole: 'client',
      action: 'PAYMENT_RECORDED',
      details: `Logged payment of GMD ${payment.amountGMD.toLocaleString()} (${payment.paymentMethod}) under Ecobank Merchant Code 505825057`,
      clientId: payment.clientId
    });

    return newPayment;
  }

  static confirmPayment(paymentId: string, confirmedBy = 'Kaddy Secka (Finance Officer)'): PaymentRecord | null {
    const payments = this.getPayments();
    const payment = payments.find((p) => p.id === paymentId);
    if (!payment) return null;

    payment.status = 'confirmed';
    payment.confirmedBy = confirmedBy;
    payment.confirmedAt = new Date().toISOString();
    payment.receiptNumber = 'RCP-2026-' + Math.floor(1000 + Math.random() * 9000);

    localStorage.setItem(PAYMENTS_KEY, JSON.stringify(payments));

    // Recalculate client financials
    const clients = this.getClients();
    const client = clients.find((c) => c.id === payment.clientId);
    if (client) {
      client.totalPaidGMD += payment.amountGMD;
      client.outstandingBalanceGMD = Math.max(0, client.totalQuotedGMD - client.totalPaidGMD);
      client.paymentStatus =
        client.outstandingBalanceGMD === 0 ? 'confirmed' : 'partially_paid';

      if (client.projectStage === 'payment_pending') {
        client.projectStage = 'installation_scheduled';
      }
      client.updatedAt = new Date().toISOString();
      localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
    }

    this.addAuditLog({
      id: generateUniqueId('log'),
      timestamp: new Date().toISOString(),
      actorName: confirmedBy,
      actorRole: 'finance_officer',
      action: 'PAYMENT_CONFIRMED',
      details: `Finance confirmed GMD ${payment.amountGMD.toLocaleString()} payment for ${payment.clientName}. Receipt ${payment.receiptNumber} issued.`,
      clientId: payment.clientId
    });

    return payment;
  }

  // --- ASSESSMENTS ---
  static getAssessments(): AssessmentReport[] {
    const data = localStorage.getItem(ASSESSMENTS_KEY);
    if (!data) {
      localStorage.setItem(ASSESSMENTS_KEY, JSON.stringify(INITIAL_ASSESSMENTS));
      return INITIAL_ASSESSMENTS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_ASSESSMENTS;
    }
  }

  static saveAssessment(assessment: AssessmentReport): AssessmentReport {
    const reports = this.getAssessments();
    const existingIndex = reports.findIndex((r) => r.id === assessment.id);

    if (existingIndex >= 0) {
      reports[existingIndex] = assessment;
    } else {
      reports.unshift(assessment);
    }

    localStorage.setItem(ASSESSMENTS_KEY, JSON.stringify(reports));

    // Offline-First IndexedDB persistence
    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
    const offlineRecord: OfflineAssessmentRecord = {
      ...assessment,
      syncStatus: isOnline ? 'synced' : 'pending_sync',
      offlineCreatedAt: new Date().toISOString(),
      gpsCoordinates: assessment.gpsCoordinates
    };

    // Store in robust IndexedDB offline cache
    OfflineStorage.saveAssessment(offlineRecord)
      .then(() => {
        // If device is online, immediately trigger background synchronization to backend
        if (isOnline) {
          BackgroundSync.syncPendingData().catch((err) => {
            console.warn('[StorageService] Auto-sync attempt:', err);
          });
        }
      })
      .catch((err) => {
        console.warn('[StorageService] OfflineStorage save warning:', err);
      });

    // Update client stage if assessment completed
    if (assessment.outcome === 'approved' || assessment.outcome === 'approved_with_modifications') {
      this.updateClientStage(
        assessment.clientId,
        'assessment_complete',
        assessment.inspectorName,
        'site_inspector'
      );
    }

    return assessment;
  }

  static async getUnsyncedOfflineAssessmentsCount(): Promise<number> {
    try {
      return await OfflineStorage.getUnsyncedCount();
    } catch {
      return 0;
    }
  }

  static triggerAssessmentSync(): Promise<{ success: boolean; syncedCount: number; errors: string[] }> {
    return BackgroundSync.syncPendingData();
  }

  // --- INSTALLATIONS ---
  static getInstallations(): InstallationLog[] {
    const data = localStorage.getItem(INSTALLATIONS_KEY);
    if (!data) {
      localStorage.setItem(INSTALLATIONS_KEY, JSON.stringify(INITIAL_INSTALLATIONS));
      return INITIAL_INSTALLATIONS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_INSTALLATIONS;
    }
  }

  static saveInstallation(log: InstallationLog): InstallationLog {
    const logs = this.getInstallations();
    const existingIndex = logs.findIndex((l) => l.id === log.id);

    if (existingIndex >= 0) {
      logs[existingIndex] = log;
    } else {
      logs.unshift(log);
    }

    localStorage.setItem(INSTALLATIONS_KEY, JSON.stringify(logs));

    if (log.progressPercentage === 100 && log.checklists.loadTestingPassed) {
      this.updateClientStage(log.clientId, 'commissioning', log.teamLeader, 'installer');
    } else if (log.status === 'in_progress') {
      this.updateClientStage(log.clientId, 'installation_in_progress', log.teamLeader, 'installer');
    }

    return log;
  }

  // --- INSTITUTIONAL MEMBERS ---
  static getInstitutionalMembers(): InstitutionalMember[] {
    const data = localStorage.getItem(MEMBERS_KEY);
    if (!data) {
      localStorage.setItem(MEMBERS_KEY, JSON.stringify(INSTITUTIONAL_MEMBERS_DATABASE));
      return INSTITUTIONAL_MEMBERS_DATABASE;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INSTITUTIONAL_MEMBERS_DATABASE;
    }
  }

  static getInstitutionalMembersForRole(role: UserRole, institutionId?: string): InstitutionalMember[] {
    // 1. Role-Based Data Minimization (UK GDPR Art 5(1)(c) / Gambia DPPA Sec 12)
    // Field staff (site inspectors, installers) and retail clients have no lawful basis to view union members' confidential salary & credit limits
    if (role === 'site_inspector' || role === 'installer' || role === 'client') {
      return [];
    }

    const members = this.getInstitutionalMembers();

    // 2. Strict Institutional Tenant Segregation (GTUCCU vs NAGNMC)
    if (role === 'institutional_admin') {
      const targetInst = (institutionId || 'GTUCCU').trim().toUpperCase();
      return members.filter((m) => m.institutionId.toUpperCase() === targetInst);
    }

    // 3. Super Admins & Finance Officers can filter by institution if requested or see all
    if (institutionId && institutionId !== 'ALL') {
      const targetInst = institutionId.trim().toUpperCase();
      return members.filter((m) => m.institutionId.toUpperCase() === targetInst);
    }

    return members;
  }

  static verifyMember(
    institutionId: 'GTUCCU' | 'NAGNMC' | string,
    memberId: string,
    callingRole?: UserRole,
    callingInstitutionId?: string
  ): InstitutionalMember | null {
    // Enforce Tenant Boundary Check for Institutional Admins
    if (callingRole === 'institutional_admin' && callingInstitutionId) {
      const callerInst = callingInstitutionId.trim().toUpperCase();
      const targetInst = institutionId.trim().toUpperCase();
      if (callerInst !== targetInst) {
        console.warn(`[SECURITY VIOLATION] Institutional Admin (${callerInst}) attempted cross-tenant lookup for ${targetInst} member: ${memberId}`);
        return null; // Deny cross-tenant disclosure
      }
    }

    const members = this.getInstitutionalMembers();
    const cleanId = memberId.trim().toUpperCase();
    const cleanInst = institutionId.trim().toUpperCase();
    const match = members.find(
      (m) => m.institutionId.toUpperCase() === cleanInst && m.memberId.toUpperCase() === cleanId
    );

    if (match) {
      this.addAuditLog({
        id: generateUniqueId('log'),
        timestamp: new Date().toISOString(),
        actorName: callingRole ? `User (${callingRole})` : 'Verification Engine',
        actorRole: callingRole || 'super_admin',
        action: 'MEMBER_VERIFIED',
        details: `Verified membership for ${match.fullName} (${cleanInst} - ${cleanId})`
      });
    }

    return match || null;
  }

  // --- AUDIT LOGS ---
  static getAuditLogs(): AuditLogItem[] {
    const data = localStorage.getItem(AUDIT_KEY);
    if (!data) {
      localStorage.setItem(AUDIT_KEY, JSON.stringify(INITIAL_AUDIT_LOGS));
      return INITIAL_AUDIT_LOGS;
    }
    try {
      const parsed: AuditLogItem[] = JSON.parse(data);
      // Sanitize any duplicate legacy IDs from stored state
      const seenIds = new Set<string>();
      const sanitized = parsed.map((item, idx) => {
        if (!item.id || seenIds.has(item.id)) {
          const uniqueId = `log-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`;
          seenIds.add(uniqueId);
          return { ...item, id: uniqueId };
        }
        seenIds.add(item.id);
        return item;
      });
      return sanitized;
    } catch {
      return INITIAL_AUDIT_LOGS;
    }
  }

  static addAuditLog(log: AuditLogItem) {
    const logs = this.getAuditLogs();
    const uniqueLog: AuditLogItem = {
      ...log,
      id: log.id && !logs.some((l) => l.id === log.id) ? log.id : generateUniqueId('log')
    };
    logs.unshift(uniqueLog);
    localStorage.setItem(AUDIT_KEY, JSON.stringify(logs.slice(0, 100))); // keep 100 recent
  }

  // --- OPENSOLAR DIRECT PAYMENT HTML INSTRUCTIONS ---
  static generateOpenSolarDirectPaymentInstructions(
    clientName: string,
    amountGMD: number,
    referenceNumber: string
  ): string {
    return `
<div style="font-family: Arial, sans-serif; border: 2px solid #1B4D3E; border-radius: 8px; padding: 20px; background-color: #F8FAF8; max-width: 600px; margin: 10px auto;">
  <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #C9A84C; padding-bottom: 12px; margin-bottom: 16px;">
    <h3 style="color: #1B4D3E; margin: 0; font-size: 18px; text-transform: uppercase;">Fortis Invicta Ltd - Direct Bank Transfer Instructions</h3>
    <span style="background-color: #1B4D3E; color: #C9A84C; font-weight: bold; font-size: 11px; padding: 4px 8px; border-radius: 4px;">EcobankPay Active</span>
  </div>
  <p style="color: #333; font-size: 14px; margin-bottom: 16px;">
    Dear <strong>${clientName}</strong>, please complete your bank transfer or over-the-counter teller payment using the details below. Ensure you include your reference number so our finance team can verify instantly.
  </p>
  
  <table style="width: 100%; border-collapse: collapse; background-color: #FFFFFF; font-size: 13px; border: 1px solid #E2E8F0; margin-bottom: 16px;">
    <tbody>
      <tr style="border-bottom: 1px solid #E2E8F0;">
        <td style="padding: 10px; font-weight: bold; color: #1B4D3E; width: 40%; background-color: #F1F5F2;">Account Name:</td>
        <td style="padding: 10px; color: #111; font-weight: bold;">FORTIS INVICTA LTD</td>
      </tr>
      <tr style="border-bottom: 1px solid #E2E8F0;">
        <td style="padding: 10px; font-weight: bold; color: #1B4D3E; background-color: #F1F5F2;">Bank Name:</td>
        <td style="padding: 10px; color: #111;">Ecobank Gambia Ltd</td>
      </tr>
      <tr style="border-bottom: 1px solid #E2E8F0;">
        <td style="padding: 10px; font-weight: bold; color: #1B4D3E; background-color: #F1F5F2;">Ecobank Merchant Code:</td>
        <td style="padding: 10px; color: #C9A84C; font-weight: bold; font-size: 15px;">505825057</td>
      </tr>
      <tr style="border-bottom: 1px solid #E2E8F0;">
        <td style="padding: 10px; font-weight: bold; color: #1B4D3E; background-color: #F1F5F2;">Terminal ID:</td>
        <td style="padding: 10px; color: #111; font-weight: bold;">32680928</td>
      </tr>
      <tr style="border-bottom: 1px solid #E2E8F0;">
        <td style="padding: 10px; font-weight: bold; color: #1B4D3E; background-color: #F1F5F2;">Account Number (BBAN):</td>
        <td style="padding: 10px; color: #111; font-family: monospace; font-size: 14px;">10100582505701</td>
      </tr>
      <tr style="border-bottom: 1px solid #E2E8F0;">
        <td style="padding: 10px; font-weight: bold; color: #1B4D3E; background-color: #F1F5F2;">Required Amount:</td>
        <td style="padding: 10px; color: #1B4D3E; font-weight: bold; font-size: 16px;">GMD ${amountGMD.toLocaleString()}</td>
      </tr>
      <tr>
        <td style="padding: 10px; font-weight: bold; color: #1B4D3E; background-color: #F1F5F2;">Payment Reference:</td>
        <td style="padding: 10px; color: #D97706; font-weight: bold;">${referenceNumber}</td>
      </tr>
    </tbody>
  </table>

  <div style="background-color: #FEF3C7; border-left: 4px solid #D97706; padding: 12px; font-size: 12px; color: #92400E; margin-bottom: 12px;">
    <strong>Important:</strong> After completing transfer or teller deposit, upload your transaction slip in the client portal or click "Confirm Payment Sent". Our finance team will verify and issue your official receipt within 2 hours.
  </div>

  <div style="border-top: 1px dashed #CBD5E1; padding-top: 10px; font-size: 11px; color: #475569; text-align: center;">
    <strong>FORTIS INVICTA LTD, THE COMMAND HQ</strong><br/>
    Address: Tranquil Behind AGIB Bank, The Gambia • Phone / WhatsApp: <strong>+220 257 2911</strong> • Email: <strong>info@fortisinvicta.com</strong>
  </div>
</div>
    `.trim();
  }

  // --- KPI & DASHBOARD METRICS ---
  static getMetrics(role: UserRole = 'super_admin', institutionId?: string, userClientId?: string) {
    const clients = this.getClientsForRole(role, userClientId, institutionId);
    const payments = this.getPaymentsForRole(role, userClientId, institutionId);

    const totalLeads = clients.length;
    const activeInstallations = clients.filter(
      (c) => c.projectStage === 'installation_in_progress' || c.projectStage === 'installation_scheduled'
    ).length;
    const completedProjects = clients.filter((c) => c.projectStage === 'completed').length;

    const totalQuoted = clients.reduce((acc, c) => acc + c.totalQuotedGMD, 0);
    const totalCollected = payments
      .filter((p) => p.status === 'confirmed')
      .reduce((acc, p) => acc + p.amountGMD, 0);
    const outstandingBalance = Math.max(0, totalQuoted - totalCollected);

    const pendingConfirmationPayments = payments.filter((p) => p.status === 'confirmation_required').length;

    const segmentCounts = {
      gtuccu_member: clients.filter((c) => c.clientSegment === 'gtuccu_member').length,
      nagnmc_member: clients.filter((c) => c.clientSegment === 'nagnmc_member').length,
      diaspora: clients.filter((c) => c.clientSegment === 'diaspora').length,
      non_union_individual: clients.filter((c) => c.clientSegment === 'non_union_individual').length
    };

    const stageCounts = {
      lead: clients.filter((c) => c.projectStage === 'lead').length,
      assessment_scheduled: clients.filter((c) => c.projectStage === 'assessment_scheduled').length,
      assessment_complete: clients.filter((c) => c.projectStage === 'assessment_complete').length,
      payment_pending: clients.filter((c) => c.projectStage === 'payment_pending').length,
      installation_scheduled: clients.filter((c) => c.projectStage === 'installation_scheduled').length,
      installation_in_progress: clients.filter((c) => c.projectStage === 'installation_in_progress').length,
      commissioning: clients.filter((c) => c.projectStage === 'commissioning').length,
      completed: clients.filter((c) => c.projectStage === 'completed').length
    };

    return {
      totalLeads,
      activeInstallations,
      completedProjects,
      totalQuotedGMD: totalQuoted,
      totalCollectedGMD: totalCollected,
      outstandingBalanceGMD: outstandingBalance,
      pendingConfirmationPayments,
      segmentCounts,
      stageCounts
    };
  }

  // --- UNIONS / INSTITUTIONAL CONFIGURATION ---
  static getUnions(): UnionConfig[] {
    const data = localStorage.getItem(UNIONS_KEY);
    if (!data) {
      localStorage.setItem(UNIONS_KEY, JSON.stringify(INITIAL_UNIONS));
      return INITIAL_UNIONS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_UNIONS;
    }
  }

  static getUnionsForRole(role: UserRole, institutionId?: string): UnionConfig[] {
    const unions = this.getUnions();
    if (role === 'institutional_admin') {
      const targetInst = (institutionId || 'GTUCCU').trim().toUpperCase();
      return unions.filter((u) => u.shortCode.toUpperCase() === targetInst || u.id.toUpperCase() === targetInst);
    }
    return unions;
  }

  static saveUnion(union: UnionConfig, actorName = 'System Admin'): UnionConfig {
    const unions = this.getUnions();
    const idx = unions.findIndex((u) => u.id === union.id || u.shortCode === union.shortCode);

    if (idx >= 0) {
      unions[idx] = union;
      this.addAuditLog({
        id: generateUniqueId('log'),
        timestamp: new Date().toISOString(),
        actorName,
        actorRole: 'super_admin',
        action: 'UNION_UPDATED',
        details: `Updated parameters for Institutional Union: ${union.name} (${union.shortCode})`
      });
    } else {
      unions.unshift(union);
      this.addAuditLog({
        id: generateUniqueId('log'),
        timestamp: new Date().toISOString(),
        actorName,
        actorRole: 'super_admin',
        action: 'UNION_CREATED',
        details: `Onboarded new Institutional Union: ${union.name} (${union.shortCode})`
      });
    }

    localStorage.setItem(UNIONS_KEY, JSON.stringify(unions));
    return union;
  }

  static toggleUnionStatus(unionId: string, actorName = 'System Admin'): UnionConfig | null {
    const unions = this.getUnions();
    const union = unions.find((u) => u.id === unionId);
    if (!union) return null;

    union.isActive = !union.isActive;
    localStorage.setItem(UNIONS_KEY, JSON.stringify(unions));

    this.addAuditLog({
      id: generateUniqueId('log'),
      timestamp: new Date().toISOString(),
      actorName,
      actorRole: 'super_admin',
      action: 'UNION_STATUS_TOGGLED',
      details: `${union.isActive ? 'Activated' : 'Deactivated'} Union: ${union.name}`
    });

    return union;
  }

  // --- ROW-LEVEL SECURITY (RLS) & TENANT SEGREGATION (UK GDPR & GAMBIA DATA PROTECTION) ---
  static getClientsForRole(role: UserRole, userClientId?: string, institutionId?: string): Client[] {
    const clients = this.getClients();

    // 1. Super Admin, Project Manager, Finance Officer: full oversight
    if (role === 'super_admin' || role === 'project_manager' || role === 'finance_officer') {
      if (institutionId && institutionId !== 'ALL') {
        const targetInst = institutionId.trim().toUpperCase();
        return clients.filter((c) => {
          if (targetInst === 'GTUCCU') return c.clientSegment === 'gtuccu_member' || c.institutionId === 'GTUCCU';
          if (targetInst === 'NAGNMC') return c.clientSegment === 'nagnmc_member' || c.institutionId === 'NAGNMC';
          return c.institutionId?.toUpperCase() === targetInst;
        });
      }
      return clients;
    }

    // 2. Institutional Admin: Strict Tenant Segregation (GTUCCU vs NAGNMC)
    if (role === 'institutional_admin') {
      const targetInst = (institutionId || 'GTUCCU').trim().toUpperCase();
      if (targetInst === 'GTUCCU' || targetInst.startsWith('GTU')) {
        return clients.filter((c) => c.clientSegment === 'gtuccu_member' || c.institutionId === 'GTUCCU');
      }
      if (targetInst === 'NAGNMC' || targetInst.startsWith('NAG')) {
        return clients.filter((c) => c.clientSegment === 'nagnmc_member' || c.institutionId === 'NAGNMC');
      }
      return clients.filter((c) => c.institutionId?.toUpperCase() === targetInst);
    }

    // 3. Site Inspector: Restricted to survey / feasibility stages
    if (role === 'site_inspector') {
      const allowedStages: ProjectStage[] = [
        'lead',
        'assessment_scheduled',
        'assessment_complete',
        'payment_pending'
      ];
      return clients.filter((c) => allowedStages.includes(c.projectStage));
    }

    // 4. Field Installer: Restricted to active and completed installation stages
    if (role === 'installer') {
      const allowedStages: ProjectStage[] = [
        'installation_scheduled',
        'installation_in_progress',
        'commissioning',
        'completed'
      ];
      return clients.filter((c) => allowedStages.includes(c.projectStage));
    }

    // 5. Client: Strict Single-Tenant Isolation (Own profile only)
    if (role === 'client') {
      if (userClientId) {
        return clients.filter((c) => c.id === userClientId);
      }
      return clients.filter((c) => c.id === 'cli-001' || c.id === 'client-1');
    }

    return clients;
  }

  static getPaymentsForRole(role: UserRole, userClientId?: string, institutionId?: string): PaymentRecord[] {
    const payments = this.getPayments();

    // 1. Super Admin, Project Manager, Finance Officer: Full financial ledger access
    if (role === 'super_admin' || role === 'project_manager' || role === 'finance_officer') {
      if (institutionId && institutionId !== 'ALL') {
        const instClients = this.getClientsForRole(role, userClientId, institutionId);
        const instClientIds = new Set(instClients.map((c) => c.id));
        return payments.filter((p) => instClientIds.has(p.clientId));
      }
      return payments;
    }

    // 2. Client: Only their own payments
    if (role === 'client') {
      const targetClientId = userClientId || 'cli-001';
      return payments.filter((p) => p.clientId === targetClientId);
    }

    // 3. Institutional Admin: Only payments linked to their verified members
    if (role === 'institutional_admin') {
      const instClients = this.getClientsForRole('institutional_admin', userClientId, institutionId);
      const instClientIds = new Set(instClients.map((c) => c.id));
      return payments.filter((p) => instClientIds.has(p.clientId));
    }

    // 4. Field Staff (Site Inspectors & Installers): Payment records completely redacted under UK GDPR / Gambia DPPA Data Minimization
    if (role === 'site_inspector' || role === 'installer') {
      return [];
    }

    return payments;
  }

  static getAssessmentsForRole(role: UserRole, userClientId?: string, institutionId?: string): AssessmentReport[] {
    const assessments = this.getAssessments();

    if (role === 'super_admin' || role === 'project_manager' || role === 'finance_officer' || role === 'site_inspector') {
      if (institutionId && institutionId !== 'ALL') {
        const instClients = this.getClientsForRole(role, userClientId, institutionId);
        const instClientIds = new Set(instClients.map((c) => c.id));
        return assessments.filter((a) => instClientIds.has(a.clientId));
      }
      return assessments;
    }

    if (role === 'institutional_admin') {
      const instClients = this.getClientsForRole('institutional_admin', userClientId, institutionId);
      const instClientIds = new Set(instClients.map((c) => c.id));
      return assessments.filter((a) => instClientIds.has(a.clientId));
    }

    if (role === 'client') {
      const targetClientId = userClientId || 'cli-001';
      return assessments.filter((a) => a.clientId === targetClientId);
    }

    if (role === 'installer') {
      const instClients = this.getClientsForRole('installer');
      const instClientIds = new Set(instClients.map((c) => c.id));
      return assessments.filter((a) => instClientIds.has(a.clientId));
    }

    return assessments;
  }

  static getInstallationsForRole(role: UserRole, userClientId?: string, institutionId?: string): InstallationLog[] {
    const installations = this.getInstallations();

    if (role === 'super_admin' || role === 'project_manager' || role === 'finance_officer' || role === 'installer') {
      if (institutionId && institutionId !== 'ALL') {
        const instClients = this.getClientsForRole(role, userClientId, institutionId);
        const instClientIds = new Set(instClients.map((c) => c.id));
        return installations.filter((i) => instClientIds.has(i.clientId));
      }
      return installations;
    }

    if (role === 'institutional_admin') {
      const instClients = this.getClientsForRole('institutional_admin', userClientId, institutionId);
      const instClientIds = new Set(instClients.map((c) => c.id));
      return installations.filter((i) => instClientIds.has(i.clientId));
    }

    if (role === 'client') {
      const targetClientId = userClientId || 'cli-001';
      return installations.filter((i) => i.clientId === targetClientId);
    }

    if (role === 'site_inspector') {
      const inspectClients = this.getClientsForRole('site_inspector');
      const inspectClientIds = new Set(inspectClients.map((c) => c.id));
      return installations.filter((i) => inspectClientIds.has(i.clientId));
    }

    return installations;
  }

  // --- MULTIMEDIA SYSTEM ---
  static getMultimedia(clientId?: string): MultimediaRecord[] {
    const data = localStorage.getItem(MULTIMEDIA_KEY);
    let allMedia: MultimediaRecord[] = [];
    if (!data) {
      localStorage.setItem(MULTIMEDIA_KEY, JSON.stringify(INITIAL_MULTIMEDIA));
      allMedia = INITIAL_MULTIMEDIA;
    } else {
      try {
        allMedia = JSON.parse(data);
      } catch {
        allMedia = INITIAL_MULTIMEDIA;
      }
    }

    if (clientId) {
      return allMedia.filter((m) => m.clientId === clientId);
    }
    return allMedia;
  }

  static addMultimedia(record: Omit<MultimediaRecord, 'id' | 'capturedAt'>, actorName = 'User', actorRole: UserRole = 'site_inspector'): MultimediaRecord {
    const mediaList = this.getMultimedia();
    const newRecord: MultimediaRecord = {
      ...record,
      id: generateUniqueId('med'),
      capturedAt: new Date().toISOString()
    };

    mediaList.unshift(newRecord);
    localStorage.setItem(MULTIMEDIA_KEY, JSON.stringify(mediaList));

    // Also link to client object if clientId exists
    if (record.clientId) {
      const clients = this.getClients();
      const client = clients.find((c) => c.id === record.clientId);
      if (client) {
        client.multimedia = client.multimedia || [];
        client.multimedia.unshift(newRecord);
        localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
      }
    }

    this.addAuditLog({
      id: generateUniqueId('log'),
      timestamp: new Date().toISOString(),
      actorName,
      actorRole,
      action: 'MULTIMEDIA_ADDED',
      details: `Recorded ${record.category.toUpperCase()} media: "${record.title}"`,
      clientId: record.clientId
    });

    return newRecord;
  }

  static deleteMultimedia(mediaId: string, actorName = 'Admin'): boolean {
    const mediaList = this.getMultimedia();
    const filtered = mediaList.filter((m) => m.id !== mediaId);
    localStorage.setItem(MULTIMEDIA_KEY, JSON.stringify(filtered));

    this.addAuditLog({
      id: generateUniqueId('log'),
      timestamp: new Date().toISOString(),
      actorName,
      actorRole: 'super_admin',
      action: 'MULTIMEDIA_DELETED',
      details: `Deleted multimedia asset ID ${mediaId}`
    });

    return true;
  }

  // --- PACKAGES & DYNAMIC INFLATION/FOREX CONFIG ---
  static getPackages(): SolarPackage[] {
    const data = localStorage.getItem(PACKAGES_KEY);
    if (!data) {
      localStorage.setItem(PACKAGES_KEY, JSON.stringify(SOLAR_PACKAGES));
      return SOLAR_PACKAGES;
    }
    try {
      const parsed = JSON.parse(data);
      if (!Array.isArray(parsed)) return SOLAR_PACKAGES;
      return SOLAR_PACKAGES.map((canonicalPkg) => {
        const existing = parsed.find((p: any) => p.id === canonicalPkg.id);
        if (!existing) return canonicalPkg;
        return {
          ...canonicalPkg,
          priceMinGMD: existing.priceMinGMD || canonicalPkg.priceMinGMD,
          priceMaxGMD: existing.priceMaxGMD || canonicalPkg.priceMaxGMD,
          priceMinUSD: existing.priceMinUSD || canonicalPkg.priceMinUSD,
          priceMaxUSD: existing.priceMaxUSD || canonicalPkg.priceMaxUSD,
          priceMinGBP: existing.priceMinGBP || canonicalPkg.priceMinGBP,
          priceMaxGBP: existing.priceMaxGBP || canonicalPkg.priceMaxGBP,
        };
      });
    } catch {
      return SOLAR_PACKAGES;
    }
  }

  static savePackage(pkg: SolarPackage, actorName = 'System Admin'): SolarPackage {
    const packages = this.getPackages();
    const idx = packages.findIndex((p) => p.id === pkg.id);
    if (idx >= 0) {
      packages[idx] = pkg;
    } else {
      packages.push(pkg);
    }
    localStorage.setItem(PACKAGES_KEY, JSON.stringify(packages));

    this.addAuditLog({
      id: generateUniqueId('log'),
      timestamp: new Date().toISOString(),
      actorName,
      actorRole: 'super_admin',
      action: 'PACKAGE_PRICING_UPDATED',
      details: `Updated base price for ${pkg.name}: GMD ${pkg.priceMinGMD.toLocaleString()} - ${pkg.priceMaxGMD.toLocaleString()}`
    });

    return pkg;
  }

  static getForexConfig(): ForexInflationConfig {
    const defaultConfig: ForexInflationConfig = {
      usdToGmdRate: 68.5,
      gbpToGmdRate: 85.0,
      globalInflationPercent: 5.0,
      lastUpdated: new Date().toISOString(),
      updatedBy: 'Fortis Central System'
    };

    const data = localStorage.getItem(FOREX_KEY);
    if (!data) {
      localStorage.setItem(FOREX_KEY, JSON.stringify(defaultConfig));
      return defaultConfig;
    }
    try {
      return JSON.parse(data);
    } catch {
      return defaultConfig;
    }
  }

  static saveForexConfig(config: ForexInflationConfig, actorName = 'Finance Officer'): ForexInflationConfig {
    const updated = {
      ...config,
      lastUpdated: new Date().toISOString(),
      updatedBy: actorName
    };
    localStorage.setItem(FOREX_KEY, JSON.stringify(updated));

    this.addAuditLog({
      id: generateUniqueId('log'),
      timestamp: new Date().toISOString(),
      actorName,
      actorRole: 'finance_officer',
      action: 'FOREX_INFLATION_UPDATED',
      details: `Updated Forex & Inflation Index: USD/GMD = ${config.usdToGmdRate}, GBP/GMD = ${config.gbpToGmdRate}, Inflation Buffer = ${config.globalInflationPercent}%`
    });

    return updated;
  }

  // --- TEAMS ---
  static getTeams(): Team[] {
    const data = localStorage.getItem(TEAMS_KEY);
    if (!data) {
      localStorage.setItem(TEAMS_KEY, JSON.stringify(INITIAL_TEAMS));
      return INITIAL_TEAMS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_TEAMS;
    }
  }

  static getTeamById(id: string): Team | undefined {
    return this.getTeams().find((t) => t.id === id);
  }

  static saveTeam(team: Team): Team {
    const teams = this.getTeams();
    const existingIndex = teams.findIndex((t) => t.id === team.id);
    if (existingIndex >= 0) {
      teams[existingIndex] = team;
    } else {
      teams.push(team);
    }
    localStorage.setItem(TEAMS_KEY, JSON.stringify(teams));
    return team;
  }
}
