/**
 * UK GDPR & The Gambia Data Protection and Privacy Act Compliance Engine
 * Enforces strict multi-tenant isolation (GTUCCU vs NAGNMC) and role-based data minimization.
 * Complies with:
 * - UK Data Protection Act 2018 / UK GDPR (Articles 5, 6, 25, 32)
 * - The Gambia Data Protection and Privacy Act / ICPA Regulatory Directives (Sections 12, 24, 31)
 */

import { UserRole, Client, InstitutionalMember } from '../types';

export interface GDPRConsent {
  accepted: boolean;
  timestamp: string;
  policyVersion: string;
  jurisdictions: ('UK_GDPR' | 'GAMBIA_DPPA')[];
}

export interface DataComplianceScope {
  role: UserRole;
  institutionId?: string;
  canViewSalaries: boolean;
  canViewBankAccounts: boolean;
  canViewRoofEngineering: boolean;
  canViewAllClients: boolean;
  isolationBoundary: string;
  legalBasis: string;
}

/**
 * Determine legal basis & data processing scope for role under UK & Gambia Data Laws
 */
export function getDataComplianceScope(role: UserRole, institutionId?: string): DataComplianceScope {
  switch (role) {
    case 'institutional_admin': {
      const union = (institutionId || 'GTUCCU').toUpperCase();
      return {
        role,
        institutionId: union,
        canViewSalaries: true,
        canViewBankAccounts: false,
        canViewRoofEngineering: false,
        canViewAllClients: false,
        isolationBoundary: `Strict Tenant Isolation: ${union} Registry Only`,
        legalBasis: `Contract Performance & Union Bylaws (UK GDPR Art 6(1)(b) / Gambia DPPA Sec 12)`
      };
    }
    case 'site_inspector':
      return {
        role,
        canViewSalaries: false,
        canViewBankAccounts: false,
        canViewRoofEngineering: true,
        canViewAllClients: false,
        isolationBoundary: 'Assessment Pipeline & Technical Survey Metadata Only (Financials Redacted)',
        legalBasis: 'Legitimate Operations for Technical Site Feasibility (UK GDPR Art 6(1)(f))'
      };
    case 'installer':
      return {
        role,
        canViewSalaries: false,
        canViewBankAccounts: false,
        canViewRoofEngineering: true,
        canViewAllClients: false,
        isolationBoundary: 'Installation & Commissioning Work Orders Only (Financials Redacted)',
        legalBasis: 'Service Delivery & Electrical Installation Safety (UK GDPR Art 6(1)(b))'
      };
    case 'finance_officer':
      return {
        role,
        canViewSalaries: true,
        canViewBankAccounts: true,
        canViewRoofEngineering: false,
        canViewAllClients: true,
        isolationBoundary: 'Financial Audit, Invoicing & Ecobank Reconciliation Ledger',
        legalBasis: 'Statutory Financial & Tax Accounting (UK GDPR Art 6(1)(c) / Gambia DPPA Sec 31)'
      };
    case 'client':
      return {
        role,
        canViewSalaries: false,
        canViewBankAccounts: false,
        canViewRoofEngineering: true,
        canViewAllClients: false,
        isolationBoundary: 'Strict Single-Tenant Data Subject Profile Only',
        legalBasis: 'Data Subject Consent & Direct Contract (UK GDPR Art 6(1)(a)/(b))'
      };
    case 'super_admin':
    case 'project_manager':
    default:
      return {
        role,
        canViewSalaries: true,
        canViewBankAccounts: true,
        canViewRoofEngineering: true,
        canViewAllClients: true,
        isolationBoundary: 'Comprehensive Platform Controller (Full Immutable Audit Logging)',
        legalBasis: 'Executive Governance & Cross-Border Compliance Oversight'
      };
  }
}

/**
 * Mask Phone numbers (e.g., "+220 7712345" -> "+220 7****45")
 */
export function maskPhone(phone: string | undefined): string {
  if (!phone) return 'N/A';
  const clean = phone.trim();
  if (clean.length <= 4) return '****';
  const start = clean.slice(0, 5);
  const end = clean.slice(-2);
  return `${start}****${end}`;
}

/**
 * Mask Email address (e.g., "diaspora.client@gmail.com" -> "d****t@gmail.com")
 */
export function maskEmail(email: string | undefined): string {
  if (!email) return 'N/A';
  const parts = email.split('@');
  if (parts.length !== 2) return '****@****';
  const username = parts[0];
  const domain = parts[1];

  if (username.length <= 2) {
    return `${username[0]}*@${domain}`;
  }
  const start = username[0];
  const end = username[username.length - 1];
  return `${start}****${end}@${domain}`;
}

/**
 * Mask National ID or Member Identification
 */
export function maskMemberID(id: string | undefined): string {
  if (!id) return 'N/A';
  if (id.length <= 3) return '***';
  return `${id.slice(0, 2)}****${id.slice(-2)}`;
}

/**
 * Mask Home / Property Street Address under GDPR
 */
export function maskAddress(address: string | undefined): string {
  if (!address) return 'N/A';
  const parts = address.split(',');
  if (parts.length > 1) {
    return `${parts[0].trim()} (Detailed street redacted under UK GDPR / Gambia DPPA)`;
  }
  return `${address.slice(0, 8)}... (Redacted)`;
}

/**
 * Mask Sensitive Financial Salary (for Site Inspectors, Field Engineers & non-authorized roles)
 */
export function maskSalaryOrCredit(amountGMD: number, isAuthorized: boolean): string {
  if (!isAuthorized) {
    return '*** GMD [Redacted - Data Minimization]';
  }
  return `GMD ${amountGMD.toLocaleString()}`;
}

/**
 * GDPR Redacted Financial Amount placeholder for Union Admin views
 */
export function formatGDPRFinancial(isUnionAdmin: boolean, formattedAmount: string): string {
  if (isUnionAdmin) {
    return '*** GMD (Restricted to Designated Union Members)';
  }
  return formattedAmount;
}

/**
 * Verify whether an institutional admin is authorized to query an institution
 */
export function canAccessInstitution(
  actorRole: UserRole,
  actorInstitution: string | undefined,
  targetInstitution: string
): boolean {
  if (actorRole === 'super_admin' || actorRole === 'project_manager' || actorRole === 'finance_officer') {
    return true;
  }
  if (actorRole === 'institutional_admin') {
    const actorInst = (actorInstitution || 'GTUCCU').trim().toUpperCase();
    const targetInst = targetInstitution.trim().toUpperCase();
    return actorInst === targetInst;
  }
  return false;
}

