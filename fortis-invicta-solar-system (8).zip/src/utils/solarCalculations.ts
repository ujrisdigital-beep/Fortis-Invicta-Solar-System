/**
 * FORTIS INVICTA SOLAR - DETERMINISTIC LOAD & SIZING ENGINE
 * Standard IEEE / IEC Photovoltaic & Motor Surge Sizing Mathematics for The Gambia
 */

export interface LoadItem {
  id: string;
  name: string;
  category: 'lighting_electronic' | 'refrigeration' | 'cooling_aircon' | 'agricultural_pump' | 'biochar_processing' | 'custom';
  nominalWatts: number;
  quantity: number;
  surgeMultiplier: number;
  operatingHoursPerDay: number;
  daytimeUsagePercent: number; // % of usage during peak solar hours (09:00 - 16:00)
}

export const CALCULATION_ENGINE_VERSION = 'v1.0.0';

export interface SolarLoadAnalysisResult {
  engineVersion: string;
  totalConnectedWatts: number;
  continuousPowerKW: number;
  continuousInverterKVA: number;
  maxIndividualSurgeWatts: number;
  totalSurgePeakKW: number;
  recommendedInverterSurgeKVA: number;
  dailyEnergyConsumptionKWh: number;
  daytimeEnergyKWh: number;
  nighttimeEnergyKWh: number;
  recommendedBatteryKWh: number;
  recommendedBatteryAh48V: number;
  recommendedPVArrayKWp: number;
  recommendedPanels550W: number;
  recommendedPackageId: 'basic_backup' | 'hybrid_standard' | 'executive_premium' | 'commercial_heavy';
  recommendedPackageName: string;
  estimatedPriceMinGMD: number;
  estimatedPriceMaxGMD: number;
  gambianGridStabilityNote: string;
  motorSurgeWarning?: string;
}

export const PRESET_APPLIANCES: Array<Omit<LoadItem, 'id'>> = [
  // 1. Lighting & Low Power Electronics (Surge = 1.0x - 1.2x)
  {
    name: 'LED Tube & Bulb Lighting (10W)',
    category: 'lighting_electronic',
    nominalWatts: 10,
    quantity: 12,
    surgeMultiplier: 1.0,
    operatingHoursPerDay: 6,
    daytimeUsagePercent: 10
  },
  {
    name: 'Smart TV & Satellite Decoder (120W)',
    category: 'lighting_electronic',
    nominalWatts: 120,
    quantity: 1,
    surgeMultiplier: 1.2,
    operatingHoursPerDay: 8,
    daytimeUsagePercent: 30
  },
  {
    name: 'Ceiling Fan (75W)',
    category: 'lighting_electronic',
    nominalWatts: 75,
    quantity: 4,
    surgeMultiplier: 1.5,
    operatingHoursPerDay: 12,
    daytimeUsagePercent: 50
  },
  // 2. Domestic Refrigeration (Surge = 3.0x - 3.5x)
  {
    name: 'Chest Deep Freezer (250W Inverter)',
    category: 'refrigeration',
    nominalWatts: 250,
    quantity: 1,
    surgeMultiplier: 3.2,
    operatingHoursPerDay: 24,
    daytimeUsagePercent: 50
  },
  // 3. Air Conditioning (Surge = 4.0x - 5.0x)
  {
    name: '1.5 HP Inverter Air Conditioner (1200W)',
    category: 'cooling_aircon',
    nominalWatts: 1200,
    quantity: 1,
    surgeMultiplier: 4.0,
    operatingHoursPerDay: 8,
    daytimeUsagePercent: 40
  },
  // 4. Agricultural Water Pumping (Surge = 5.0x - 6.0x)
  {
    name: '1.0 HP Submersible Borehole Pump (750W)',
    category: 'agricultural_pump',
    nominalWatts: 750,
    quantity: 1,
    surgeMultiplier: 5.5,
    operatingHoursPerDay: 4,
    daytimeUsagePercent: 80
  },
  // 5. Biochar & Heavy Machinery (Surge = 5.5x - 6.5x)
  {
    name: 'Biochar Biomass Extruder / Chopper (3.0kW)',
    category: 'biochar_processing',
    nominalWatts: 3000,
    quantity: 1,
    surgeMultiplier: 6.0,
    operatingHoursPerDay: 3,
    daytimeUsagePercent: 90
  }
];

/**
 * Standard Gambian Solar Constant Parameters:
 * - Peak Sun Hours (PSH): 5.4 kWh/m²/day (Annual average across Greater Banjul, West Coast, and Central River Region)
 * - Tropical Temperature Derating & Soiling PR: 0.78 (accounting for Harmattan dust & 38°C ambient heat)
 * - LiFePO4 Battery Usable Depth of Discharge (DoD): 85%
 * - Inverter / Battery Round-Trip Efficiency: 90%
 * - Inverter Power Factor: 0.85 (cos φ)
 */
export function calculateSolarLoadRequirements(
  loads: LoadItem[],
  customOptions?: {
    autonomyDays?: number;
    diversityFactor?: number;
    powerFactor?: number;
    batteryType?: 'lifepo4' | 'gel_agm';
    peakSunHours?: number;
  }
): SolarLoadAnalysisResult {
  const options = {
    autonomyDays: 1.0,
    diversityFactor: 0.80,
    powerFactor: 0.85,
    batteryType: 'lifepo4',
    peakSunHours: 5.4,
    ...customOptions
  };

  if (loads.length === 0) {
    return {
      engineVersion: CALCULATION_ENGINE_VERSION,
      totalConnectedWatts: 0,
      continuousPowerKW: 0,
      continuousInverterKVA: 0,
      maxIndividualSurgeWatts: 0,
      totalSurgePeakKW: 0,
      recommendedInverterSurgeKVA: 0,
      dailyEnergyConsumptionKWh: 0,
      daytimeEnergyKWh: 0,
      nighttimeEnergyKWh: 0,
      recommendedBatteryKWh: 0,
      recommendedBatteryAh48V: 0,
      recommendedPVArrayKWp: 0,
      recommendedPanels550W: 0,
      recommendedPackageId: 'basic_backup',
      recommendedPackageName: 'Tier 1: Basic Back-Up (1.5 kVA)',
      estimatedPriceMinGMD: 90000,
      estimatedPriceMaxGMD: 110000,
      gambianGridStabilityNote: 'Zero load entered.'
    };
  }

  // 1. Continuous Connected Watts
  let totalConnectedWatts = 0;
  let maxIndividualSurgeWatts = 0;
  let totalSurgeWattsCombined = 0;
  let dailyEnergyWh = 0;
  let daytimeEnergyWh = 0;
  let hasHeavyInductiveMotor = false;

  loads.forEach((item) => {
    const itemNominalTotal = item.nominalWatts * item.quantity;
    totalConnectedWatts += itemNominalTotal;

    const itemSurgeWatts = item.nominalWatts * item.surgeMultiplier;
    if (itemSurgeWatts > maxIndividualSurgeWatts) {
      maxIndividualSurgeWatts = itemSurgeWatts;
    }

    if (item.category === 'agricultural_pump' || item.category === 'biochar_processing' || item.surgeMultiplier >= 4.0) {
      hasHeavyInductiveMotor = true;
    }

    // Daily energy in Watt-hours
    const itemDailyWh = itemNominalTotal * item.operatingHoursPerDay;
    dailyEnergyWh += itemDailyWh;
    daytimeEnergyWh += itemDailyWh * (item.daytimeUsagePercent / 100);
  });

  // 2. Realistic Continuous Inverter Demand with Diversity Factor
  const continuousPowerKW = Number(((totalConnectedWatts * options.diversityFactor) / 1000).toFixed(2));
  const continuousInverterKVA = Number((continuousPowerKW / options.powerFactor).toFixed(2));

  // 3. Surge Inverter Sizing
  // Standard rule: Inverter must sustain largest motor starting surge + nominal running power of remaining loads
  const remainingRunningWatts = (totalConnectedWatts - (maxIndividualSurgeWatts / 4.0)) * 0.7;
  const totalSurgePeakKW = Number(((maxIndividualSurgeWatts + Math.max(0, remainingRunningWatts)) / 1000).toFixed(2));
  const recommendedInverterSurgeKVA = Number((totalSurgePeakKW / options.powerFactor).toFixed(2));

  // 4. Energy Consumption
  const dailyEnergyConsumptionKWh = Number((dailyEnergyWh / 1000).toFixed(2));
  const daytimeEnergyKWh = Number((daytimeEnergyWh / 1000).toFixed(2));
  const nighttimeEnergyKWh = Number((Math.max(0, dailyEnergyWh - daytimeEnergyWh) / 1000).toFixed(2));

  // 5. Battery Sizing
  const dod = options.batteryType === 'lifepo4' ? 0.85 : 0.50;
  const efficiency = 0.90; // Inverter/Battery combined efficiency
  const requiredBatteryKWh = Number(((nighttimeEnergyKWh * options.autonomyDays) / (dod * efficiency)).toFixed(2));
  const batteryAh48V = Math.round((requiredBatteryKWh * 1000) / 48);

  // 6. Solar PV Array Sizing
  const performanceRatio = 0.78; // Tropical Gambian PR
  const requiredPVArrayKWp = Number((dailyEnergyConsumptionKWh / (options.peakSunHours * performanceRatio)).toFixed(2));
  const recommendedPanels550W = Math.max(2, Math.ceil((requiredPVArrayKWp * 1000) / 550));

  // 7. Deterministic Package Mapping
  let packageId: 'basic_backup' | 'hybrid_standard' | 'executive_premium' | 'commercial_heavy' = 'basic_backup';
  let packageName = 'Tier 1: Basic Back-Up (1.5 kVA)';
  let priceMin = 90000;
  let priceMax = 110000;

  if (continuousInverterKVA > 7.5 || recommendedInverterSurgeKVA > 14.0 || dailyEnergyConsumptionKWh > 25.0) {
    packageId = 'commercial_heavy';
    packageName = 'Tier 4: Commercial / Enterprise (10 kVA / 15 kVA 3-Phase)';
    priceMin = 880000;
    priceMax = 1220000;
  } else if (continuousInverterKVA > 3.2 || recommendedInverterSurgeKVA > 6.0 || dailyEnergyConsumptionKWh > 12.0) {
    packageId = 'executive_premium';
    packageName = 'Tier 3: Executive Premium (5.5 kVA)';
    priceMin = 500000;
    priceMax = 670000;
  } else if (continuousInverterKVA > 1.2 || recommendedInverterSurgeKVA > 2.5 || dailyEnergyConsumptionKWh > 5.0) {
    packageId = 'hybrid_standard';
    packageName = 'Tier 2: Hybrid Standard (3.5 kVA)';
    priceMin = 280000;
    priceMax = 360000;
  }

  let motorSurgeWarning: string | undefined;
  if (hasHeavyInductiveMotor) {
    motorSurgeWarning = `High inductive motor load detected (Surge Peak: ${totalSurgePeakKW}kW / ${recommendedInverterSurgeKVA}kVA). A heavy-duty low-frequency copper transformer inverter or soft-starter is required for pump/biochar machinery startup.`;
  }

  const gridNote = `Calculated for NAWEC grid backup in The Gambia with ${options.peakSunHours} Peak Sun Hours (PSH) and ${requiredBatteryKWh}kWh nighttime autonomy.`;

  return {
    engineVersion: CALCULATION_ENGINE_VERSION,
    totalConnectedWatts,
    continuousPowerKW,
    continuousInverterKVA,
    maxIndividualSurgeWatts,
    totalSurgePeakKW,
    recommendedInverterSurgeKVA,
    dailyEnergyConsumptionKWh,
    daytimeEnergyKWh,
    nighttimeEnergyKWh,
    recommendedBatteryKWh: requiredBatteryKWh,
    recommendedBatteryAh48V: batteryAh48V,
    recommendedPVArrayKWp: requiredPVArrayKWp,
    recommendedPanels550W,
    recommendedPackageId: packageId,
    recommendedPackageName: packageName,
    estimatedPriceMinGMD: priceMin,
    estimatedPriceMaxGMD: priceMax,
    gambianGridStabilityNote: gridNote,
    motorSurgeWarning
  };
}

/**
 * Format deterministic solar engineering report
 */
export function formatSolarEngineeringReport(result: SolarLoadAnalysisResult): string {
  return `=== FORTIS INVICTA DETERMINISTIC SOLAR AUDIT REPORT ===
• Continuous Power: ${result.continuousPowerKW} kW (${result.continuousInverterKVA} kVA @ 0.85 PF)
• Motor Surge Peak Capacity: ${result.totalSurgePeakKW} kW (${result.recommendedInverterSurgeKVA} kVA Peak Surge)
• Daily Energy: ${result.dailyEnergyConsumptionKWh} kWh/day (Daytime: ${result.daytimeEnergyKWh} kWh | Nighttime: ${result.nighttimeEnergyKWh} kWh)
• Recommended Battery Storage: ${result.recommendedBatteryKWh} kWh (LiFePO4 ~${result.recommendedBatteryAh48V} Ah @ 48V)
• Recommended Solar Array: ${result.recommendedPVArrayKWp} kWp (${result.recommendedPanels550W} x 550W Monocrystalline Tier-1 Panels)
• Matched Package: ${result.recommendedPackageName}
• Cost Estimate: GMD ${result.estimatedPriceMinGMD.toLocaleString()} - GMD ${result.estimatedPriceMaxGMD.toLocaleString()}
${result.motorSurgeWarning ? `\n⚠️ MOTOR SURGE ALERT: ${result.motorSurgeWarning}` : ''}`;
}

export const calculateSolarRequirements = calculateSolarLoadRequirements;

