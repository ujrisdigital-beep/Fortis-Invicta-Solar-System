/**
 * Disposable & Temporary Email Domain Detection Utility
 * Blocks all known temp mail, disposable inbox providers, and burner domains.
 */

export const DISPOSABLE_EMAIL_DOMAINS = new Set([
  // Popular Disposable Mail Services
  'mailinator.com',
  'tempmail.com',
  'temp-mail.org',
  '10minutemail.com',
  '10minutemail.net',
  'guerrillamail.com',
  'guerrillamail.info',
  'guerrillamail.biz',
  'guerrillamail.de',
  'guerrillamail.net',
  'guerrillamail.org',
  'guerrillamailblock.com',
  'sharklasers.com',
  'grr.la',
  'yopmail.com',
  'yopmail.fr',
  'yopmail.net',
  'trashmail.com',
  'trashmail.net',
  'trashmail.me',
  'dispostable.com',
  'throwawaymail.com',
  'fakemailgenerator.com',
  'getnada.com',
  'inboxkitten.com',
  'mohmal.com',
  'burnermail.io',
  'crazymailing.com',
  'mytemp.email',
  'generator.email',
  'emailondeck.com',
  'dropmail.me',
  'clipmail.eu',
  'tempmailaddress.com',
  '10mail.org',
  'maildrop.cc',
  'zoemail.org',
  'armyspy.com',
  'cuvox.de',
  'dayrep.com',
  'einrot.com',
  'fleckens.hu',
  'gustr.com',
  'jourrapide.com',
  'rhyta.com',
  'superrito.com',
  'teleworm.us',
  'tempinbox.com',
  'tmpmail.org',
  'fakemail.net',
  'trashmail.org',
  'throwaway.email',
  'trash-mail.at',
  'trash-mail.com',
  'trash-mail.ch',
  'fakeinbox.com',
  'discard.email',
  'discardmail.com',
  'spambog.com',
  'instantemailaddress.com',
  'tempmail.net',
  'getairmail.com',
  'nada.ltd',
  'inboxbear.com',
  'spamgourmet.com',
  'trashcanmail.com',
  'mailcatch.com',
  'jetable.org',
  'kasmail.com',
  'binkmail.com',
  'bobmail.info',
  'chammy.info',
  'devnullmail.com',
  'letthemeatspam.com',
  'mailin8r.com',
  'mailinator2.com',
  'notmailinator.com',
  'reallymymail.com',
  'reconmail.com',
  'safetymail.info',
  'sendspamhere.com',
  'sogetthis.com',
  'spambooger.com',
  'spamherelots.com',
  'spamhereplease.com',
  'streetwisemail.com',
  'suremail.info',
  'thisisnotmyrealemail.com',
  'tradermail.info',
  'veryrealemail.com',
  'zippymail.info'
]);

// Pattern regex for dynamically generated disposable subdomains
const DISPOSABLE_PATTERNS = [
  /temp.*mail/i,
  /throw.*away/i,
  /disposable/i,
  /fake.*mail/i,
  /trash.*mail/i,
  /guerrilla.*mail/i,
  /burner.*mail/i,
  /spam.*box/i,
  /instant.*mail/i,
  /anon.*mail/i,
  /sharklasers/i,
  /yopmail/i,
  /mailinator/i,
  /mohmal/i,
  /dropmail/i
];

/**
 * Validates whether an email address belongs to a disposable or temporary mail service.
 * @param email - The email string to validate
 * @returns Object with isValid boolean and error reason if disposable
 */
export function isDisposableEmail(email: string): { isDisposable: boolean; reason?: string } {
  if (!email || typeof email !== 'string') {
    return { isDisposable: true, reason: 'Invalid email format' };
  }

  const clean = email.trim().toLowerCase();
  const parts = clean.split('@');
  if (parts.length !== 2) {
    return { isDisposable: true, reason: 'Invalid email address structure' };
  }

  const domain = parts[1];

  // 1. Direct domain lookup in static blacklist
  if (DISPOSABLE_EMAIL_DOMAINS.has(domain)) {
    return {
      isDisposable: true,
      reason: `The domain "${domain}" is identified as a temporary/disposable email provider and is blocked.`
    };
  }

  // 2. Subdomain check (e.g. *.mailinator.com)
  for (const blockedDomain of DISPOSABLE_EMAIL_DOMAINS) {
    if (domain.endsWith('.' + blockedDomain)) {
      return {
        isDisposable: true,
        reason: `Subdomain of disposable mail provider "${blockedDomain}" is blocked.`
      };
    }
  }

  // 3. Heuristic pattern checks
  for (const pattern of DISPOSABLE_PATTERNS) {
    if (pattern.test(domain)) {
      return {
        isDisposable: true,
        reason: `Domain "${domain}" matches temporary email provider patterns and is blocked.`
      };
    }
  }

  return { isDisposable: false };
}
