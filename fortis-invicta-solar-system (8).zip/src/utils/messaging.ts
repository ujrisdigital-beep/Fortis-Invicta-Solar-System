import { Client, MessageLog } from '../types';
import { StorageService } from '../services/storage';

export type MessageChannel = 'whatsapp' | 'email' | 'sms';
export type TemplateType = 'onboarding' | 'inspection' | 'payment_reminder' | 'stage_update' | 'custom';

export interface NotificationMessage {
  subject?: string;
  body: string;
}

/**
 * Format phone numbers for WhatsApp / SMS dispatches in Gambia (+220) and worldwide.
 */
export function cleanPhoneNumber(phone: string): string {
  let cleaned = phone.replace(/[^0-9]/g, '');
  // Default to Gambia (+220) if country code is omitted and length is 7 digits
  if (cleaned.length === 7) {
    cleaned = '220' + cleaned;
  }
  return cleaned;
}

/**
 * Generate standard message templates tailored for Fortis Invicta Gambia operations.
 */
export function generateMessageTemplate(
  templateType: TemplateType,
  client: Partial<Client>,
  customNote?: string
): NotificationMessage {
  const name = client.fullName || 'Valued Client';
  const pkg = (client.packageId || 'Solar System').replace('_', ' ').toUpperCase();
  const quote = client.totalQuotedGMD ? `GMD ${client.totalQuotedGMD.toLocaleString()}` : '';
  const balance = client.outstandingBalanceGMD ? `GMD ${client.outstandingBalanceGMD.toLocaleString()}` : '';

  switch (templateType) {
    case 'onboarding':
      return {
        subject: `Welcome to Fortis Invicta Solar — Application Received (${name})`,
        body: `Greetings ${name},\n\nThank you for choosing Fortis Invicta Ltd for your ${pkg} installation! Your application has been successfully logged into our system.\n\nQuote Summary: ${quote}\nPayment Plan: ${client.financingType ? client.financingType.replace('_', ' ') : 'Salary Deduction'}\n\nOur team is reviewing your documents and will schedule a site assessment shortly.\n\nFor inquiries, reply to this message or visit our office.\n\nWarm regards,\nFortis Invicta Solar Team\nEcobank Merchant Code: 505825057`
      };

    case 'inspection':
      return {
        subject: `Fortis Invicta — Site Assessment Scheduled for ${name}`,
        body: `Hello ${name},\n\nA site inspection for your ${pkg} project has been scheduled by Fortis Invicta Field Crew.\n\nAddress: ${client.address || 'Your registered location'}\nField Inspector Note: ${customNote || 'Please ensure roof access and an adult representative are available.'}\n\nThank you for choosing Fortis Invicta Solar!`
      };

    case 'payment_reminder':
      return {
        subject: `Fortis Invicta — Payment Notice for ${name}`,
        body: `Hello ${name},\n\nThis is a friendly payment notice regarding your Fortis Invicta Solar project.\n\nOutstanding Balance: ${balance}\nEcobank Merchant Code: 505825057 | Terminal ID: 32680928\nAccount Name: Fortis Invicta Ltd\n\nPlease submit your bank teller deposit receipt or GTUCCU/NAGNMC pay-slip proof to proceed to the next installation phase.\n\nThank you!`
      };

    case 'stage_update':
      return {
        subject: `Fortis Invicta — Project Status Update: ${name}`,
        body: `Dear ${name},\n\nGreat news! Your ${pkg} solar installation project has progressed to stage: ${(client.projectStage || '').replace(/_/g, ' ').toUpperCase()}.\n\nNext Step: ${customNote || 'Our crew is preparing equipment for dispatch.'}\n\nThank you for trusting Fortis Invicta Ltd!`
      };

    case 'custom':
    default:
      return {
        subject: `Update from Fortis Invicta Ltd for ${name}`,
        body: customNote || `Dear ${name},\n\nThank you for partnering with Fortis Invicta Ltd on your solar journey.`
      };
  }
}

/**
 * Dispatch message via zero-cost native protocols (WhatsApp, SMS, Email) and log to audit history.
 */
export function dispatchNotification(
  channel: MessageChannel,
  templateType: TemplateType,
  client: Client,
  customNote?: string,
  actorName: string = 'System Admin'
): { success: boolean; link: string } {
  const message = generateMessageTemplate(templateType, client, customNote);
  const rawPhone = client.phone || '';
  const cleanedPhone = cleanPhoneNumber(rawPhone);
  const email = client.email || '';

  let link = '';

  if (channel === 'whatsapp') {
    const encodedText = encodeURIComponent(message.body);
    // wa.me format works seamlessly on desktop, iPad, and mobile
    link = `https://wa.me/${cleanedPhone}?text=${encodedText}`;
  } else if (channel === 'sms') {
    const encodedBody = encodeURIComponent(message.body);
    // Universal sms format compatible across iOS, Android, and macOS/Windows messaging apps
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    link = `sms:${cleanedPhone}${isIOS ? '&' : '?'}body=${encodedBody}`;
  } else if (channel === 'email') {
    const encodedSubject = encodeURIComponent(message.subject || 'Fortis Invicta Solar Notice');
    const encodedBody = encodeURIComponent(message.body);
    link = `mailto:${email}?subject=${encodedSubject}&body=${encodedBody}`;
  }

  // Open protocol window safely
  if (link) {
    window.open(link, '_blank', 'noopener,noreferrer');
  }

  // Record dispatch in client messaging log and central audit log
  const messageLog: MessageLog = {
    id: 'msg-' + Date.now(),
    clientId: client.id,
    channel,
    templateType,
    recipient: channel === 'email' ? email : rawPhone,
    messageText: message.body,
    sentAt: new Date().toISOString(),
    sentBy: actorName
  };

  const currentHistory = client.messageHistory || [];
  const updatedClient: Client = {
    ...client,
    messageHistory: [messageLog, ...currentHistory],
    updatedAt: new Date().toISOString()
  };

  StorageService.saveClient(updatedClient);

  StorageService.addAuditLog({
    id: 'log-' + Date.now(),
    timestamp: new Date().toISOString(),
    actorName,
    actorRole: 'project_manager',
    action: 'MESSAGE_DISPATCHED',
    details: `Dispatched ${channel.toUpperCase()} (${templateType}) notice to ${client.fullName} (${channel === 'email' ? email : rawPhone})`
  });

  return { success: true, link };
}
