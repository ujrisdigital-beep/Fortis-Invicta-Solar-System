import { Currency } from '../types';

// Exchange rates relative to GMD
const GMD_TO_USD = 0.015;  // 1 GMD = 0.015 USD ($1 = ~66.7 GMD)
const GMD_TO_GBP = 0.012;  // 1 GMD = 0.012 GBP (£1 = ~83.3 GMD)

export function formatCurrency(amountGMD: number, targetCurrency: Currency = 'GMD'): string {
  if (targetCurrency === 'USD') {
    const usd = amountGMD * GMD_TO_USD;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(usd);
  }

  if (targetCurrency === 'GBP') {
    const gbp = amountGMD * GMD_TO_GBP;
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0
    }).format(gbp);
  }

  return `GMD ${Math.round(amountGMD).toLocaleString()}`;
}

export function formatPriceRange(minGMD: number, maxGMD: number, targetCurrency: Currency = 'GMD'): string {
  const formattedMin = formatCurrency(minGMD, targetCurrency);
  const formattedMax = formatCurrency(maxGMD, targetCurrency);
  return `${formattedMin} – ${formattedMax}`;
}

export function getSegmentBadge(segment: string) {
  switch (segment) {
    case 'gtuccu_member':
      return { label: 'GTUCCU Member', color: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
    case 'nagnmc_member':
      return { label: 'NAGNMC Healthcare', color: 'bg-teal-100 text-teal-800 border-teal-300' };
    case 'diaspora':
      return { label: 'Diaspora Client', color: 'bg-amber-100 text-amber-800 border-amber-300' };
    case 'non_union_individual':
      return { label: 'Non-Union Individual', color: 'bg-slate-100 text-slate-800 border-slate-300' };
    default:
      return { label: segment, color: 'bg-gray-100 text-gray-800 border-gray-300' };
  }
}

export function getStageLabel(stage: string): string {
  switch (stage) {
    case 'lead':
      return '1. Lead Received';
    case 'assessment_scheduled':
      return '2. Assessment Scheduled';
    case 'assessment_complete':
      return '3. Assessment Complete';
    case 'payment_pending':
      return '4. Payment Pending';
    case 'installation_scheduled':
      return '5. Installation Scheduled';
    case 'installation_in_progress':
      return '6. Installation In Progress';
    case 'commissioning':
      return '7. Commissioning';
    case 'completed':
      return '8. Completed & Monitoring';
    default:
      return stage;
  }
}

export function getStageColor(stage: string): string {
  switch (stage) {
    case 'lead':
      return 'bg-slate-100 text-slate-700 border-slate-200';
    case 'assessment_scheduled':
      return 'bg-blue-50 text-blue-700 border-blue-200';
    case 'assessment_complete':
      return 'bg-indigo-50 text-indigo-700 border-indigo-200';
    case 'payment_pending':
      return 'bg-amber-50 text-amber-800 border-amber-300';
    case 'installation_scheduled':
      return 'bg-cyan-50 text-cyan-800 border-cyan-200';
    case 'installation_in_progress':
      return 'bg-purple-50 text-purple-800 border-purple-200';
    case 'commissioning':
      return 'bg-orange-50 text-orange-800 border-orange-200';
    case 'completed':
      return 'bg-emerald-50 text-emerald-800 border-emerald-300';
    default:
      return 'bg-gray-100 text-gray-700 border-gray-200';
  }
}

export function getPaymentStatusBadge(status: string) {
  switch (status) {
    case 'confirmed':
      return { label: 'Paid / Confirmed', color: 'bg-emerald-600 text-white' };
    case 'partially_paid':
      return { label: 'Deposit Paid (Partial)', color: 'bg-blue-600 text-white' };
    case 'confirmation_required':
      return { label: 'Verify Teller Slip', color: 'bg-amber-500 text-white animate-pulse' };
    case 'pending':
      return { label: 'Awaiting Transfer', color: 'bg-slate-500 text-white' };
    case 'overdue':
      return { label: 'Overdue Payment', color: 'bg-rose-600 text-white' };
    default:
      return { label: status, color: 'bg-gray-500 text-white' };
  }
}
