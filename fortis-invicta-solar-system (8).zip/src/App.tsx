import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DashboardView } from './components/Dashboard/DashboardView';
import { ClientTable } from './components/ClientManagement/ClientTable';
import { ClientDetailModal } from './components/ClientManagement/ClientDetailModal';
import { KanbanBoard } from './components/Kanban/KanbanBoard';
import { PaymentModule } from './components/Payments/PaymentModule';
import { InstitutionalModule } from './components/Institutional/InstitutionalModule';
import { SiteAssessmentModule } from './components/Assessment/SiteAssessmentModule';
import { InstallationHub } from './components/Installation/InstallationHub';
import { ReportsModule } from './components/Reports/ReportsModule';
import { ClientPortalView } from './components/ClientPortal/ClientPortalView';
import { PublicOnboardingForm } from './components/Onboarding/PublicOnboardingForm';
import { SolarAIAssistant } from './components/AIAssistant/SolarAIAssistant';
import { RepaymentCalculator } from './components/Calculator/RepaymentCalculator';
import { MultimediaManager } from './components/Multimedia/MultimediaManager';
import { InflationForexPanel } from './components/Settings/InflationForexPanel';
import { AuthScreen } from './components/Auth/AuthScreen';
import { FortisLogo } from './components/FortisLogo';

import {
  Client,
  Currency,
  PaymentRecord,
  AssessmentReport,
  InstallationLog,
  InstitutionalMember,
  AuditLogItem,
  UserRole,
  ProjectStage
} from './types';
import { StorageService } from './services/storage';
import { useAuth } from './services/authContext';

export default function App() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [currency, setCurrency] = useState<Currency>('GMD');
  const [currentRole, setCurrentRole] = useState<UserRole>(user?.role || 'super_admin');
  const [isGdprActive, setIsGdprActive] = useState<boolean>(true);
  const [selectedUnionId, setSelectedUnionId] = useState<string>(user?.institutionId || 'GTUCCU');

  // Auto-sync currentRole and institutionId when authenticated user changes
  useEffect(() => {
    if (user && user.role) {
      setCurrentRole(user.role);
      if (user.institutionId) {
        setSelectedUnionId(user.institutionId);
      }
      if (user.role === 'client') {
        setActiveTab('client_portal');
      }
    }
  }, [user]);

  // Live Data State
  const [clients, setClients] = useState<Client[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [assessments, setAssessments] = useState<AssessmentReport[]>([]);
  const [installations, setInstallations] = useState<InstallationLog[]>([]);
  const [members, setMembers] = useState<InstitutionalMember[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);

  // Modals & Drawers
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [isAIOpen, setIsAIOpen] = useState<boolean>(false);

  const refreshData = (role: UserRole = currentRole, unionId: string = selectedUnionId) => {
    const userClientId = role === 'client' ? (user?.id || 'cli-001') : undefined;
    setClients(StorageService.getClientsForRole(role, userClientId, unionId));
    setPayments(StorageService.getPaymentsForRole(role, userClientId, unionId));
    setAssessments(StorageService.getAssessmentsForRole(role, userClientId, unionId));
    setInstallations(StorageService.getInstallationsForRole(role, userClientId, unionId));
    setMembers(StorageService.getInstitutionalMembersForRole(role, unionId));
    setAuditLogs(StorageService.getAuditLogs());
  };

  useEffect(() => {
    if (isAuthenticated && user) {
      refreshData(currentRole, selectedUnionId);
    }
  }, [currentRole, selectedUnionId, isAuthenticated, user]);

  // Loading state while checking token persistence
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#07130F] flex flex-col items-center justify-center text-white space-y-4">
        <FortisLogo size="lg" theme="dark" showText={true} />
        <div className="flex items-center gap-3 text-amber-300 text-xs font-bold animate-pulse mt-4">
          <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
          <span>Verifying Secure Session & Clearance...</span>
        </div>
      </div>
    );
  }

  // MANDATORY AUTH GATE: User must sign up / sign in to access the system
  if (!isAuthenticated || !user) {
    return <AuthScreen />;
  }

  const userClientId = currentRole === 'client' ? (user?.id || 'cli-001') : undefined;
  const metrics = StorageService.getMetrics(currentRole, selectedUnionId, userClientId);
  const pendingPaymentCount = payments.filter((p) => p.status === 'confirmation_required').length;

  const handleUpdateStage = (clientId: string, newStage: ProjectStage) => {
    StorageService.updateClientStage(clientId, newStage, 'Staff Operator', currentRole);
    refreshData();
  };

  const handleRecordPayment = (payment: any) => {
    StorageService.recordPayment(payment);
    refreshData();
  };

  const handleConfirmPayment = (paymentId: string) => {
    StorageService.confirmPayment(paymentId, 'Kaddy Secka (Finance Officer)');
    refreshData();
    if (selectedClient) {
      const updated = StorageService.getClientById(selectedClient.id);
      if (updated) setSelectedClient(updated);
    }
  };

  const handleSaveAssessment = (assessment: AssessmentReport) => {
    StorageService.saveAssessment(assessment);
    refreshData();
  };

  const handleSaveInstallation = (log: InstallationLog) => {
    StorageService.saveInstallation(log);
    refreshData();
  };

  return (
    <div className="min-h-screen bg-[#F8FAF8] text-slate-900 font-sans antialiased selection:bg-amber-200 selection:text-slate-900">
      {/* Header Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currency={currency}
        setCurrency={setCurrency}
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        onOpenAIAssistant={() => setIsAIOpen(true)}
        pendingPaymentCount={pendingPaymentCount}
        isGdprActive={isGdprActive}
        setIsGdprActive={setIsGdprActive}
        selectedUnionId={selectedUnionId}
        setSelectedUnionId={setSelectedUnionId}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            metrics={metrics}
            clients={clients}
            payments={payments}
            auditLogs={auditLogs}
            currency={currency}
            currentRole={currentRole}
            isGdprActive={isGdprActive}
            selectedUnionId={selectedUnionId}
            onNavigateTab={(tab) => {
              if (tab === 'ai_copilot') {
                setIsAIOpen(true);
              } else {
                setActiveTab(tab);
              }
            }}
            onSelectClient={setSelectedClient}
            onNewClient={() => setActiveTab('onboarding')}
          />
        )}

        {activeTab === 'calculator' && (
          <RepaymentCalculator
            currency={currency}
            onApplyWithPlan={() => setActiveTab('onboarding')}
          />
        )}

        {activeTab === 'clients' && (
          <ClientTable
            clients={clients}
            currency={currency}
            userRole={currentRole}
            isGdprActive={isGdprActive}
            onSelectClient={setSelectedClient}
            onNewClient={() => setActiveTab('onboarding')}
            onUpdateStage={handleUpdateStage}
          />
        )}

        {activeTab === 'kanban' && (
          <KanbanBoard
            clients={clients}
            currency={currency}
            onUpdateStage={handleUpdateStage}
            onSelectClient={setSelectedClient}
            onNewClient={() => setActiveTab('onboarding')}
          />
        )}

        {activeTab === 'payments' && (
          <PaymentModule
            payments={payments}
            clients={clients}
            currency={currency}
            onRecordPayment={handleRecordPayment}
            onConfirmPayment={handleConfirmPayment}
          />
        )}

        {activeTab === 'institutional' && (
          <InstitutionalModule
            members={members}
            currency={currency}
            currentRole={currentRole}
            selectedUnionId={selectedUnionId}
            isGdprActive={isGdprActive}
            onVerifyMember={(inst, id) => StorageService.verifyMember(inst, id, currentRole, selectedUnionId)}
          />
        )}

        {activeTab === 'multimedia' && (
          <MultimediaManager
            currentRole={currentRole}
          />
        )}

        {activeTab === 'assessment' && (
          <SiteAssessmentModule
            assessments={assessments}
            clients={clients}
            currency={currency}
            onSaveAssessment={handleSaveAssessment}
          />
        )}

        {activeTab === 'installation' && (
          <InstallationHub
            installations={installations}
            clients={clients}
            currency={currency}
            onSaveInstallation={handleSaveInstallation}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsModule
            clients={clients}
            payments={payments}
            currency={currency}
            metrics={metrics}
          />
        )}

        {activeTab === 'forex_settings' && (
          <InflationForexPanel
            currency={currency}
            onConfigUpdated={() => refreshData()}
          />
        )}

        {activeTab === 'client_portal' && (
          <ClientPortalView
            clients={clients}
            payments={payments}
            currency={currency}
            onRecordPayment={handleRecordPayment}
          />
        )}

        {activeTab === 'onboarding' && (
          <PublicOnboardingForm
            currency={currency}
            onCompleteOnboarding={() => refreshData()}
          />
        )}
      </main>

      {/* Detail Drawer Modal */}
      <ClientDetailModal
        client={selectedClient}
        onClose={() => setSelectedClient(null)}
        currency={currency}
        onConfirmPayment={handleConfirmPayment}
        onUpdateStage={handleUpdateStage}
        payments={payments}
      />

      {/* FORTIS AI Assistant Bot */}
      <SolarAIAssistant
        isOpen={isAIOpen}
        onClose={() => setIsAIOpen(false)}
        onNavigateTab={(tab) => {
          setActiveTab(tab);
          setIsAIOpen(false);
        }}
      />
    </div>
  );
}
