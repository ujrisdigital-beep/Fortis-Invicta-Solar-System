import './sentry';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { AuthProvider } from './services/authContext.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

// Manage PWA Service Worker safely (bypass in dev / iframe to prevent stale cache conflicts)
try {
  if (typeof window !== 'undefined' && typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
    const isInsideIframe = window.self !== window.top;
    const isDev = import.meta.env.DEV;

    if (isInsideIframe || isDev) {
      // In dev server or iframe preview, unregister existing service workers to avoid intercepted rejections
      navigator.serviceWorker.getRegistrations().then((registrations) => {
        registrations.forEach((reg) => {
          reg.unregister().catch(() => {});
        });
      }).catch(() => {});
    } else {
      window.addEventListener('load', () => {
        navigator.serviceWorker
          ?.register('/sw.js')
          .then((registration) => {
            console.log('[PWA] ServiceWorker active:', registration.scope);
          })
          .catch((error) => {
            console.info('[PWA] ServiceWorker bypassed:', error?.message);
          });
      });
    }
  }
} catch (err: any) {
  console.info('[PWA] ServiceWorker setup bypassed:', err?.message);
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <AuthProvider>
        <App />
      </AuthProvider>
    </ErrorBoundary>
  </StrictMode>,
);
