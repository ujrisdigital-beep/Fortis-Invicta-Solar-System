/**
 * Fortis Invicta Solar Solution - Brand Theme & Visual Identity
 * The Gambia
 */
export const fortisTheme = {
  colors: {
    primary: '#1B4D3E',      // Fortis Deep Emerald Green
    primaryHover: '#143B30',
    secondary: '#C9A84C',    // Fortis Gold
    accent: '#D4AF37',       // Fortis Bright Gold
    background: '#FFFFFF',
    canvas: '#F8FAF8',
    text: '#0D2818',
    textMuted: '#4B6B5D',
    border: '#E2EBE5',
    card: '#FFFFFF',
    status: {
      success: '#10B981',
      warning: '#F59E0B',
      danger: '#EF4444',
      info: '#3B82F6'
    }
  },
  fonts: {
    heading: 'Inter, system-ui, -apple-system, sans-serif',
    body: 'Inter, system-ui, -apple-system, sans-serif',
    mono: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace'
  },
  company: {
    name: 'FORTIS INVICTA LTD',
    tagline: 'Transforming Energy | Empowering Communities',
    address: 'Tranquil Behind AGIB Bank, The Gambia',
    phone: '+220 257 2911',
    email: 'info@fortisinvicta.com',
    secondaryEmail: 'fortisinvictaltd@gmail.com',
    country: 'The Gambia',
    currency: 'GMD',
    ecobank: {
      accountName: 'FORTIS INVICTA LTD',
      accountNumber: '6254514448',
      merchantCode: '505825057',
      terminalId: '32680928',
      bankName: 'Ecobank Gambia'
    }
  }
};

export default fortisTheme;
