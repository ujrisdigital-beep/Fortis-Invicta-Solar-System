import { UserRole } from './types.js';
import { AuthenticatedRequest } from './auth.js';
import { Response, NextFunction } from 'express';

export type Permission =
  | 'clients.read'
  | 'clients.write'
  | 'payments.read'
  | 'payments.create'
  | 'payments.verify'
  | 'payments.refund'
  | 'assessments.read'
  | 'assessments.create'
  | 'assessments.approve'
  | 'projects.read'
  | 'projects.write'
  | 'inventory.read'
  | 'inventory.write'
  | 'installations.read'
  | 'installations.write'
  | 'users.manage'
  | 'audit.read';

// Authoritative RBAC Permission Mapping
export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  admin: [
    'clients.read',
    'clients.write',
    'payments.read',
    'payments.create',
    'payments.verify',
    'payments.refund',
    'assessments.read',
    'assessments.create',
    'assessments.approve',
    'projects.read',
    'projects.write',
    'inventory.read',
    'inventory.write',
    'installations.read',
    'installations.write',
    'users.manage',
    'audit.read'
  ],
  super_admin: [
    'clients.read',
    'clients.write',
    'payments.read',
    'payments.create',
    'payments.verify',
    'payments.refund',
    'assessments.read',
    'assessments.create',
    'assessments.approve',
    'projects.read',
    'projects.write',
    'inventory.read',
    'inventory.write',
    'installations.read',
    'installations.write',
    'users.manage',
    'audit.read'
  ],
  project_manager: [
    'clients.read',
    'clients.write',
    'payments.read',
    'assessments.read',
    'assessments.approve',
    'projects.read',
    'projects.write',
    'inventory.read',
    'inventory.write',
    'installations.read',
    'installations.write',
    'audit.read'
  ],
  finance_officer: [
    'clients.read',
    'payments.read',
    'payments.create',
    'payments.verify',
    'payments.refund',
    'projects.read',
    'audit.read'
  ],
  engineer: [
    'clients.read',
    'assessments.read',
    'assessments.create',
    'assessments.approve',
    'projects.read',
    'projects.write',
    'inventory.read',
    'installations.read',
    'installations.write'
  ],
  site_inspector: [
    'clients.read',
    'assessments.read',
    'assessments.create',
    'projects.read',
    'installations.read'
  ],
  installer: [
    'projects.read',
    'installations.read',
    'installations.write',
    'inventory.read'
  ],
  institutional_admin: [
    'clients.read',
    'projects.read',
    'payments.read',
    'assessments.read'
  ],
  client: [
    'clients.read',
    'payments.read',
    'payments.create',
    'assessments.read',
    'projects.read'
  ]
};

export function hasPermission(role: UserRole, permission: Permission): boolean {
  const permissions = ROLE_PERMISSIONS[role] || [];
  return permissions.includes(permission);
}

export function requirePermission(permission: Permission) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required',
        code: 'UNAUTHORIZED'
      });
    }

    if (!hasPermission(req.user.role, permission)) {
      return res.status(403).json({
        success: false,
        error: `Access forbidden: requires '${permission}' permission. User role '${req.user.role}' is not authorized.`,
        code: 'FORBIDDEN'
      });
    }

    next();
  };
}
