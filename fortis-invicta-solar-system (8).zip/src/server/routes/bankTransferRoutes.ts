import { Router, Request, Response } from 'express';
import multer from 'multer';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const router = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// Lazy-initialized Supabase client
let supabaseClient: SupabaseClient | null = null;

function getSupabaseClient(): SupabaseClient | null {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!url || !key) {
    return null;
  }
  if (!supabaseClient) {
    supabaseClient = createClient(url, key);
  }
  return supabaseClient;
}

// 1. Fetch Bank Transfer Details for Users
router.get('/ecobank-transfer-details', (req: Request, res: Response) => {
  res.status(200).json({
    accountName: process.env.ECOBANK_ACCOUNT_NAME || "Fortis Invicta Ltd",
    accountNumber: process.env.ECOBANK_ACCOUNT_NUMBER || "6240019284",
    branch: process.env.ECOBANK_BRANCH || "Kairaba Avenue",
    swiftCode: process.env.ECOBANK_SWIFT || "ECOCGMGM"
  });
});

// 2. Submit Direct Transfer / Bank Teller Proof
router.post('/submit-teller-proof', upload.single('receiptImage'), async (req: Request, res: Response) => {
  try {
    const { clientId, amount, referenceCode, depositDate } = req.body;

    if (!clientId || !amount || !referenceCode) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: clientId, amount, and referenceCode are mandatory.'
      });
    }

    let imageUrl: string | null = null;
    const supabase = getSupabaseClient();

    // Upload receipt image to Supabase Storage bucket if provided
    if (req.file && supabase) {
      const sanitizedName = req.file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
      const filePath = `receipts/${clientId}_${Date.now()}_${sanitizedName}`;

      try {
        const { error: storageError } = await supabase
          .storage
          .from('payment-proofs')
          .upload(filePath, req.file.buffer, { contentType: req.file.mimetype, upsert: true });

        if (!storageError) {
          const { data: publicUrlData } = supabase.storage
            .from('payment-proofs')
            .getPublicUrl(filePath);

          imageUrl = publicUrlData?.publicUrl || null;
        } else {
          console.warn('[Storage Notice] payment-proofs upload notice:', storageError.message);
        }
      } catch (storageEx: any) {
        console.warn('[Storage Warning] Error uploading to payment-proofs bucket:', storageEx.message);
      }
    }

    const newPaymentRecord = {
      client_id: clientId,
      amount: parseFloat(amount),
      reference_code: referenceCode.trim().toUpperCase(),
      deposit_date: depositDate || new Date().toISOString().split('T')[0],
      proof_url: imageUrl,
      status: 'PENDING_VERIFICATION',
      payment_method: 'ECOBANK_DIRECT_TRANSFER',
      created_at: new Date().toISOString()
    };

    if (supabase) {
      // Insert payment record into manual_payments table
      const { data, error } = await supabase
        .from('manual_payments')
        .insert([newPaymentRecord])
        .select();

      if (!error && data && data.length > 0) {
        return res.status(201).json({
          success: true,
          message: 'Deposit proof submitted successfully. Pending admin confirmation.',
          transaction: data[0]
        });
      }

      if (error) {
        console.warn('[Database Notice] manual_payments table insert notice:', error.message);
        // Fallback insert to standard payments table if manual_payments not yet migrated in Supabase instance
        const { data: payData, error: payError } = await supabase
          .from('payments')
          .insert([{
            client_id: clientId,
            amount_gmd: parseFloat(amount),
            teller_reference_number: referenceCode.trim().toUpperCase(),
            teller_receipt_url: imageUrl,
            payment_type: '80% System Deposit',
            payment_method: 'DIRECT_TRANSFER',
            channel: 'BANK_TRANSFER',
            status: 'PENDING_VERIFICATION',
            created_at: new Date().toISOString()
          }])
          .select();

        if (!payError && payData && payData.length > 0) {
          return res.status(201).json({
            success: true,
            message: 'Deposit proof submitted successfully. Pending admin confirmation.',
            transaction: {
              ...newPaymentRecord,
              id: payData[0].id
            }
          });
        }

        if (process.env.NODE_ENV === 'production') {
          throw error || payError;
        }
      }
    }

    // Fallback for non-production environments when Supabase is disconnected
    return res.status(201).json({
      success: true,
      message: 'Deposit proof submitted successfully. Pending admin confirmation.',
      transaction: {
        id: `mpay-${Date.now()}`,
        ...newPaymentRecord
      }
    });
  } catch (err: any) {
    console.error('[Submit Teller Proof Error]:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to submit teller proof' });
  }
});

// 3. Verify Payment Status (Admin / Finance Officer)
router.post('/verify-payment', async (req: Request, res: Response) => {
  try {
    const { paymentId, status, adminId } = req.body; // status: 'APPROVED' or 'REJECTED'

    if (!paymentId || !status) {
      return res.status(400).json({ success: false, error: 'paymentId and status are required' });
    }

    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase
        .from('manual_payments')
        .update({ 
          status: status, 
          verified_by: adminId || null, 
          updated_at: new Date().toISOString() 
        })
        .eq('id', paymentId)
        .select();

      if (!error && data && data.length > 0) {
        return res.status(200).json({ success: true, payment: data[0] });
      }

      if (error) {
        // Also update standard payments table if ID belongs there
        const { data: payData, error: payError } = await supabase
          .from('payments')
          .update({
            status: status,
            confirmed_by: adminId || 'Finance Admin',
            confirmed_at: status === 'APPROVED' ? new Date().toISOString() : null
          })
          .eq('id', paymentId)
          .select();

        if (!payError && payData && payData.length > 0) {
          return res.status(200).json({ success: true, payment: payData[0] });
        }

        return res.status(500).json({ success: false, error: error.message });
      }
    }

    // Fallback in non-production standalone mode
    return res.status(200).json({
      success: true,
      payment: {
        id: paymentId,
        status: status,
        verified_by: adminId || null,
        updated_at: new Date().toISOString()
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Internal server error' });
  }
});

export default router;
