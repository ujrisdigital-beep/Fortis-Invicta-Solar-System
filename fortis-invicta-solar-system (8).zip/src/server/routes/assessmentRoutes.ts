import { Router, Response } from 'express';
import { AuthenticatedRequest, requireAuth, requireRole } from '../auth.js';
import { getSupabaseAdminClient } from '../../db/supabaseClient.js';

export const assessmentRouter = Router();

// GET /api/v2/assessments - List assessments with strict role-based access control
assessmentRouter.get(
  '/',
  requireAuth,
  async (req: AuthenticatedRequest, res: Response) => {
    const supabase = getSupabaseAdminClient();
    if (!supabase) {
      return res.status(503).json({
        success: false,
        error: {
          code: 'DATABASE_UNAVAILABLE',
          message: 'Authoritative database connection is unavailable. Cannot retrieve assessments.'
        }
      });
    }

    try {
      let query = supabase.from('site_assessments').select('*').order('created_at', { ascending: false });

      // Role-based tenant / user isolation
      if (req.user?.role === 'client') {
        query = query.eq('client_id', req.user.id);
      } else if (req.user?.role === 'site_inspector' || req.user?.role === 'engineer') {
        // Inspectors and engineers see assessments where they are the assessor or all assigned
        if (req.query.myOnly === 'true') {
          query = query.eq('assessor_id', req.user.id);
        }
      }

      const { data, error } = await query;
      if (error) {
        return res.status(500).json({
          success: false,
          error: {
            code: 'DATABASE_QUERY_ERROR',
            message: error.message
          }
        });
      }

      return res.json({ success: true, assessments: data || [] });
    } catch (err: any) {
      return res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_SERVER_ERROR',
          message: err.message || 'Failed to retrieve assessments'
        }
      });
    }
  }
);

// POST /api/v2/assessments - Record field engineer site assessment (Authoritative DB only)
assessmentRouter.post(
  '/',
  requireAuth,
  requireRole(['admin', 'super_admin', 'engineer', 'site_inspector', 'project_manager']),
  async (req: AuthenticatedRequest, res: Response) => {
    const supabase = getSupabaseAdminClient();
    if (!supabase) {
      return res.status(503).json({
        success: false,
        error: {
          code: 'DATABASE_UNAVAILABLE',
          message: 'Authoritative database is not connected. Assessment rejected to prevent uncommitted data loss.'
        }
      });
    }

    try {
      const a = req.body;
      const assessorId = req.user?.id;

      if (!assessorId) {
        return res.status(401).json({
          success: false,
          error: {
            code: 'UNAUTHORIZED_ASSESSOR',
            message: 'Authenticated assessor ID is required.'
          }
        });
      }

      if (!a.clientId) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'MISSING_CLIENT_ID',
            message: 'Client ID is mandatory for site assessment records.'
          }
        });
      }

      const record = {
        id: a.id || `assess-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        client_id: a.clientId,
        assessor_id: assessorId,
        roof_type: a.roofType || 'corrugated_iron',
        roof_azimuth_degrees: Number(a.roofAzimuthDegrees || a.azimuth || 180),
        tilt_angle_degrees: Number(a.tiltAngleDegrees || a.tilt || 15),
        shading_level: a.shadingLevel || 'minimal',
        nawec_grid_stability: a.nawecGridStability || 'Intermittent',
        daily_energy_kwh: Number(a.dailyEnergyKWh || 12.0),
        recommended_kva: Number(a.recommendedKVA || 3.5),
        recommended_panels: Number(a.recommendedPanels || 6),
        recommended_batteries: Number(a.recommendedBatteries || 2),
        notes: a.notes || 'Field engineering assessment recorded',
        gps_coordinates: a.gpsCoordinates || (a.latitude && a.longitude ? `${a.latitude},${a.longitude}` : null),
        assessed_at: new Date().toISOString(),
        created_at: new Date().toISOString()
      };

      const { data: assessment, error } = await supabase
        .from('site_assessments')
        .insert(record)
        .select()
        .single();

      if (error || !assessment) {
        console.error('[Assessment DB Insert Error]:', error);
        return res.status(500).json({
          success: false,
          error: {
            code: 'DATABASE_INSERT_FAILED',
            message: `Failed to commit site assessment to authoritative database: ${error?.message || 'Unknown database error'}. Data was NOT saved.`
          }
        });
      }

      // Update client stage to PROPOSAL_APPROVED or ASSESSED atomically
      await supabase
        .from('clients')
        .update({ stage: 'ASSESSED' })
        .eq('id', a.clientId);

      // Record immutable audit log
      await supabase.from('audit_logs').insert({
        user_id: assessorId,
        actor_name: req.user?.fullName || 'Field Inspector',
        actor_role: req.user?.role || 'site_inspector',
        action: 'SITE_ASSESSMENT_CREATED',
        details: {
          assessmentId: record.id,
          clientId: a.clientId,
          recommendedKVA: record.recommended_kva,
          dailyEnergyKWh: record.daily_energy_kwh
        }
      });

      return res.status(201).json({
        success: true,
        message: 'Site assessment committed to authoritative database.',
        assessment
      });
    } catch (err: any) {
      console.error('[Assessment Route Error]:', err);
      return res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_SERVER_ERROR',
          message: err.message || 'Unexpected failure processing assessment'
        }
      });
    }
  }
);

