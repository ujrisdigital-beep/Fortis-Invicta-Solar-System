import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { requireAuth, requireRole, AuthenticatedRequest } from '../auth.js';
import { institutionalRateLimiter } from '../security.js';
import { getSupabaseAdminClient } from '../../db/supabaseClient.js';
import { getEnvConfig } from '../envConfig.js';

export const verificationRouter = Router();

// Apply max 10 requests per hour rate limiting across institutional verification endpoints
verificationRouter.use(institutionalRateLimiter);

export interface VerificationDossier {
  id: string;
  clientId?: string;
  institutionId: 'GTUCCU' | 'NAGNMC' | 'GAMPOST' | 'GAMTEL' | 'NAWEC' | string;
  memberId: string;
  memberName: string;
  workplace: string;
  monthlyGrossSalaryGMD: number;
  requestedPackageId?: string;
  idDocumentUrl?: string;
  payslipDocumentUrl?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'MORE_INFO_REQUIRED';
  adminNotes?: string;
  reviewedBy?: string;
  reviewerRole?: string;
  approvedCreditLimitGMD?: number;
  maxMonthlyDeductionGMD?: number;
  proofToken?: string;
  submittedAt: string;
  reviewedAt?: string;
  auditTrail: Array<{
    action: string;
    actor: string;
    timestamp: string;
    note?: string;
  }>;
}

// In-Memory Fallback Queue for Verification Dossiers
const inMemoryVerificationQueue: VerificationDossier[] = [
  {
    id: 'ver-001',
    clientId: 'cli-001',
    institutionId: 'GTUCCU',
    memberId: 'GTU-88421',
    memberName: 'Amara Jobe',
    workplace: 'Brikama Senior Secondary School',
    monthlyGrossSalaryGMD: 18500,
    requestedPackageId: 'hybrid_standard',
    status: 'APPROVED',
    adminNotes: 'Verified against GTUCCU Central Credit Committee payroll database.',
    reviewedBy: 'Fatou Jallow (Finance Officer)',
    reviewerRole: 'finance_officer',
    approvedCreditLimitGMD: 350000,
    maxMonthlyDeductionGMD: 6100,
    proofToken: 'hmac_proof_gtuccu_88421_approved_token_2026',
    submittedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString(),
    reviewedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 13).toISOString(),
    auditTrail: [
      { action: 'SUBMITTED', actor: 'Amara Jobe', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString() },
      { action: 'APPROVED', actor: 'Fatou Jallow', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 13).toISOString(), note: 'Verified payslip #GTU-2026-08' }
    ]
  },
  {
    id: 'ver-002',
    institutionId: 'NAGNMC',
    memberId: 'NAG-4109',
    memberName: 'Omar Jallow',
    workplace: 'EFSTH Hospital Banjul',
    monthlyGrossSalaryGMD: 24000,
    requestedPackageId: 'executive_premium',
    status: 'PENDING',
    adminNotes: 'Awaiting secondary payslip stamped by Ministry of Health payroll desk.',
    submittedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(),
    auditTrail: [
      { action: 'SUBMITTED', actor: 'Omar Jallow', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString() }
    ]
  }
];

// Helper to calculate Gambian statutory maximum salary deduction (33.3% net cap)
function calculateCreditLimits(grossSalaryGMD: number, durationMonths = 24) {
  const estimatedNetSalary = grossSalaryGMD * 0.85; // after pensions/taxes
  const maxMonthlyDeductionGMD = Math.round(estimatedNetSalary * 0.333); // 33.3% cap
  const approvedCreditLimitGMD = Math.round(maxMonthlyDeductionGMD * durationMonths * 0.95); // 5% admin fee adjusted
  return { maxMonthlyDeductionGMD, approvedCreditLimitGMD };
}

// 1. POST /api/v2/verify-member/submit - Human-in-the-Loop Verification Request
verificationRouter.post('/submit', async (req: Request, res: Response) => {
  try {
    const {
      institutionId,
      memberId,
      memberName,
      workplace,
      monthlyGrossSalaryGMD,
      requestedPackageId,
      idDocumentUrl,
      payslipDocumentUrl,
      clientId
    } = req.body;

    if (!institutionId || !memberId || !memberName) {
      return res.status(400).json({ success: false, error: 'Missing mandatory identification fields' });
    }

    const cleanMemberId = String(memberId).trim().toUpperCase();
    const cleanInst = String(institutionId).trim().toUpperCase();
    const salary = Number(monthlyGrossSalaryGMD) || 15000;

    const dossier: VerificationDossier = {
      id: `ver-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      clientId,
      institutionId: cleanInst,
      memberId: cleanMemberId,
      memberName: String(memberName).trim(),
      workplace: String(workplace || 'Civil Service / Institutional').trim(),
      monthlyGrossSalaryGMD: salary,
      requestedPackageId: requestedPackageId || 'hybrid_standard',
      idDocumentUrl,
      payslipDocumentUrl,
      status: 'PENDING',
      submittedAt: new Date().toISOString(),
      auditTrail: [
        {
          action: 'DOSSIER_SUBMITTED',
          actor: memberName,
          timestamp: new Date().toISOString(),
          note: 'Documents submitted for credit committee verification.'
        }
      ]
    };

    const supabase = getSupabaseAdminClient();
    if (supabase) {
      await supabase.from('verification_records').insert({
        id: dossier.id,
        client_id: dossier.clientId || null,
        institution_id: dossier.institutionId,
        member_id: dossier.memberId,
        member_name: dossier.memberName,
        is_verified: false,
        max_credit_gmd: salary * 18,
        proof_token_hash: `pending_${dossier.id}`
      });
    }

    inMemoryVerificationQueue.unshift(dossier);

    return res.status(201).json({
      success: true,
      message: `Institutional verification request for ${memberName} (${cleanInst}) placed into Admin Review Queue.`,
      dossier
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 2. GET /api/v2/verify-member/queue - Admin Review Queue
verificationRouter.get('/queue', async (req: Request, res: Response) => {
  const { status, institutionId } = req.query;

  let queue = [...inMemoryVerificationQueue];
  if (status) {
    queue = queue.filter((d) => d.status === String(status).toUpperCase());
  }
  if (institutionId) {
    queue = queue.filter((d) => d.institutionId === String(institutionId).toUpperCase());
  }

  return res.json({
    success: true,
    total: queue.length,
    queue
  });
});

// 3. POST /api/v2/verify-member/review/:id - Human Review Action (Approve / Reject)
verificationRouter.post('/review/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { status, adminNotes, approvedCreditLimit, reviewerName, reviewerRole } = req.body;

    if (!['APPROVED', 'REJECTED', 'MORE_INFO_REQUIRED'].includes(status)) {
      return res.status(400).json({ success: false, error: 'Invalid review status. Must be APPROVED, REJECTED, or MORE_INFO_REQUIRED.' });
    }

    const dossier = inMemoryVerificationQueue.find((d) => d.id === id);
    if (!dossier) {
      return res.status(404).json({ success: false, error: 'Verification dossier not found' });
    }

    const config = getEnvConfig();
    const reviewer = reviewerName || 'Institutional Officer';
    const now = new Date().toISOString();

    dossier.status = status;
    dossier.adminNotes = adminNotes || dossier.adminNotes;
    dossier.reviewedBy = reviewer;
    dossier.reviewerRole = reviewerRole || 'finance_officer';
    dossier.reviewedAt = now;

    if (status === 'APPROVED') {
      const limits = calculateCreditLimits(dossier.monthlyGrossSalaryGMD);
      dossier.approvedCreditLimitGMD = approvedCreditLimit ? Number(approvedCreditLimit) : limits.approvedCreditLimitGMD;
      dossier.maxMonthlyDeductionGMD = limits.maxMonthlyDeductionGMD;

      // Generate cryptographically signed HMAC token for deduction mandate
      const proofPayload = `${dossier.institutionId}:${dossier.memberId}:${dossier.memberName}:${dossier.approvedCreditLimitGMD}:${now}`;
      dossier.proofToken = crypto.createHmac('sha256', config.APP_SECRET).update(proofPayload).digest('hex');
    }

    dossier.auditTrail.push({
      action: `REVIEW_${status}`,
      actor: reviewer,
      timestamp: now,
      note: adminNotes || `Review completed with status ${status}`
    });

    return res.json({
      success: true,
      message: `Dossier #${id} review status updated to ${status}`,
      dossier
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 4. POST /api/v2/verify-member - Direct Member Lookup & Legacy Verification
verificationRouter.post('/', async (req: Request, res: Response) => {
  try {
    const { institutionId, memberId } = req.body;
    if (!institutionId || !memberId) {
      return res.status(400).json({ error: 'Missing required parameters: institutionId and memberId' });
    }

    const cleanMember = String(memberId).trim().toUpperCase();
    const cleanInst = String(institutionId).trim().toUpperCase();

    // Check approved queue first
    const approvedDossier = inMemoryVerificationQueue.find(
      (d) => d.memberId === cleanMember && d.institutionId === cleanInst && d.status === 'APPROVED'
    );

    if (approvedDossier) {
      return res.json({
        verified: true,
        institutionId: approvedDossier.institutionId,
        memberId: approvedDossier.memberId,
        memberName: approvedDossier.memberName,
        workplace: approvedDossier.workplace,
        maxCreditGMD: approvedDossier.approvedCreditLimitGMD || 350000,
        deductionStatus: 'PRE_APPROVED',
        proofToken: approvedDossier.proofToken,
        verifiedAt: approvedDossier.reviewedAt || approvedDossier.submittedAt
      });
    }

    // Check pending dossier
    const pendingDossier = inMemoryVerificationQueue.find(
      (d) => d.memberId === cleanMember && d.institutionId === cleanInst && d.status === 'PENDING'
    );

    if (pendingDossier) {
      return res.json({
        verified: false,
        pendingReview: true,
        institutionId: cleanInst,
        memberId: cleanMember,
        message: `Member ID "${cleanMember}" is currently under review by the ${cleanInst} credit committee.`
      });
    }

    return res.json({
      verified: false,
      institutionId: cleanInst,
      memberId: cleanMember,
      message: `Member ID "${cleanMember}" was not found in the verified active payroll registry of ${cleanInst}. Please submit a verification dossier.`
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});
