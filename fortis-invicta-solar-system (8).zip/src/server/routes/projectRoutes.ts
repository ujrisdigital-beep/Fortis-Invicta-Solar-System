import { Router, Response } from 'express';
import { z } from 'zod';
import { AuthenticatedRequest, requireAuth, requireRole } from '../auth.js';
import { validateBody } from '../security.js';
import { createProjectSchema } from '../validationSchemas.js';
import { getSupabaseAdminClient } from '../../db/supabaseClient.js';

export const projectRouter = Router();

const updateProjectSchema = z.object({
  assignedEngineerId: z.string().optional().nullable(),
  stage: z.enum(['LEAD', 'SITE_SURVEY', 'PROPOSAL_APPROVED', 'DEPOSIT_RECEIVED', 'EQUIPMENT_ALLOCATED', 'INSTALLATION_IN_PROGRESS', 'COMMISSIONED', 'MAINTENANCE']).optional(),
  installationDate: z.string().optional().nullable(),
  commissioningDate: z.string().optional().nullable(),
  warrantyYears: z.number().int().min(1).optional(),
  systemCapacityKVA: z.number().positive().optional(),
  batteryCapacityKWh: z.number().positive().optional(),
  gpsLatitude: z.number().optional().nullable(),
  gpsLongitude: z.number().optional().nullable()
});

// In-Memory fallback projects cache
const inMemoryProjects: any[] = [
  {
    id: 'prj-001',
    client_id: 'cli-001',
    package_id: 'hybrid_standard',
    package_name: 'Tier 2: Hybrid Standard (3.5kVA / 3.0kW)',
    system_capacity_kva: 3.5,
    battery_capacity_kwh: 9.6,
    stage: 'INSTALLATION_IN_PROGRESS',
    warranty_years: 5,
    gps_latitude: 13.2811,
    gps_longitude: -16.6514,
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString()
  }
];

// 1. GET /api/v2/projects - List all projects with RBAC
projectRouter.get('/', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const supabase = getSupabaseAdminClient();
    const user = req.user!;

    if (supabase) {
      let query = supabase.from('projects').select('*, clients(*)');

      if (user.role === 'engineer') {
        query = query.eq('assigned_engineer_id', user.id);
      } else if (user.role === 'client') {
        const { data: userClients } = await supabase
          .from('clients')
          .select('id')
          .eq('user_id', user.id);
        const clientIds = (userClients || []).map((c) => c.id);
        query = query.in('client_id', clientIds);
      }

      const { data: projects, error } = await query.order('created_at', { ascending: false });
      if (!error && projects) {
        return res.json({ success: true, projects });
      }
    }

    return res.json({ success: true, projects: inMemoryProjects });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 2. GET /api/v2/projects/:id - Get project by ID
projectRouter.get('/:id', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getSupabaseAdminClient();

    if (supabase) {
      const { data: project, error } = await supabase
        .from('projects')
        .select('*, clients(*), site_assessments(*)')
        .eq('id', id)
        .maybeSingle();

      if (error) throw error;
      if (!project) return res.status(404).json({ success: false, error: 'Project not found' });
      return res.json({ success: true, project });
    }

    const match = inMemoryProjects.find((p) => p.id === id);
    if (!match) return res.status(404).json({ success: false, error: 'Project not found' });
    return res.json({ success: true, project: match });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 3. POST /api/v2/projects - Create new project
projectRouter.post(
  '/',
  requireAuth,
  requireRole(['admin', 'project_manager', 'engineer']),
  validateBody(createProjectSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const supabase = getSupabaseAdminClient();
      const p = req.body;

      if (!supabase) {
        const newProj = {
          id: `prj-${Date.now()}`,
          client_id: p.clientId,
          assigned_engineer_id: p.assignedEngineerId || null,
          package_id: p.packageId,
          package_name: p.packageName,
          system_capacity_kva: p.systemCapacityKVA,
          battery_capacity_kwh: p.batteryCapacityKWh,
          stage: p.stage || 'LEAD',
          warranty_years: p.warrantyYears || 5,
          gps_latitude: p.gpsLatitude,
          gps_longitude: p.gpsLongitude,
          created_at: new Date().toISOString()
        };
        inMemoryProjects.unshift(newProj);
        return res.status(201).json({ success: true, project: newProj });
      }

      const { data: project, error } = await supabase
        .from('projects')
        .insert({
          client_id: p.clientId,
          assigned_engineer_id: p.assignedEngineerId || null,
          package_id: p.packageId,
          package_name: p.packageName,
          system_capacity_kva: p.systemCapacityKVA,
          battery_capacity_kwh: p.batteryCapacityKWh,
          stage: p.stage || 'LEAD',
          warranty_years: p.warrantyYears || 5,
          gps_latitude: p.gpsLatitude,
          gps_longitude: p.gpsLongitude
        })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json({ success: true, project });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);

// 4. PUT /api/v2/projects/:id - Update project stages / specifications
projectRouter.put(
  '/:id',
  requireAuth,
  requireRole(['admin', 'project_manager', 'engineer']),
  validateBody(updateProjectSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const supabase = getSupabaseAdminClient();

      if (supabase) {
        const updatePayload: Record<string, any> = {
          updated_at: new Date().toISOString()
        };
        if (updates.assignedEngineerId !== undefined) updatePayload.assigned_engineer_id = updates.assignedEngineerId;
        if (updates.stage) updatePayload.stage = updates.stage;
        if (updates.installationDate) updatePayload.installation_date = updates.installationDate;
        if (updates.commissioningDate) updatePayload.commissioning_date = updates.commissioningDate;
        if (updates.warrantyYears) updatePayload.warranty_years = updates.warrantyYears;
        if (updates.systemCapacityKVA) updatePayload.system_capacity_kva = updates.systemCapacityKVA;
        if (updates.batteryCapacityKWh) updatePayload.battery_capacity_kwh = updates.batteryCapacityKWh;
        if (updates.gpsLatitude !== undefined) updatePayload.gps_latitude = updates.gpsLatitude;
        if (updates.gpsLongitude !== undefined) updatePayload.gps_longitude = updates.gpsLongitude;

        const { data: updated, error } = await supabase
          .from('projects')
          .update(updatePayload)
          .eq('id', id)
          .select()
          .single();

        if (error) throw error;
        return res.json({ success: true, message: 'Project updated', project: updated });
      }

      const match = inMemoryProjects.find((p) => p.id === id);
      if (!match) return res.status(404).json({ success: false, error: 'Project not found' });
      Object.assign(match, updates);

      return res.json({ success: true, message: 'Project updated in local cache', project: match });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);

// 5. DELETE /api/v2/projects/:id - Delete project (Admin only)
projectRouter.delete(
  '/:id',
  requireAuth,
  requireRole(['admin']),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const supabase = getSupabaseAdminClient();

      if (supabase) {
        const { error } = await supabase.from('projects').delete().eq('id', id);
        if (error) throw error;
      } else {
        const idx = inMemoryProjects.findIndex((p) => p.id === id);
        if (idx !== -1) inMemoryProjects.splice(idx, 1);
      }

      return res.json({ success: true, message: `Project ${id} deleted successfully` });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);
