import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { AuthenticatedRequest, requireAuth, requireRole, usersDB } from '../auth.js';
import { validateBody } from '../security.js';
import { getSupabaseAdminClient } from '../../db/supabaseClient.js';
import { UserRole } from '../types.js';

export const userRouter = Router();

const updateUserRoleSchema = z.object({
  role: z.enum(['client', 'engineer', 'project_manager', 'finance_officer', 'institutional_admin', 'admin']),
  institutionId: z.string().optional().nullable()
});

const updateUserStatusSchema = z.object({
  isActive: z.boolean()
});

// 1. GET /api/v2/users - List all system users (Admin / Project Manager)
userRouter.get(
  '/',
  requireAuth,
  requireRole(['admin', 'project_manager']),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const supabase = getSupabaseAdminClient();
      if (supabase) {
        const { data: users, error } = await supabase
          .from('users')
          .select('id, email, full_name, role, phone, institution_id, is_active, last_login_at, created_at, updated_at')
          .order('created_at', { ascending: false });

        if (!error && users) {
          return res.json({ success: true, users });
        }
      }

      // In-memory fallback
      const safeUsers = usersDB.map(({ passwordHash, ...user }) => user);
      return res.json({ success: true, users: safeUsers });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);

// 2. GET /api/v2/users/:id - Get specific user profile by ID
userRouter.get(
  '/:id',
  requireAuth,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const currentUser = req.user!;

      // Clients can only access their own profile; staff can access any profile
      if (currentUser.role === 'client' && currentUser.id !== id) {
        return res.status(403).json({ success: false, error: 'Access forbidden' });
      }

      const supabase = getSupabaseAdminClient();
      if (supabase) {
        const { data: user, error } = await supabase
          .from('users')
          .select('id, email, full_name, role, phone, institution_id, is_active, last_login_at, created_at')
          .eq('id', id)
          .maybeSingle();

        if (error) throw error;
        if (!user) {
          return res.status(404).json({ success: false, error: 'User not found' });
        }

        return res.json({ success: true, user });
      }

      const memoryUser = usersDB.find((u) => u.id === id);
      if (!memoryUser) {
        return res.status(404).json({ success: false, error: 'User not found' });
      }

      const { passwordHash, ...safeUser } = memoryUser;
      return res.json({ success: true, user: safeUser });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);

// 3. PATCH /api/v2/users/:id/role - Update user role & institution (Super Admin only)
userRouter.patch(
  '/:id/role',
  requireAuth,
  requireRole(['admin']),
  validateBody(updateUserRoleSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { role, institutionId } = req.body;

      const supabase = getSupabaseAdminClient();
      if (supabase) {
        const { data: updatedUser, error } = await supabase
          .from('users')
          .update({
            role,
            institution_id: institutionId || null,
            updated_at: new Date().toISOString()
          })
          .eq('id', id)
          .select('id, email, full_name, role, institution_id, updated_at')
          .single();

        if (error) throw error;
        return res.json({ success: true, message: 'User role updated', user: updatedUser });
      }

      const memoryUser = usersDB.find((u) => u.id === id);
      if (!memoryUser) {
        return res.status(404).json({ success: false, error: 'User not found' });
      }

      memoryUser.role = role as UserRole;
      if (institutionId !== undefined) memoryUser.institutionId = institutionId;

      return res.json({
        success: true,
        message: 'User role updated in local state',
        user: {
          id: memoryUser.id,
          email: memoryUser.email,
          fullName: memoryUser.fullName,
          role: memoryUser.role,
          institutionId: memoryUser.institutionId
        }
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);

// 4. PATCH /api/v2/users/:id/status - Activate / Deactivate user account (Admin only)
userRouter.patch(
  '/:id/status',
  requireAuth,
  requireRole(['admin']),
  validateBody(updateUserStatusSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { isActive } = req.body;

      const supabase = getSupabaseAdminClient();
      if (supabase) {
        const { data: updatedUser, error } = await supabase
          .from('users')
          .update({
            is_active: isActive,
            updated_at: new Date().toISOString()
          })
          .eq('id', id)
          .select('id, email, is_active, updated_at')
          .single();

        if (error) throw error;
        return res.json({ success: true, message: `User status set to ${isActive ? 'active' : 'inactive'}`, user: updatedUser });
      }

      return res.json({ success: true, message: `User status updated for ${id}` });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);

// 5. DELETE /api/v2/users/:id - Delete user account (Admin only)
userRouter.delete(
  '/:id',
  requireAuth,
  requireRole(['admin']),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      if (req.user?.id === id) {
        return res.status(400).json({ success: false, error: 'Cannot delete your own administrative account' });
      }

      const supabase = getSupabaseAdminClient();
      if (supabase) {
        const { error } = await supabase.from('users').delete().eq('id', id);
        if (error) throw error;
      } else {
        const index = usersDB.findIndex((u) => u.id === id);
        if (index !== -1) usersDB.splice(index, 1);
      }

      return res.json({ success: true, message: `User ${id} permanently deleted` });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);
