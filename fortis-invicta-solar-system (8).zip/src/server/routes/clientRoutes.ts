import { Router, Response } from 'express';
import { z } from 'zod';
import { AuthenticatedRequest, requireAuth, requireRole } from '../auth.js';
import { validateBody } from '../security.js';
import { createClientSchema } from '../validationSchemas.js';
import { getSupabaseAdminClient } from '../../db/supabaseClient.js';

export const clientRouter = Router();

const updateClientSchema = z.object({
  fullName: z.string().min(2).optional(),
  phone: z.string().min(7).optional(),
  email: z.string().email().optional().nullable(),
  address: z.string().min(3).optional(),
  region: z.string().min(2).optional(),
  institutionId: z.string().optional().nullable(),
  institutionMemberId: z.string().optional().nullable(),
  stage: z.enum(['LEAD', 'SITE_SURVEY', 'PROPOSAL_APPROVED', 'DEPOSIT_RECEIVED', 'EQUIPMENT_ALLOCATED', 'INSTALLATION_IN_PROGRESS', 'COMMISSIONED', 'MAINTENANCE']).optional(),
  ragStatus: z.enum(['GREEN', 'AMBER', 'RED']).optional(),
  selectedPackageId: z.enum(['basic_backup', 'hybrid_standard', 'executive_premium', 'commercial_heavy']).optional(),
  totalContractGMD: z.number().positive().optional(),
  depositPaidGMD: z.number().nonnegative().optional(),
  outstandingGMD: z.number().nonnegative().optional(),
  deductionStatus: z.enum(['NOT_APPLICABLE', 'PENDING_SUBMISSION', 'SUBMITTED_TO_UNION', 'PRE_APPROVED', 'ACTIVE_DEDUCTION', 'COMPLETED', 'DEFAULTED']).optional(),
  monthlyDeductionGMD: z.number().nonnegative().optional().nullable(),
  notes: z.string().optional().nullable()
});

// In-Memory clients fallback cache
const inMemoryClients: any[] = [
  {
    id: 'cli-001',
    fullName: 'Amara Jobe',
    phone: '+220 784 9210',
    email: 'amara.jobe@gtu.gm',
    address: 'Brikama Nyambai, West Coast Region',
    region: 'West Coast',
    institutionId: 'GTUCCU',
    institutionMemberId: 'GTU-88421',
    stage: 'INSTALLATION_IN_PROGRESS',
    ragStatus: 'GREEN',
    selectedPackageId: 'hybrid_standard',
    totalContractGMD: 345000,
    depositPaidGMD: 276000,
    outstandingGMD: 69000,
    deductionStatus: 'PRE_APPROVED',
    monthlyDeductionGMD: 2875,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString()
  }
];

// 1. GET /api/v2/clients - List clients with RBAC
clientRouter.get('/', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const supabase = getSupabaseAdminClient();
    const user = req.user!;

    if (supabase) {
      let query = supabase.from('clients').select('*, projects(*), payments(*), site_assessments(*)');

      // If client role, restrict to their own client record
      if (user.role === 'client') {
        query = query.eq('user_id', user.id);
      } else if (user.role === 'institutional_admin' && user.institutionId) {
        query = query.eq('institution_id', user.institutionId);
      }

      const { data: clients, error } = await query.order('created_at', { ascending: false });
      if (!error && clients) {
        return res.json({ success: true, clients });
      }
    }

    return res.json({ success: true, clients: inMemoryClients });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 2. GET /api/v2/clients/:id - Get client by ID
clientRouter.get('/:id', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const supabase = getSupabaseAdminClient();

    if (supabase) {
      let query = supabase
        .from('clients')
        .select('*, projects(*), payments(*), site_assessments(*)')
        .eq('id', id);

      if (user.role === 'client') {
        query = query.eq('user_id', user.id);
      }

      const { data: client, error } = await query.maybeSingle();
      if (error) throw error;
      if (!client) return res.status(404).json({ success: false, error: 'Client record not found' });
      return res.json({ success: true, client });
    }

    const match = inMemoryClients.find((c) => c.id === id);
    if (!match) return res.status(404).json({ success: false, error: 'Client record not found' });
    return res.json({ success: true, client: match });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 3. POST /api/v2/clients - Create new client record
clientRouter.post(
  '/',
  requireAuth,
  requireRole(['admin', 'project_manager', 'finance_officer', 'client']),
  validateBody(createClientSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const supabase = getSupabaseAdminClient();
      const clientData = req.body;
      const userId = req.user?.id;

      if (!supabase) {
        const createdClient = {
          id: `cli-${Date.now()}`,
          user_id: userId,
          ...clientData,
          stage: 'LEAD',
          ragStatus: 'GREEN',
          createdAt: new Date().toISOString()
        };
        inMemoryClients.unshift(createdClient);
        return res.status(201).json({ success: true, client: createdClient });
      }

      const { data: client, error } = await supabase
        .from('clients')
        .insert({
          user_id: userId,
          full_name: clientData.fullName,
          phone: clientData.phone,
          email: clientData.email,
          address: clientData.address,
          region: clientData.region,
          institution_id: clientData.institutionId,
          institution_member_id: clientData.institutionMemberId,
          stage: 'LEAD',
          rag_status: 'GREEN',
          selected_package_id: clientData.selectedPackageId,
          total_contract_gmd: clientData.totalContractGMD,
          deposit_paid_gmd: clientData.depositPaidGMD || 0,
          outstanding_gmd: clientData.outstandingGMD,
          deduction_status: clientData.deductionStatus || 'NOT_APPLICABLE',
          monthly_deduction_gmd: clientData.monthlyDeductionGMD,
          gdpr_consent: clientData.gdprConsent,
          notes: clientData.notes
        })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json({ success: true, client });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);

// 4. PUT /api/v2/clients/:id - Update client record
clientRouter.put(
  '/:id',
  requireAuth,
  requireRole(['admin', 'project_manager', 'finance_officer']),
  validateBody(updateClientSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const supabase = getSupabaseAdminClient();

      if (supabase) {
        const updatePayload: Record<string, any> = {
          updated_at: new Date().toISOString()
        };
        if (updates.fullName) updatePayload.full_name = updates.fullName;
        if (updates.phone) updatePayload.phone = updates.phone;
        if (updates.email !== undefined) updatePayload.email = updates.email;
        if (updates.address) updatePayload.address = updates.address;
        if (updates.region) updatePayload.region = updates.region;
        if (updates.institutionId !== undefined) updatePayload.institution_id = updates.institutionId;
        if (updates.institutionMemberId !== undefined) updatePayload.institution_member_id = updates.institutionMemberId;
        if (updates.stage) updatePayload.stage = updates.stage;
        if (updates.ragStatus) updatePayload.rag_status = updates.ragStatus;
        if (updates.selectedPackageId) updatePayload.selected_package_id = updates.selectedPackageId;
        if (updates.totalContractGMD) updatePayload.total_contract_gmd = updates.totalContractGMD;
        if (updates.depositPaidGMD !== undefined) updatePayload.deposit_paid_gmd = updates.depositPaidGMD;
        if (updates.outstandingGMD !== undefined) updatePayload.outstanding_gmd = updates.outstandingGMD;
        if (updates.deductionStatus) updatePayload.deduction_status = updates.deductionStatus;
        if (updates.monthlyDeductionGMD !== undefined) updatePayload.monthly_deduction_gmd = updates.monthlyDeductionGMD;
        if (updates.notes !== undefined) updatePayload.notes = updates.notes;

        const { data: client, error } = await supabase
          .from('clients')
          .update(updatePayload)
          .eq('id', id)
          .select()
          .single();

        if (error) throw error;
        return res.json({ success: true, message: 'Client record updated', client });
      }

      const match = inMemoryClients.find((c) => c.id === id);
      if (!match) return res.status(404).json({ success: false, error: 'Client not found' });
      Object.assign(match, updates);

      return res.json({ success: true, message: 'Client record updated in local cache', client: match });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);

// 5. DELETE /api/v2/clients/:id - Delete client record (Admin only)
clientRouter.delete(
  '/:id',
  requireAuth,
  requireRole(['admin']),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const supabase = getSupabaseAdminClient();

      if (supabase) {
        const { error } = await supabase.from('clients').delete().eq('id', id);
        if (error) throw error;
      } else {
        const idx = inMemoryClients.findIndex((c) => c.id === id);
        if (idx !== -1) inMemoryClients.splice(idx, 1);
      }

      return res.json({ success: true, message: `Client ${id} deleted successfully` });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }
);
