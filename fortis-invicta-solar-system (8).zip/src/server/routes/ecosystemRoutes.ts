import { Router, Request, Response } from 'express';
import { DirectusService } from '../integrations/directusService.js';
import { ERPNextService } from '../integrations/erpnextService.js';
import { MoodleService } from '../integrations/moodleService.js';
import { ThingsBoardService } from '../integrations/thingsboardService.js';
import { PostalService } from '../integrations/postalService.js';
import { OpenSearchService } from '../integrations/opensearchService.js';
import { requireAuth, requireRole, AuthenticatedRequest } from '../auth.js';

export const ecosystemRouter = Router();

// =========================================================================
// 1. DIRECTUS CMS ENDPOINTS
// =========================================================================
ecosystemRouter.get('/directus/packages', async (req: Request, res: Response) => {
  try {
    const packages = await DirectusService.getSolarPackages();
    res.json({ source: 'directus_cms', data: packages });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

ecosystemRouter.get('/directus/articles', async (req: Request, res: Response) => {
  try {
    const articles = await DirectusService.getArticles();
    res.json({ source: 'directus_cms', data: articles });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// =========================================================================
// 2. ERPNEXT ERP & HR ENDPOINTS
// =========================================================================
ecosystemRouter.post('/erpnext/customers/sync', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const syncResult = await ERPNextService.syncCustomer(req.body);
    res.json({ success: true, erpStatus: syncResult });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

ecosystemRouter.post('/erpnext/invoices', requireAuth, requireRole(['finance_officer', 'super_admin']), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const invoiceResult = await ERPNextService.createSalesInvoice(req.body);
    res.json({ success: true, invoice: invoiceResult });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

ecosystemRouter.get('/erpnext/inventory', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const inventory = await ERPNextService.getInventoryLevels();
    res.json({ source: 'erpnext', data: inventory });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

ecosystemRouter.get('/erpnext/employees', async (req: Request, res: Response) => {
  try {
    const employees = await ERPNextService.getEmployees();
    res.json({ source: 'erpnext_hr', data: employees });
  } catch (err: any) {
    res.status(503).json({ error: `Service Offline: ERPNext on ${ERPNextService['getBaseUrl'] ? (ERPNextService as any).getBaseUrl() : 'http://localhost:8000'}: ${err.message}` });
  }
});

// =========================================================================
// 3. MOODLE LMS ENDPOINTS
// =========================================================================
ecosystemRouter.get('/moodle/certifications', async (req: Request, res: Response) => {
  try {
    const email = req.query.email as string | undefined;
    const certs = await MoodleService.getTechnicianCertifications(email);
    res.json({ source: 'moodle_academy', data: certs });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

ecosystemRouter.get('/moodle/courses', async (req: Request, res: Response) => {
  try {
    const courses = await MoodleService.getAvailableCourses();
    res.json({ source: 'moodle_academy', data: courses });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// =========================================================================
// 4. THINGSBOARD IOT TELEMETRY ENDPOINTS
// =========================================================================
ecosystemRouter.get('/thingsboard/telemetry/:deviceId', async (req: Request, res: Response) => {
  try {
    const telemetry = await ThingsBoardService.getLiveTelemetry(req.params.deviceId);
    res.json({ source: 'thingsboard_iot', telemetry });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

ecosystemRouter.post('/thingsboard/telemetry', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { deviceId, ...telemetry } = req.body;
    const ok = await ThingsBoardService.sendTelemetry(deviceId || 'solar-inverter-001', telemetry);
    res.json({ success: ok });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// =========================================================================
// 5. POSTAL TRANSACTIONAL MAIL ENDPOINTS
// =========================================================================
ecosystemRouter.post('/postal/send', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = await PostalService.sendEmail(req.body);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// =========================================================================
// 6. OPENSEARCH CENTRAL AUDIT ENDPOINTS
// =========================================================================
ecosystemRouter.post('/opensearch/audit', async (req: Request, res: Response) => {
  try {
    const event = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      ...req.body
    };
    const indexed = await OpenSearchService.indexAuditEvent(event);
    res.json({ success: indexed, eventId: event.id });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

ecosystemRouter.get('/opensearch/query', requireAuth, requireRole(['super_admin', 'finance_officer']), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const q = (req.query.q as string) || '*';
    const limit = Number(req.query.limit) || 50;
    const logs = await OpenSearchService.queryLogs(q, limit);
    res.json({ source: 'opensearch', data: logs });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
