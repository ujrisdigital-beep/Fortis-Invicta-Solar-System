import { Router, Response } from 'express';
import crypto from 'crypto';
import { AuthenticatedRequest, requireAuth, requireRole } from '../auth.js';
import { validateBody, manualPaymentRateLimiter } from '../security.js';
import { manualPaymentSubmitSchema, verifyPaymentSchema } from '../validationSchemas.js';
import { getSupabaseAdminClient } from '../../db/supabaseClient.js';
import { PostalService } from '../integrations/postalService.js';

export const paymentRouter = Router();

export interface PaymentTransactionRecord {
  id: string;
  clientId: string;
  clientName?: string;
  amountGMD: number;
  paymentType: string;
  paymentMethod: 'DIRECT_TRANSFER' | 'BANK_TELLER';
  channel: string;
  status: 'PENDING_VERIFICATION' | 'APPROVED' | 'REJECTED' | 'CONFIRMED' | 'SETTLED';
  tellerReferenceNumber: string;
  tellerReceiptUrl?: string | null;
  bankName: string;
  accountNumber: string;
  depositDate?: string;
  adminNotes?: string | null;
  confirmedAt?: string | null;
  confirmedBy?: string | null;
  createdAt: string;
}

// Helper: Upload teller receipt to Supabase Storage bucket 'teller-receipts'
async function uploadReceiptToSupabaseStorage(
  supabase: any,
  base64Data: string,
  fileName: string
): Promise<string | null> {
  try {
    const base64Content = base64Data.includes(';base64,')
      ? base64Data.split(';base64,')[1]
      : base64Data;
    const mimeType = base64Data.includes('data:')
      ? base64Data.split(';')[0].replace('data:', '')
      : 'image/jpeg';
    const buffer = Buffer.from(base64Content, 'base64');

    const bucketName = 'teller-receipts';
    const filePath = `receipts/${Date.now()}-${fileName.replace(/[^a-zA-Z0-9.-]/g, '_')}`;

    const { error } = await supabase.storage
      .from(bucketName)
      .upload(filePath, buffer, {
        contentType: mimeType,
        upsert: true
      });

    if (error) {
      console.warn('[Supabase Storage] Bucket upload notice:', error.message);
      return null;
    }

    const { data: publicUrlData } = supabase.storage.from(bucketName).getPublicUrl(filePath);
    return publicUrlData?.publicUrl || null;
  } catch (err: any) {
    console.warn('[Supabase Storage] Error processing receipt upload:', err.message);
    return null;
  }
}

// 1. GET /api/v2/payments/config & /api/payments/config - Operational Bank Details for Clients
paymentRouter.get('/config', (req: any, res: Response) => {
  res.json({
    success: true,
    paymentMode: 'MANUAL_BANK_TRANSFER',
    gatewayNotice: 'Direct Bank Wire / Over-the-Counter Branch Teller Deposit is the official active payment channel.',
    bankName: 'Ecobank Gambia Ltd',
    accountName: 'FORTIS INVICTA LIMITED',
    currency: 'GMD',
    acceptedMethods: ['DIRECT_TRANSFER', 'BANK_TELLER'],
    instructions: 'Transfer to Fortis Invicta at Ecobank Gambia Ltd, then upload the teller reference and photo slip in the client portal for immediate finance verification.'
  });
});

// 2. POST /api/v2/payments/manual-submit - User Submits Teller / Wire Notice (Authoritative DB Only)
paymentRouter.post(
  '/manual-submit',
  manualPaymentRateLimiter,
  validateBody(manualPaymentSubmitSchema),
  async (req: any, res: Response) => {
    const supabase = getSupabaseAdminClient();
    if (!supabase) {
      return res.status(503).json({
        success: false,
        error: {
          code: 'DATABASE_UNAVAILABLE',
          message: 'Authoritative financial database is temporarily unavailable. Transaction rejected to protect payment auditability.'
        }
      });
    }

    try {
      const p = req.body;
      const cleanRef = p.tellerReferenceNumber.trim().toUpperCase();

      // Idempotency: verify no duplicate teller reference has been submitted
      const { data: duplicate } = await supabase
        .from('payments')
        .select('id, status, teller_reference_number')
        .eq('teller_reference_number', cleanRef)
        .maybeSingle();

      if (duplicate) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'DUPLICATE_PAYMENT_REFERENCE',
            message: `A payment with reference ${cleanRef} has already been registered (Status: ${duplicate.status}). Duplicate submissions are blocked.`
          }
        });
      }

      let finalReceiptUrl = p.tellerReceiptUrl || null;

      if (p.tellerReceiptBase64) {
        const uploadedUrl = await uploadReceiptToSupabaseStorage(
          supabase,
          p.tellerReceiptBase64,
          `receipt-${cleanRef}.jpg`
        );
        if (uploadedUrl) {
          finalReceiptUrl = uploadedUrl;
        }
      }

      const paymentRecord = {
        id: `pay-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
        client_id: p.clientId,
        amount_gmd: Number(p.amountGMD),
        payment_type: p.paymentType || '80% System Deposit',
        payment_method: p.paymentMethod || 'DIRECT_TRANSFER',
        channel: 'BANK_TRANSFER',
        status: 'PENDING_VERIFICATION',
        teller_reference_number: cleanRef,
        teller_receipt_url: finalReceiptUrl,
        admin_notes: p.notes || null,
        created_at: new Date().toISOString()
      };

      const { data, error } = await supabase
        .from('payments')
        .insert(paymentRecord)
        .select()
        .single();

      if (error || !data) {
        console.error('[Payment Insert Error]:', error);
        return res.status(500).json({
          success: false,
          error: {
            code: 'PAYMENT_INSERT_FAILED',
            message: `Database failed to record payment notice: ${error?.message || 'Unknown database error'}. No money was registered.`
          }
        });
      }

      // Record Audit Log for payment notice
      await supabase.from('audit_logs').insert({
        user_id: req.user?.id || null,
        actor_name: p.clientName || 'Client User',
        actor_role: 'client',
        action: 'PAYMENT_NOTICE_SUBMITTED',
        details: {
          paymentId: paymentRecord.id,
          clientId: p.clientId,
          amountGMD: paymentRecord.amount_gmd,
          tellerReferenceNumber: cleanRef
        }
      });

      return res.status(201).json({
        success: true,
        message: `Payment notice of GMD ${paymentRecord.amount_gmd.toLocaleString()} submitted successfully. Awaiting Finance verification.`,
        payment: data
      });
    } catch (err: any) {
      console.error('[Manual Payment Submit Error]:', err);
      return res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_SERVER_ERROR',
          message: err.message || 'Failed to submit payment notice'
        }
      });
    }
  }
);

// 3. PATCH /api/v2/payments/:id/verify - Finance Officer / Admin Review (Atomic & Idempotent)
paymentRouter.patch(
  '/:id/verify',
  requireAuth,
  requireRole(['admin', 'super_admin', 'finance_officer', 'project_manager']),
  validateBody(verifyPaymentSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    const supabase = getSupabaseAdminClient();
    if (!supabase) {
      return res.status(503).json({
        success: false,
        error: {
          code: 'DATABASE_UNAVAILABLE',
          message: 'Authoritative database is not connected. Verification aborted.'
        }
      });
    }

    try {
      const { id } = req.params;
      const { status, adminNotes } = req.body;
      const reviewerName = req.user?.fullName || 'Finance Officer';
      const reviewerId = req.user?.id;
      const now = new Date().toISOString();

      // Retrieve existing payment from authoritative DB
      const { data: existingPayment, error: fetchErr } = await supabase
        .from('payments')
        .select('*')
        .eq('id', id)
        .single();

      if (fetchErr || !existingPayment) {
        return res.status(404).json({
          success: false,
          error: {
            code: 'PAYMENT_NOT_FOUND',
            message: `Payment transaction #${id} was not found in the authoritative ledger.`
          }
        });
      }

      // Idempotency: Reject if already in target status or settled
      if (existingPayment.status === status) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'PAYMENT_ALREADY_PROCESSED',
            message: `This payment is already in status ${status}. No duplicate modification made.`
          }
        });
      }

      if (existingPayment.status === 'APPROVED' && status === 'PENDING_VERIFICATION') {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_STATE_TRANSITION',
            message: 'Cannot revert an approved payment to pending verification.'
          }
        });
      }

      // 1. Update Payment Status
      const { error: updateErr } = await supabase
        .from('payments')
        .update({
          status: status,
          admin_notes: adminNotes || existingPayment.admin_notes,
          confirmed_at: status === 'APPROVED' ? now : null,
          confirmed_by: status === 'APPROVED' ? reviewerName : null
        })
        .eq('id', id);

      if (updateErr) {
        return res.status(500).json({
          success: false,
          error: {
            code: 'PAYMENT_UPDATE_FAILED',
            message: updateErr.message
          }
        });
      }

      // 2. If APPROVED, update client financial ledger
      if (status === 'APPROVED' && existingPayment.client_id) {
        const { data: client } = await supabase
          .from('clients')
          .select('id, total_contract_gmd, deposit_paid_gmd')
          .eq('id', existingPayment.client_id)
          .single();

        if (client) {
          const currentDeposit = Number(client.deposit_paid_gmd || 0);
          const paymentAmount = Number(existingPayment.amount_gmd || 0);
          const newDeposit = currentDeposit + paymentAmount;
          const contractTotal = Number(client.total_contract_gmd || 0);
          const newOutstanding = Math.max(0, contractTotal - newDeposit);
          const newStage = newDeposit >= contractTotal * 0.80 ? 'EQUIPMENT_ALLOCATED' : 'DEPOSIT_RECEIVED';

          await supabase
            .from('clients')
            .update({
              deposit_paid_gmd: newDeposit,
              outstanding_gmd: newOutstanding,
              stage: newStage
            })
            .eq('id', existingPayment.client_id);
        }
      }

      // 3. Write Immutable Audit Log
      await supabase.from('audit_logs').insert({
        user_id: reviewerId,
        actor_name: reviewerName,
        actor_role: req.user?.role || 'finance_officer',
        action: `PAYMENT_${status}`,
        details: {
          paymentId: id,
          amountGMD: existingPayment.amount_gmd,
          tellerReferenceNumber: existingPayment.teller_reference_number,
          previousStatus: existingPayment.status,
          newStatus: status,
          adminNotes
        }
      });

      // 4. If APPROVED, automatically dispatch invoice notification via Postal Mail Server
      let postalResult: any = null;
      if (status === 'APPROVED' && existingPayment.client_id) {
        try {
          const { data: clientData } = await supabase
            .from('clients')
            .select('email, full_name, selected_package_id')
            .eq('id', existingPayment.client_id)
            .maybeSingle();

          const targetEmail = clientData?.email || req.body.clientEmail;
          const targetName = clientData?.full_name || existingPayment.client_name || 'Valued Solar Client';
          const invNum = `INV-FI-${id.toUpperCase().slice(-6)}`;
          const formattedGMD = `GMD ${Number(existingPayment.amount_gmd || 0).toLocaleString()}`;

          if (targetEmail) {
            const htmlBody = `
              <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 650px; margin: auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 16px; background: #ffffff; color: #0f172a;">
                <div style="border-bottom: 3px solid #1B4D3E; padding-bottom: 16px; margin-bottom: 20px;">
                  <h1 style="color: #1B4D3E; margin: 0; font-size: 20px; font-weight: 800;">FORTIS INVICTA LTD</h1>
                  <p style="color: #64748b; font-size: 11px; margin: 4px 0 0 0; text-transform: uppercase;">Official Solar Payment Receipt & Commercial Invoice</p>
                </div>
                <p style="font-size: 14px; color: #334155;">Dear <strong>${targetName}</strong>,</p>
                <p style="font-size: 14px; color: #334155; line-height: 1.6;">
                  We are pleased to inform you that your payment of <strong style="color: #1B4D3E;">${formattedGMD}</strong> has been officially approved and verified by the Fortis Invicta Finance Division.
                </p>
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; margin: 20px 0; font-size: 12px;">
                  <table style="width: 100%;">
                    <tr><td style="color:#64748b; padding: 4px 0;">Invoice Number:</td><td style="font-weight: bold; font-family: monospace; text-align: right;">${invNum}</td></tr>
                    <tr><td style="color:#64748b; padding: 4px 0;">Ecobank Ref:</td><td style="font-weight: bold; font-family: monospace; text-align: right;">${existingPayment.teller_reference_number}</td></tr>
                    <tr><td style="color:#64748b; padding: 4px 0;">Verified Amount:</td><td style="font-weight: 800; color: #1B4D3E; font-size: 14px; text-align: right;">${formattedGMD}</td></tr>
                    <tr><td style="color:#64748b; padding: 4px 0;">Status:</td><td style="color: #166534; font-weight: bold; text-align: right;">✓ APPROVED & RECONCILED</td></tr>
                  </table>
                </div>
                <p style="font-size: 12px; color: #64748b;">
                  Your equipment allocation is now active. You may download or print your official stamped PDF invoice from the Fortis Solar portal.
                </p>
                <hr style="border: none; border-top: 1px solid #f1f5f9; margin: 20px 0;" />
                <p style="font-size: 10px; color: #94a3b8; text-align: center;">Fortis Invicta Ltd • Ecobank Merchant #505825057 • Dispatched via Postal</p>
              </div>
            `;

            postalResult = await PostalService.sendEmail({
              to: [targetEmail],
              subject: `[Fortis Invicta] Invoice & Payment Confirmation - ${invNum} (${formattedGMD})`,
              htmlBody,
              plainBody: `Payment of ${formattedGMD} verified. Invoice ${invNum}. Reference: ${existingPayment.teller_reference_number}.`
            });
          }
        } catch (postalErr: any) {
          console.warn('[Postal Auto-Dispatch Warning]:', postalErr?.message);
        }
      }

      return res.json({
        success: true,
        message: `Payment transaction #${id} marked as ${status} by ${reviewerName}.${postalResult ? ' Invoice sent via Postal.' : ''}`,
        postalDispatched: !!postalResult,
        payment: {
          ...existingPayment,
          status,
          adminNotes,
          confirmedAt: status === 'APPROVED' ? now : null,
          confirmedBy: status === 'APPROVED' ? reviewerName : null
        }
      });
    } catch (err: any) {
      console.error('[Verify Payment Error]:', err);
      return res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_SERVER_ERROR',
          message: err.message || 'Failed to verify payment'
        }
      });
    }
  }
);

// 3.5 POST /api/v2/payments/:id/send-invoice - Explicitly Send Formatted PDF/HTML Invoice via Postal
paymentRouter.post(
  '/:id/send-invoice',
  requireAuth,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { clientEmail, clientName, invoiceHtml, amountGMD, referenceNumber, packageName } = req.body;

      if (!clientEmail) {
        return res.status(400).json({ success: false, error: 'Recipient clientEmail is required' });
      }

      const invNum = `INV-FI-${id.toUpperCase().slice(-6)}`;
      const formattedAmount = `GMD ${Number(amountGMD || 0).toLocaleString()}`;

      const defaultHtmlBody = `
        <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 680px; margin: auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 16px; background: #ffffff; color: #0f172a;">
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #1B4D3E; padding-bottom: 16px; margin-bottom: 20px;">
            <div>
              <h1 style="color: #1B4D3E; margin: 0; font-size: 20px; font-weight: 800;">FORTIS INVICTA LTD</h1>
              <p style="color: #64748b; font-size: 11px; margin: 4px 0 0 0; text-transform: uppercase;">The Command HQ • Commercial Solar Power</p>
            </div>
            <div style="text-align: right;">
              <span style="display: inline-block; background: #f0fdf4; color: #166534; font-size: 11px; font-weight: 800; padding: 4px 10px; border-radius: 20px; border: 1px solid #bbf7d0;">
                ✓ INVOICE ATTACHED
              </span>
              <div style="font-family: monospace; font-size: 11px; color: #C9A84C; font-weight: 700; margin-top: 4px;">${invNum}</div>
            </div>
          </div>

          <p style="font-size: 14px; color: #334155;">Dear <strong>${clientName || 'Valued Client'}</strong>,</p>
          <p style="font-size: 14px; color: #334155; line-height: 1.6;">
            Please find attached your official commercial solar invoice and payment reconciliation record for <strong style="color: #1B4D3E;">${formattedAmount}</strong>.
          </p>

          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px; margin: 20px 0; font-size: 12px;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 6px 0; color: #64748b;">Invoice Reference:</td>
                <td style="padding: 6px 0; font-weight: 700; font-family: monospace; text-align: right;">${invNum}</td>
              </tr>
              <tr>
                <td style="padding: 6px 0; color: #64748b;">Ecobank Transaction Ref:</td>
                <td style="padding: 6px 0; font-weight: 700; font-family: monospace; text-align: right;">${referenceNumber || 'ECO-REF'}</td>
              </tr>
              ${packageName ? `
              <tr>
                <td style="padding: 6px 0; color: #64748b;">Solar System:</td>
                <td style="padding: 6px 0; font-weight: 600; text-align: right;">${packageName}</td>
              </tr>` : ''}
              <tr style="border-top: 1px solid #cbd5e1;">
                <td style="padding: 10px 0; font-weight: 700; font-size: 13px;">Invoiced / Received:</td>
                <td style="padding: 10px 0; font-weight: 800; font-size: 15px; color: #1B4D3E; text-align: right; font-family: monospace;">${formattedAmount}</td>
              </tr>
            </table>
          </div>

          <p style="font-size: 12px; color: #64748b; line-height: 1.5;">
            Thank you for partnering with Fortis Invicta. For questions or system scheduling, reach our operations desk at <a href="mailto:info@fortisinvicta.co.uk" style="color: #1B4D3E;">info@fortisinvicta.co.uk</a>.
          </p>

          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 24px 0 16px 0;" />
          <div style="text-align: center; font-size: 10px; color: #94a3b8;">
            Fortis Invicta Ltd • Banjul, The Gambia • Sent via Postal Transactional Gateway
          </div>
        </div>
      `;

      const attachments = invoiceHtml ? [
        {
          name: `${invNum}.html`,
          contentType: 'text/html',
          data: Buffer.from(invoiceHtml).toString('base64')
        }
      ] : undefined;

      const result = await PostalService.sendEmail({
        to: [clientEmail],
        subject: `[Fortis Invicta] Commercial Invoice - ${invNum} (${formattedAmount})`,
        htmlBody: defaultHtmlBody,
        plainBody: `Fortis Invicta Commercial Invoice ${invNum}. Amount: ${formattedAmount}. Ref: ${referenceNumber || ''}`,
        attachments
      });

      return res.json({
        success: true,
        message: `Invoice ${invNum} dispatched to ${clientEmail} via Postal Mail Server.`,
        messageId: result.messageId,
        invoiceNumber: invNum
      });
    } catch (err: any) {
      console.error('[Send Invoice Error]:', err);
      return res.status(500).json({
        success: false,
        error: err.message || 'Failed to dispatch invoice via Postal'
      });
    }
  }
);

// 4. GET /api/v2/payments - List Payments with Mandatory Authentication & Role Isolation
paymentRouter.get(
  '/',
  requireAuth,
  async (req: AuthenticatedRequest, res: Response) => {
    const supabase = getSupabaseAdminClient();
    if (!supabase) {
      return res.status(503).json({
        success: false,
        error: {
          code: 'DATABASE_UNAVAILABLE',
          message: 'Authoritative database is not available. Cannot fetch payment records.'
        }
      });
    }

    try {
      const { status, clientId } = req.query;
      let query = supabase.from('payments').select('*').order('created_at', { ascending: false });

      // Role-Based Isolation
      if (req.user?.role === 'client') {
        // Client can only view their own payments
        query = query.eq('client_id', req.user.id);
      } else if (req.user?.role === 'institutional_admin') {
        // Institutional admin sees payments related to their institution
        if (req.user.institutionId) {
          // If institutionId matches, filter by clients belonging to that union
          const { data: unionClients } = await supabase
            .from('clients')
            .select('id')
            .eq('union_branch', req.user.institutionId);
          const unionClientIds = (unionClients || []).map((c: any) => c.id);
          query = query.in('client_id', unionClientIds.length > 0 ? unionClientIds : ['__none__']);
        }
      } else if (clientId && ['admin', 'super_admin', 'finance_officer', 'project_manager'].includes(req.user?.role || '')) {
        query = query.eq('client_id', String(clientId));
      }

      if (status) {
        query = query.eq('status', String(status).toUpperCase());
      }

      const { data, error } = await query;
      if (error) {
        return res.status(500).json({
          success: false,
          error: {
            code: 'DATABASE_QUERY_FAILED',
            message: error.message
          }
        });
      }

      return res.json({ success: true, payments: data || [] });
    } catch (err: any) {
      return res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_SERVER_ERROR',
          message: err.message || 'Failed to list payments'
        }
      });
    }
  }
);


