import { z } from 'zod';

// ==========================================
// 1. Authentication Schemas
// ==========================================
export const signupValidationSchema = z.object({
  email: z.string().email('Invalid email address format').toLowerCase().trim(),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number')
    .regex(/[^a-zA-Z0-9]/, 'Password must contain at least one special character'),
  fullName: z.string().min(2, 'Full name must be at least 2 characters').trim(),
  role: z.enum(['client', 'engineer', 'project_manager', 'finance_officer', 'institutional_admin', 'admin']).default('client'),
  institutionId: z.string().optional().nullable(),
  phone: z.string().min(7, 'Phone number must be at least 7 digits').optional().nullable()
});

export const loginValidationSchema = z.object({
  email: z.string().email('Invalid email address format').toLowerCase().trim(),
  password: z.string().min(1, 'Password is required')
});

export const refreshTokenValidationSchema = z.object({
  refreshToken: z.string().min(10, 'Refresh token is required')
});

export const verifyEmailValidationSchema = z.object({
  email: z.string().email('Invalid email address format').toLowerCase().trim(),
  code: z.string().min(4, 'Verification code is required').max(10).trim()
});

export const resendVerificationValidationSchema = z.object({
  email: z.string().email('Invalid email address format').toLowerCase().trim()
});

// ==========================================
// 2. Client & Project Creation Schemas
// ==========================================
export const createClientSchema = z.object({
  fullName: z.string().min(2, 'Full legal name is required').trim(),
  phone: z.string().min(7, 'Phone number is required').trim(),
  email: z.string().email('Invalid client email').optional().nullable(),
  address: z.string().min(3, 'Physical installation address is required'),
  region: z.string().min(2, 'Geographic region is required'),
  institutionId: z.string().optional().nullable(),
  institutionMemberId: z.string().optional().nullable(),
  selectedPackageId: z.enum(['basic_backup', 'hybrid_standard', 'executive_premium', 'commercial_heavy']),
  totalContractGMD: z.number().positive('Total contract value must be greater than 0'),
  depositPaidGMD: z.number().nonnegative('Deposit cannot be negative').default(0),
  outstandingGMD: z.number().nonnegative('Outstanding amount cannot be negative'),
  deductionStatus: z.enum(['NOT_APPLICABLE', 'PENDING_SUBMISSION', 'SUBMITTED_TO_UNION', 'PRE_APPROVED', 'ACTIVE_DEDUCTION', 'COMPLETED', 'DEFAULTED']).default('NOT_APPLICABLE'),
  monthlyDeductionGMD: z.number().nonnegative().optional().nullable(),
  gdprConsent: z.boolean().default(true),
  notes: z.string().optional().nullable()
});

export const createProjectSchema = z.object({
  clientId: z.string().uuid('Valid Client ID is required'),
  assignedEngineerId: z.string().uuid().optional().nullable(),
  packageId: z.string().min(1, 'Package ID is required'),
  packageName: z.string().min(1, 'Package Name is required'),
  systemCapacityKVA: z.number().positive('System capacity must be greater than 0'),
  batteryCapacityKWh: z.number().positive('Battery capacity must be greater than 0'),
  stage: z.enum(['LEAD', 'SITE_SURVEY', 'PROPOSAL_APPROVED', 'DEPOSIT_RECEIVED', 'EQUIPMENT_ALLOCATED', 'INSTALLATION_IN_PROGRESS', 'COMMISSIONED', 'MAINTENANCE']).default('LEAD'),
  warrantyYears: z.number().int().min(1).default(5),
  gpsLatitude: z.number().optional().nullable(),
  gpsLongitude: z.number().optional().nullable()
});

// ==========================================
// 3. Payment Record Schema (Ecobank & Manual Bank Transfer)
// ==========================================
export const manualPaymentSubmitSchema = z.object({
  clientId: z.string().min(1, 'Client ID is required'),
  clientName: z.string().optional().nullable(),
  amountGMD: z.number().positive('Payment amount must be greater than 0'),
  paymentType: z.string().min(2, 'Payment type is required (e.g., 80% System Deposit)'),
  paymentMethod: z.enum(['DIRECT_TRANSFER', 'BANK_TELLER']).default('DIRECT_TRANSFER'),
  tellerReferenceNumber: z.string().min(3, 'Transaction/Teller reference number is required').trim(),
  tellerReceiptUrl: z.string().optional().nullable(),
  tellerReceiptBase64: z.string().optional().nullable(),
  bankName: z.string().default('Ecobank Gambia Ltd'),
  accountNumber: z.string().default('6240019284'),
  depositDate: z.string().optional().nullable(),
  notes: z.string().optional().nullable()
});

export const verifyPaymentSchema = z.object({
  status: z.enum(['APPROVED', 'REJECTED']),
  adminNotes: z.string().optional().nullable()
});

export const recordPaymentSchema = z.object({
  clientId: z.string().min(1, 'Client ID is required'),
  amountGMD: z.number().positive('Payment amount must be greater than 0'),
  paymentType: z.enum(['80% System Deposit', '20% Balance Payment', 'Full Cash Payment', 'Institutional Salary Deduction']),
  channel: z.enum(['ECOBANK_PAY', 'BANK_TRANSFER', 'CASH_OFFICE', 'SALARY_DEDUCTION']).default('BANK_TRANSFER'),
  paymentMethod: z.enum(['DIRECT_TRANSFER', 'BANK_TELLER']).default('DIRECT_TRANSFER'),
  transactionRef: z.string().min(3, 'Transaction reference is required'),
  tellerReferenceNumber: z.string().optional().nullable(),
  ecobankMerchantCode: z.string().default('505825057'),
  ecobankTerminalId: z.string().default('32680928'),
  tellerReceiptUrl: z.string().optional().nullable()
});

// ==========================================
// 4. Site Assessment Schema
// ==========================================
export const siteAssessmentSchema = z.object({
  clientId: z.string().min(1, 'Client ID is required'),
  assessorId: z.string().optional().nullable(),
  roofType: z.enum(['Corrugated Metal', 'Concrete Flat Slab', 'Clay Tile', 'Ground Mount Structure']),
  roofAzimuthDegrees: z.number().min(0).max(360).default(180),
  tiltAngleDegrees: z.number().min(0).max(90).default(15),
  shadingLevel: z.enum(['none', 'low', 'medium', 'heavy']).default('none'),
  nawecGridStability: z.enum(['Stable (>20h/day)', 'Intermittent (10-18h/day)', 'Severe Outages (<8h/day)', 'Total Off-Grid']),
  dailyEnergyKWh: z.number().positive('Daily energy consumption must be positive'),
  recommendedKVA: z.number().positive('Recommended kVA must be positive'),
  recommendedPanels: z.number().int().positive('Panel count must be at least 1'),
  recommendedBatteries: z.number().int().nonnegative('Battery count must be 0 or more'),
  notes: z.string().optional().nullable()
});

// ==========================================
// 5. Verification Record Schema
// ==========================================
export const verifyMemberSchema = z.object({
  institutionId: z.string().min(2, 'Institution identifier is required (e.g., GTUCCU, NAGNMC)').trim(),
  memberId: z.string().min(2, 'Member ID is required').trim()
});
