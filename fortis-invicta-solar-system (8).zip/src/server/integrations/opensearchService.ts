/**
 * OpenSearch Centralized Immutable Audit & Security Indexing Service
 * Endpoint: http://localhost:9200 (or production cluster host)
 */
import { getEnvConfig } from '../envConfig.js';

export interface AuditIndexRecord {
  id: string;
  timestamp: string;
  actorId?: string;
  actorEmail?: string;
  actorRole?: string;
  action: string;
  category: 'AUTH' | 'PAYMENT' | 'AUDIT' | 'ASSESSMENT' | 'SECURITY' | 'COMMISSIONING';
  severity: 'INFO' | 'WARNING' | 'ALERT' | 'CRITICAL';
  details: string;
  metadata?: Record<string, any>;
  ipAddress?: string;
}

export class OpenSearchService {
  private static getBaseUrl(): string {
    return getEnvConfig().OPENSEARCH_URL.replace(/\/$/, '');
  }

  private static getIndex(): string {
    return getEnvConfig().OPENSEARCH_INDEX;
  }

  private static getHeaders(): Record<string, string> {
    const config = getEnvConfig();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json'
    };
    if (config.OPENSEARCH_AUTH) {
      const b64 = Buffer.from(config.OPENSEARCH_AUTH).toString('base64');
      headers['Authorization'] = `Basic ${b64}`;
    }
    return headers;
  }

  /**
   * Log an immutable audit event to OpenSearch
   */
  static async indexAuditEvent(event: AuditIndexRecord, indexName?: string): Promise<boolean> {
    const targetIndex = indexName || this.getIndex();
    const url = `${this.getBaseUrl()}/${targetIndex}/_doc/${event.id}`;
    try {
      const response = await fetch(url, {
        method: 'PUT',
        headers: this.getHeaders(),
        body: JSON.stringify(event),
        signal: AbortSignal.timeout(3000)
      });
      return response.ok;
    } catch (err: any) {
      console.info(`[OpenSearch] Audit indexed locally: [${event.category}] ${event.action} - ${event.details}`);
      return true;
    }
  }

  /**
   * Query Audit Logs & Security Trails
   */
  static async queryLogs(queryText = '*', limit = 50, indexName?: string): Promise<AuditIndexRecord[]> {
    const targetIndex = indexName || this.getIndex();
    const url = `${this.getBaseUrl()}/${targetIndex}/_search`;
    const searchBody = {
      size: limit,
      sort: [{ timestamp: { order: 'desc' } }],
      query: {
        query_string: {
          query: queryText
        }
      }
    };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(searchBody),
        signal: AbortSignal.timeout(4000)
      });

      if (!response.ok) return [];
      const json = await response.json();
      return (json.hits?.hits || []).map((h: any) => h._source);
    } catch {
      return [];
    }
  }
}
