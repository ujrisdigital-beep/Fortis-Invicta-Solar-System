/**
 * ERPNext (Frappe REST API) Production Integration Service
 * Endpoint: https://erp.fortisinvicta.co.uk
 */
import { getEnvConfig } from '../envConfig.js';

export interface ERPNextCustomer {
  customer_name: string;
  customer_type: 'Individual' | 'Company';
  customer_group: string;
  territory: string;
  email_id?: string;
  mobile_no?: string;
}

export interface ERPNextSalesInvoice {
  customer: string;
  posting_date: string;
  due_date: string;
  currency: string;
  items: Array<{
    item_code: string;
    qty: number;
    rate: number;
  }>;
}

export class ERPNextService {
  private static getBaseUrl(): string {
    return getEnvConfig().ERPNEXT_URL.replace(/\/$/, '');
  }

  private static getHeaders(): Record<string, string> {
    const config = getEnvConfig();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    if (config.ERPNEXT_API_KEY && config.ERPNEXT_API_SECRET) {
      headers['Authorization'] = `token ${config.ERPNEXT_API_KEY}:${config.ERPNEXT_API_SECRET}`;
    }
    return headers;
  }

  /**
   * Sync or Create Customer Record in ERPNext
   */
  static async syncCustomer(customer: ERPNextCustomer): Promise<any> {
    const url = `${this.getBaseUrl()}/api/resource/Customer`;
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(customer),
        signal: AbortSignal.timeout(6000)
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`ERPNext status ${response.status}: ${errorText}`);
      }

      const resJson = await response.json();
      return resJson.data;
    } catch (err: any) {
      console.warn(`[ERPNext] Customer sync error: ${err.message}`);
      return { customer_name: customer.customer_name, status: 'synced_locally_pending_erp_sync' };
    }
  }

  /**
   * Submit Sales Invoice to ERPNext
   */
  static async createSalesInvoice(invoice: ERPNextSalesInvoice): Promise<any> {
    const url = `${this.getBaseUrl()}/api/resource/Sales Invoice`;
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(invoice),
        signal: AbortSignal.timeout(6000)
      });

      if (!response.ok) {
        throw new Error(`ERPNext invoice error: ${response.statusText}`);
      }

      const resJson = await response.json();
      return resJson.data;
    } catch (err: any) {
      console.warn(`[ERPNext] Sales Invoice creation error: ${err.message}`);
      return { status: 'queued_for_erp_posting', error: err.message };
    }
  }

  /**
   * Get Active Stock & Inverter Inventory Levels
   */
  static async getInventoryLevels(): Promise<any[]> {
    const url = `${this.getBaseUrl()}/api/resource/Bin?fields=["item_code","actual_qty","warehouse"]&limit_page_length=50`;
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: this.getHeaders(),
        signal: AbortSignal.timeout(5000)
      });

      if (!response.ok) return [];
      const json = await response.json();
      return json.data || [];
    } catch (err: any) {
      console.warn(`[ERPNext] Inventory query error: ${err.message}`);
      return [];
    }
  }

  /**
   * Get Staff / Employee Roster from ERPNext HR
   */
  static async getEmployees(): Promise<any[]> {
    const url = `${this.getBaseUrl()}/api/resource/Employee?fields=["name","employee_name","designation","department","status","cell_number","company_email"]&limit_page_length=100`;
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: this.getHeaders(),
        signal: AbortSignal.timeout(5000)
      });

      if (!response.ok) {
        throw new Error(`ERPNext status ${response.status}: ${response.statusText}`);
      }

      const json = await response.json();
      return json.data || [];
    } catch (err: any) {
      console.warn(`[ERPNext] Employee roster query error: ${err.message}`);
      throw err;
    }
  }
}
