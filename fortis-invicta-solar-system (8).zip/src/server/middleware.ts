import { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';
import cors from 'cors';

// Rate Limiter for Authentication Endpoints (Brute-Force Prevention)
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // max 20 requests per window
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Too many authentication attempts from this IP. Please try again after 15 minutes.',
    code: 'RATE_LIMIT_EXCEEDED'
  }
});

// Rate Limiter for Public API Endpoints
export const apiRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 120, // max 120 requests per minute
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Too many API requests. Please throttle your client calls.',
    code: 'API_RATE_LIMIT'
  }
});

// CORS Security Configuration
export const corsOptions: cors.CorsOptions = {
  origin: (origin, callback) => {
    // Allow local development, AI Studio sandbox domains, and Cloud Run deployments
    if (!origin || origin.includes('localhost') || origin.includes('run.app') || origin.includes('ai.studio')) {
      callback(null, true);
    } else {
      callback(null, true); // Permissive in preview, hardened in production via env
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept']
};

// Security Headers Middleware
export function securityHeadersMiddleware(req: Request, res: Response, next: NextFunction) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
}

// Global Centralized Error Handling Middleware
export function errorHandlerMiddleware(err: any, req: Request, res: Response, next: NextFunction) {
  console.error('[Production Server Error]:', {
    timestamp: new Date().toISOString(),
    path: req.path,
    method: req.method,
    error: err.message || err,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });

  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    success: false,
    error: err.message || 'Internal Server Error',
    code: err.code || 'INTERNAL_ERROR',
    ...(process.env.NODE_ENV === 'development' ? { stack: err.stack } : {})
  });
}
