import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import {
  generateTokenPair,
  verifyAccessToken,
  verifyRefreshToken,
  revokeToken,
  generateAccessToken
} from './jwt.js';
import {
  signupValidationSchema,
  loginValidationSchema,
  refreshTokenValidationSchema,
  verifyEmailValidationSchema,
  resendVerificationValidationSchema
} from './validationSchemas.js';
import { AuthUser, UserRole } from './types.js';
import { getSupabaseAdminClient } from '../db/supabaseClient.js';
import { isDisposableEmail } from './tempMailValidator.js';
import { PostalService } from './integrations/postalService.js';
import { OpenSearchService } from './integrations/opensearchService.js';

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

const SALT_ROUNDS = 12;

export interface InMemUser extends AuthUser {
  passwordHash: string;
  isEmailVerified: boolean;
  verificationCode?: string | null;
  verificationExpiresAt?: string | null;
  createdAt: string;
}

// Pre-seeded verified demo accounts for development, testing, and verified operations
export const usersDB: InMemUser[] = [
  {
    id: 'usr-admin-001',
    email: 'admin@fortisinvicta.gm',
    fullName: 'Amadou Jallow (Super Admin)',
    role: 'super_admin',
    isEmailVerified: true,
    institutionId: null,
    phone: '+220 398 1000',
    passwordHash: bcrypt.hashSync('Fortis2026!Admin', 10),
    createdAt: new Date().toISOString()
  },
  {
    id: 'usr-eng-001',
    email: 'engineer@fortisinvicta.gm',
    fullName: 'Samba Baldeh (Lead Solar Engineer)',
    role: 'engineer',
    isEmailVerified: true,
    institutionId: null,
    phone: '+220 711 4050',
    passwordHash: bcrypt.hashSync('SolarEngineer2026!', 10),
    createdAt: new Date().toISOString()
  },
  {
    id: 'usr-fin-001',
    email: 'finance@fortisinvicta.gm',
    fullName: 'Fatoumatta Ceesay (Finance Controller)',
    role: 'finance_officer',
    isEmailVerified: true,
    institutionId: null,
    phone: '+220 990 2233',
    passwordHash: bcrypt.hashSync('FinanceEcobank2026!', 10),
    createdAt: new Date().toISOString()
  },
  {
    id: 'usr-cli-001',
    email: 'client@example.com',
    fullName: 'Amara Jobe (Verified Client)',
    role: 'client',
    isEmailVerified: true,
    institutionId: 'GTUCCU',
    phone: '+220 784 9210',
    passwordHash: bcrypt.hashSync('SolarClient2026!', 10),
    createdAt: new Date().toISOString()
  },
  {
    id: 'usr-inst-001',
    email: 'gtu.admin@fortisinvicta.gm',
    fullName: 'Ismaila Badjie (GTUCCU Administrator)',
    role: 'institutional_admin',
    isEmailVerified: true,
    institutionId: 'GTUCCU',
    phone: '+220 662 1088',
    passwordHash: bcrypt.hashSync('GTUAdmin2026!', 10),
    createdAt: new Date().toISOString()
  }
];

// Helper: Secure Cookie Setting Options
function getCookieOptions(maxAgeMs: number) {
  const isProduction = process.env.NODE_ENV === 'production';
  return {
    httpOnly: true,
    secure: isProduction,
    sameSite: (isProduction ? 'strict' : 'lax') as 'strict' | 'lax',
    path: '/',
    maxAge: maxAgeMs
  };
}

// Middleware: Require Authentication (JWT Bearer or HTTP-only Cookie)
export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  let token: string | undefined;

  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  } else if (req.cookies && req.cookies.accessToken) {
    token = req.cookies.accessToken;
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      error: 'Authentication required. Missing Bearer token or session cookie.',
      code: 'UNAUTHORIZED'
    });
  }

  try {
    const decoded = verifyAccessToken(token);
    req.user = {
      id: decoded.userId,
      email: decoded.email,
      fullName: decoded.fullName,
      role: decoded.role,
      institutionId: decoded.institutionId,
      phone: null,
      isEmailVerified: true
    };
    next();
  } catch (err: any) {
    return res.status(401).json({
      success: false,
      error: 'Invalid or expired access token. Please refresh or log in again.',
      code: 'TOKEN_EXPIRED'
    });
  }
}

// Middleware: Granular Role-Based Access Control (RBAC)
export function requireRole(allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required',
        code: 'UNAUTHORIZED'
      });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        error: `Access forbidden: requires one of [${allowedRoles.join(', ')}]. Current role: ${req.user.role}`,
        code: 'FORBIDDEN'
      });
    }

    next();
  };
}

// Middleware: Optional Authentication
export function optionalAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  let token: string | undefined;
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  } else if (req.cookies && req.cookies.accessToken) {
    token = req.cookies.accessToken;
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (token) {
    try {
      const decoded = verifyAccessToken(token);
      req.user = {
        id: decoded.userId,
        email: decoded.email,
        fullName: decoded.fullName,
        role: decoded.role,
        institutionId: decoded.institutionId,
        phone: null,
        isEmailVerified: true
      };
    } catch {
      // Ignored for optional auth
    }
  }
  next();
}

// Route Handler: User Signup with Temp Mail Blocking & Verification Code Dispatch
export async function handleSignup(req: Request, res: Response) {
  try {
    const validated = signupValidationSchema.parse(req.body);
    const cleanEmail = validated.email.toLowerCase().trim();

    // 1. Strict Disposable / Temp Mail Blocking
    const tempMailCheck = isDisposableEmail(cleanEmail);
    if (tempMailCheck.isDisposable) {
      return res.status(400).json({
        success: false,
        error: 'Temporary, disposable, or throwaway email domains are strictly blocked. Please register with an authentic personal, business, or institutional email address.',
        reason: tempMailCheck.reason,
        code: 'TEMP_MAIL_BLOCKED'
      });
    }

    const supabase = getSupabaseAdminClient();
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    const verificationExpiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();

    // If Supabase is connected
    if (supabase) {
      const { data: existingUser } = await supabase
        .from('users')
        .select('id, email, is_email_verified')
        .eq('email', cleanEmail)
        .maybeSingle();

      if (existingUser) {
        return res.status(409).json({ success: false, error: 'A user with this email address is already registered.' });
      }

      const passwordHash = await bcrypt.hash(validated.password, SALT_ROUNDS);
      const { data: createdUser, error: insertError } = await supabase
        .from('users')
        .insert({
          email: cleanEmail,
          password_hash: passwordHash,
          full_name: validated.fullName,
          role: validated.role,
          phone: validated.phone,
          institution_id: validated.institutionId,
          is_email_verified: false,
          verification_code: verificationCode,
          verification_expires_at: verificationExpiresAt
        })
        .select('id, email, full_name, role, institution_id, phone')
        .single();

      if (insertError || !createdUser) {
        throw new Error(insertError?.message || 'Database insert failed');
      }

      // Dispatch real transactional verification email via Postal
      PostalService.sendVerificationOTP(cleanEmail, verificationCode, validated.fullName).catch(() => {});
      OpenSearchService.indexAuditEvent({
        id: `audit-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorEmail: cleanEmail,
        action: 'USER_REGISTERED_PENDING_VERIFICATION',
        category: 'AUTH',
        severity: 'INFO',
        details: `User registered ${cleanEmail} (${validated.role}) awaiting OTP verification`
      }).catch(() => {});

      return res.status(201).json({
        success: true,
        requiresVerification: true,
        email: cleanEmail,
        message: 'Account registered successfully! A 6-digit verification code has been dispatched to your email.',
        verificationCodeDemo: verificationCode // Available in dev preview for instant verification
      });
    }

    if (process.env.NODE_ENV === 'production') {
      return res.status(503).json({
        success: false,
        error: 'Authoritative database is unavailable. Production mode fails closed.',
        code: 'DATABASE_UNAVAILABLE'
      });
    }

    // In-memory fallback
    const existing = usersDB.find((u) => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      if (!existing.isEmailVerified) {
        // Update code and allow verification
        existing.verificationCode = verificationCode;
        existing.verificationExpiresAt = verificationExpiresAt;
        PostalService.sendVerificationOTP(cleanEmail, verificationCode, existing.fullName).catch(() => {});
        return res.status(200).json({
          success: true,
          requiresVerification: true,
          email: cleanEmail,
          message: 'Account pending verification. A fresh 6-digit verification code has been generated.',
          verificationCodeDemo: verificationCode
        });
      }
      return res.status(409).json({ success: false, error: 'A user with this email address already exists.' });
    }

    const passwordHash = await bcrypt.hash(validated.password, SALT_ROUNDS);
    const newUser: InMemUser = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      email: cleanEmail,
      fullName: validated.fullName,
      role: validated.role as UserRole,
      phone: validated.phone || null,
      institutionId: validated.institutionId || null,
      passwordHash,
      isEmailVerified: false,
      verificationCode,
      verificationExpiresAt,
      createdAt: new Date().toISOString()
    };

    usersDB.push(newUser);
    PostalService.sendVerificationOTP(cleanEmail, verificationCode, validated.fullName).catch(() => {});
    OpenSearchService.indexAuditEvent({
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actorEmail: cleanEmail,
      action: 'USER_REGISTERED_PENDING_VERIFICATION',
      category: 'AUTH',
      severity: 'INFO',
      details: `User registered in-memory ${cleanEmail} (${validated.role})`
    }).catch(() => {});

    return res.status(201).json({
      success: true,
      requiresVerification: true,
      email: cleanEmail,
      message: 'Account registered successfully! Please enter the 6-digit verification code to complete verification.',
      verificationCodeDemo: verificationCode
    });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', details: err.issues });
    }
    return res.status(500).json({ success: false, error: err.message || 'Internal server error during registration' });
  }
}

// Route Handler: Email Verification with 6-Digit OTP
export async function handleVerifyEmail(req: Request, res: Response) {
  try {
    const validated = verifyEmailValidationSchema.parse(req.body);
    const cleanEmail = validated.email.toLowerCase().trim();
    const code = validated.code.trim();

    const supabase = getSupabaseAdminClient();

    if (supabase) {
      const { data: userRecord, error } = await supabase
        .from('users')
        .select('*')
        .eq('email', cleanEmail)
        .maybeSingle();

      if (error || !userRecord) {
        return res.status(404).json({ success: false, error: 'User record not found.' });
      }

      if (userRecord.is_email_verified) {
        const authUser: AuthUser = {
          id: userRecord.id,
          email: userRecord.email,
          fullName: userRecord.full_name,
          role: userRecord.role,
          institutionId: userRecord.institution_id,
          phone: userRecord.phone,
          isEmailVerified: true
        };
        const tokens = generateTokenPair(authUser);
        return res.json({
          success: true,
          message: 'Email already verified. You are now logged in.',
          user: authUser,
          accessToken: tokens.accessToken,
          refreshToken: tokens.refreshToken
        });
      }

      // Check code matching or universal dev token
      const isDevPass = process.env.NODE_ENV !== 'production' && code === '123456';
      if (userRecord.verification_code !== code && !isDevPass) {
        return res.status(400).json({ success: false, error: 'Invalid verification code. Please check your email or request a new code.' });
      }

      // Mark user as verified in database
      await supabase
        .from('users')
        .update({
          is_email_verified: true,
          verification_code: null,
          verification_expires_at: null,
          email_verified_at: new Date().toISOString()
        })
        .eq('id', userRecord.id);

      const authUser: AuthUser = {
        id: userRecord.id,
        email: userRecord.email,
        fullName: userRecord.full_name,
        role: userRecord.role,
        institutionId: userRecord.institution_id,
        phone: userRecord.phone,
        isEmailVerified: true
      };

      const tokens = generateTokenPair(authUser);
      res.cookie('accessToken', tokens.accessToken, getCookieOptions(15 * 60 * 1000));
      res.cookie('refreshToken', tokens.refreshToken, getCookieOptions(7 * 24 * 60 * 60 * 1000));

      return res.json({
        success: true,
        message: 'Email successfully verified! Welcome to Fortis Invicta Solar.',
        user: authUser,
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken
      });
    }

    // In-memory verification
    const memUser = usersDB.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!memUser) {
      return res.status(404).json({ success: false, error: 'User registration not found.' });
    }

    const isDevPass = code === '123456' || (memUser.verificationCode && memUser.verificationCode === code);
    if (!isDevPass) {
      return res.status(400).json({ success: false, error: 'Invalid verification code. Please check and try again.' });
    }

    memUser.isEmailVerified = true;
    memUser.verificationCode = null;
    memUser.verificationExpiresAt = null;

    const authUser: AuthUser = {
      id: memUser.id,
      email: memUser.email,
      fullName: memUser.fullName,
      role: memUser.role,
      institutionId: memUser.institutionId,
      phone: memUser.phone,
      isEmailVerified: true
    };

    const tokens = generateTokenPair(authUser);
    res.cookie('accessToken', tokens.accessToken, getCookieOptions(15 * 60 * 1000));
    res.cookie('refreshToken', tokens.refreshToken, getCookieOptions(7 * 24 * 60 * 60 * 1000));

    return res.json({
      success: true,
      message: 'Email successfully verified! Welcome to Fortis Invicta Solar.',
      user: authUser,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken
    });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', details: err.issues });
    }
    return res.status(500).json({ success: false, error: err.message || 'Verification failed.' });
  }
}

// Route Handler: Resend Verification Code
export async function handleResendVerification(req: Request, res: Response) {
  try {
    const validated = resendVerificationValidationSchema.parse(req.body);
    const cleanEmail = validated.email.toLowerCase().trim();

    const newCode = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();

    const supabase = getSupabaseAdminClient();
    if (supabase) {
      const { data: userRecord } = await supabase
        .from('users')
        .select('id, is_email_verified')
        .eq('email', cleanEmail)
        .maybeSingle();

      if (!userRecord) {
        return res.status(404).json({ success: false, error: 'Account not found.' });
      }

      if (userRecord.is_email_verified) {
        return res.json({ success: true, message: 'This email is already verified. You can proceed to log in.' });
      }

      await supabase
        .from('users')
        .update({
          verification_code: newCode,
          verification_expires_at: expiresAt
        })
        .eq('id', userRecord.id);

      return res.json({
        success: true,
        message: 'A fresh 6-digit verification code has been sent to your email.',
        verificationCodeDemo: newCode
      });
    }

    const memUser = usersDB.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!memUser) {
      return res.status(404).json({ success: false, error: 'Account not found.' });
    }

    memUser.verificationCode = newCode;
    memUser.verificationExpiresAt = expiresAt;

    return res.json({
      success: true,
      message: 'A fresh 6-digit verification code has been dispatched.',
      verificationCodeDemo: newCode
    });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', details: err.issues });
    }
    return res.status(500).json({ success: false, error: err.message });
  }
}

// Route Handler: User Login (Gated by Email Verification)
export async function handleLogin(req: Request, res: Response) {
  try {
    const validated = loginValidationSchema.parse(req.body);
    const cleanEmail = validated.email.toLowerCase().trim();
    const supabase = getSupabaseAdminClient();

    let authUser: AuthUser | null = null;
    let passwordHash: string | null = null;
    let isEmailVerified = false;

    if (supabase) {
      const { data: dbUser, error: dbError } = await supabase
        .from('users')
        .select('*')
        .eq('email', cleanEmail)
        .maybeSingle();

      if (dbUser) {
        authUser = {
          id: dbUser.id,
          email: dbUser.email,
          fullName: dbUser.full_name,
          role: dbUser.role,
          institutionId: dbUser.institution_id,
          phone: dbUser.phone,
          isEmailVerified: !!dbUser.is_email_verified
        };
        passwordHash = dbUser.password_hash;
        isEmailVerified = !!dbUser.is_email_verified;
      } else if (process.env.NODE_ENV === 'production') {
        if (dbError) {
          return res.status(503).json({
            success: false,
            error: 'Authoritative database is unavailable. Production mode fails closed.',
            code: 'DATABASE_UNAVAILABLE'
          });
        }
        return res.status(401).json({ success: false, error: 'Invalid email address or password.' });
      }
    } else if (process.env.NODE_ENV === 'production') {
      return res.status(503).json({
        success: false,
        error: 'Authoritative database is unavailable. Production mode fails closed.',
        code: 'DATABASE_UNAVAILABLE'
      });
    }

    if (!authUser) {
      const memoryUser = usersDB.find((u) => u.email.toLowerCase() === cleanEmail);
      if (memoryUser) {
        authUser = {
          id: memoryUser.id,
          email: memoryUser.email,
          fullName: memoryUser.fullName,
          role: memoryUser.role,
          institutionId: memoryUser.institutionId,
          phone: memoryUser.phone,
          isEmailVerified: memoryUser.isEmailVerified
        };
        passwordHash = memoryUser.passwordHash;
        isEmailVerified = memoryUser.isEmailVerified;
      }
    }

    if (!authUser || !passwordHash) {
      return res.status(401).json({ success: false, error: 'Invalid email address or password.' });
    }

    const passwordMatch = await bcrypt.compare(validated.password, passwordHash);
    if (!passwordMatch) {
      return res.status(401).json({ success: false, error: 'Invalid email address or password.' });
    }

    // BLOCK UNVERIFIED USERS
    if (!isEmailVerified) {
      return res.status(403).json({
        success: false,
        requiresVerification: true,
        email: authUser.email,
        error: 'Email address has not been verified. You must verify your email before accessing the platform.',
        code: 'EMAIL_NOT_VERIFIED'
      });
    }

    const tokens = generateTokenPair(authUser);

    // Set secure HTTP-Only cookies
    res.cookie('accessToken', tokens.accessToken, getCookieOptions(15 * 60 * 1000));
    res.cookie('refreshToken', tokens.refreshToken, getCookieOptions(7 * 24 * 60 * 60 * 1000));
    res.cookie('token', tokens.accessToken, getCookieOptions(7 * 24 * 60 * 60 * 1000));

    return res.json({
      success: true,
      message: 'Logged in successfully',
      user: authUser,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken
    });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', details: err.issues });
    }
    return res.status(500).json({ success: false, error: err.message || 'Internal server error during login' });
  }
}

// Route Handler: Token Refresh
export async function handleRefreshToken(req: Request, res: Response) {
  try {
    const refreshToken = req.body?.refreshToken || req.cookies?.refreshToken;
    if (!refreshToken) {
      return res.status(400).json({ success: false, error: 'Refresh token is required' });
    }

    const decoded = verifyRefreshToken(refreshToken);
    const newAccessToken = generateAccessToken({
      id: decoded.userId,
      email: decoded.email,
      fullName: decoded.fullName,
      role: decoded.role,
      institutionId: decoded.institutionId
    });

    res.cookie('accessToken', newAccessToken, getCookieOptions(15 * 60 * 1000));

    return res.json({
      success: true,
      accessToken: newAccessToken,
      expiresIn: 15 * 60
    });
  } catch (err: any) {
    return res.status(401).json({
      success: false,
      error: 'Invalid or expired refresh token. Please log in again.',
      code: 'INVALID_REFRESH_TOKEN'
    });
  }
}

// Route Handler: Logout and Invalidate Tokens
export function handleLogout(req: Request, res: Response) {
  const token = req.cookies?.accessToken || req.cookies?.token;
  const refreshToken = req.cookies?.refreshToken;

  if (token) revokeToken(token);
  if (refreshToken) revokeToken(refreshToken);

  res.clearCookie('accessToken', { path: '/' });
  res.clearCookie('refreshToken', { path: '/' });
  res.clearCookie('token', { path: '/' });

  return res.json({ success: true, message: 'Logged out and session revoked successfully' });
}

// Route Handler: Current User Profile
export function handleMe(req: AuthenticatedRequest, res: Response) {
  if (!req.user) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }
  return res.json({ success: true, user: req.user });
}
