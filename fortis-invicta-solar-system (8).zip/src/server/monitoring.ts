import * as Sentry from '@sentry/node';
import { Request, Response, NextFunction } from 'express';
import { getEnvConfig } from './envConfig.js';

let isInitialized = false;

export function initBackendMonitoring() {
  const config = getEnvConfig();
  const dsn = config.SENTRY_DSN || process.env.SENTRY_DSN;

  if (dsn && !isInitialized) {
    try {
      Sentry.init({
        dsn,
        environment: config.NODE_ENV,
        release: 'fortis-invicta-solar@2.5.0',
        tracesSampleRate: config.NODE_ENV === 'production' ? 0.2 : 1.0,
      });
      console.log(`[Monitoring] Sentry Node SDK initialized in ${config.NODE_ENV} mode`);
      isInitialized = true;
    } catch (err: any) {
      console.warn('[Monitoring] Sentry SDK initialization warning:', err?.message);
    }
  } else if (!isInitialized) {
    console.log('[Monitoring] Sentry DSN not configured; using structured console telemetry.');
  }

  // Handle global uncaught exceptions
  process.on('uncaughtException', (error: Error) => {
    console.error('[FATAL: Uncaught Exception]:', {
      message: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString()
    });
    if (isInitialized) {
      Sentry.captureException(error);
    }
  });

  // Handle global unhandled promise rejections
  process.on('unhandledRejection', (reason: any) => {
    console.error('[FATAL: Unhandled Rejection]:', {
      reason: reason?.message || reason,
      stack: reason?.stack,
      timestamp: new Date().toISOString()
    });
    if (isInitialized && reason instanceof Error) {
      Sentry.captureException(reason);
    }
  });
}

export function sentryTracingMiddleware(req: Request, res: Response, next: NextFunction) {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (res.statusCode >= 400) {
      console.warn(`[HTTP Warning] ${req.method} ${req.originalUrl} - ${res.statusCode} (${duration}ms)`);
    }
  });
  next();
}

export function captureException(error: Error, context?: Record<string, any>) {
  console.error('[Captured Exception]:', {
    message: error.message,
    context,
    timestamp: new Date().toISOString()
  });
  if (isInitialized) {
    Sentry.captureException(error, { extra: context });
  }
}
