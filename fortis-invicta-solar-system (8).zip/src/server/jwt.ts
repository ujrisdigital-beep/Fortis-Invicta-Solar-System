import jwt from 'jsonwebtoken';
import { getEnvConfig } from './envConfig.js';
import { JwtPayload, UserRole } from './types.js';

const ACCESS_TOKEN_EXPIRY = '15m'; // 15 minutes for access tokens
const REFRESH_TOKEN_EXPIRY = '7d';  // 7 days for refresh tokens

// In-memory revoked tokens store (In production, replace with Redis or database table)
const revokedTokens = new Set<string>();

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  expiresIn: number; // in seconds
}

export function generateAccessToken(user: { id: string; email: string; fullName: string; role: UserRole; institutionId?: string | null }): string {
  const config = getEnvConfig();
  const payload: JwtPayload = {
    userId: user.id,
    email: user.email,
    role: user.role,
    fullName: user.fullName,
    institutionId: user.institutionId || null,
    tokenType: 'access'
  };

  return jwt.sign(payload, config.JWT_SECRET, {
    expiresIn: ACCESS_TOKEN_EXPIRY,
    issuer: 'fortis-invicta-auth',
    audience: 'fortis-invicta-app'
  });
}

export function generateRefreshToken(user: { id: string; email: string; fullName: string; role: UserRole; institutionId?: string | null }): string {
  const config = getEnvConfig();
  const payload: JwtPayload = {
    userId: user.id,
    email: user.email,
    role: user.role,
    fullName: user.fullName,
    institutionId: user.institutionId || null,
    tokenType: 'refresh'
  };

  return jwt.sign(payload, config.JWT_REFRESH_SECRET, {
    expiresIn: REFRESH_TOKEN_EXPIRY,
    issuer: 'fortis-invicta-auth',
    audience: 'fortis-invicta-app'
  });
}

export function generateTokenPair(user: { id: string; email: string; fullName: string; role: UserRole; institutionId?: string | null }): TokenPair {
  return {
    accessToken: generateAccessToken(user),
    refreshToken: generateRefreshToken(user),
    expiresIn: 15 * 60 // 15 minutes in seconds
  };
}

export function verifyAccessToken(token: string): JwtPayload {
  const config = getEnvConfig();
  if (revokedTokens.has(token)) {
    throw new Error('Token has been revoked');
  }

  const decoded = jwt.verify(token, config.JWT_SECRET, {
    issuer: 'fortis-invicta-auth',
    audience: 'fortis-invicta-app'
  }) as JwtPayload;

  if (decoded.tokenType !== 'access') {
    throw new Error('Invalid token type provided as access token');
  }

  return decoded;
}

export function verifyRefreshToken(token: string): JwtPayload {
  const config = getEnvConfig();
  if (revokedTokens.has(token)) {
    throw new Error('Refresh token has been revoked');
  }

  const decoded = jwt.verify(token, config.JWT_REFRESH_SECRET, {
    issuer: 'fortis-invicta-auth',
    audience: 'fortis-invicta-app'
  }) as JwtPayload;

  if (decoded.tokenType !== 'refresh') {
    throw new Error('Invalid token type provided as refresh token');
  }

  return decoded;
}

export function revokeToken(token: string): void {
  revokedTokens.add(token);
}

export function isTokenRevoked(token: string): boolean {
  return revokedTokens.has(token);
}
