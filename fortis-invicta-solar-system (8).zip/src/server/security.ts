import { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';
import cors from 'cors';
import { ZodSchema, ZodError } from 'zod';
import { getEnvConfig } from './envConfig.js';

// ==========================================
// 1. CORS Configuration
// ==========================================
export const corsOptions: cors.CorsOptions = {
  origin: (origin, callback) => {
    // In production, tighten allowed domains; in staging/dev, allow preview instances
    if (!origin) return callback(null, true);

    const allowedPatterns = [
      /^http:\/\/localhost:\d+$/,
      /^https:\/\/.*\.run\.app$/,
      /^https:\/\/.*\.googleusercontent\.com$/,
      /^https:\/\/.*\.ai\.studio$/
    ];

    const isAllowed = allowedPatterns.some((pattern) => pattern.test(origin));
    if (isAllowed) {
      callback(null, true);
    } else {
      callback(null, true); // Permissive for preview sandbox environments
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'X-Refresh-Token'],
  exposedHeaders: ['Set-Cookie', 'Authorization'],
  maxAge: 86400 // 24 hours preflight cache
};

// ==========================================
// 2. Rate Limiters
// ==========================================
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Max 5 attempts per 15 minutes
  standardHeaders: true,
  legacyHeaders: false,
  validate: false,
  message: {
    success: false,
    error: 'Too many authentication attempts. Rate limit: 5 attempts per 15 minutes.',
    code: 'AUTH_RATE_LIMIT_EXCEEDED'
  }
});

export const manualPaymentRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // Max 10 requests per hour
  standardHeaders: true,
  legacyHeaders: false,
  validate: false,
  message: {
    success: false,
    error: 'Manual payment submission rate limit exceeded. Max 10 requests per hour.',
    code: 'PAYMENT_RATE_LIMIT_EXCEEDED'
  }
});

export const institutionalRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // Max 10 attempts per hour
  standardHeaders: true,
  legacyHeaders: false,
  validate: false,
  message: {
    success: false,
    error: 'Institutional verification rate limit exceeded. Max 10 requests per hour.',
    code: 'INSTITUTIONAL_RATE_LIMIT_EXCEEDED'
  }
});

export const apiRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 120, // 120 requests/min
  standardHeaders: true,
  legacyHeaders: false,
  validate: false,
  message: {
    success: false,
    error: 'API rate limit exceeded. Please throttle requests.',
    code: 'RATE_LIMIT_EXCEEDED'
  }
});

export const webhookRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  validate: false,
  message: {
    success: false,
    error: 'Webhook rate limit exceeded',
    code: 'WEBHOOK_RATE_LIMIT'
  }
});

// ==========================================
// 3. Security Headers Middleware (Helmet Equivalent)
// ==========================================
export function securityHeaders(req: Request, res: Response, next: NextFunction) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(self)');
  
  if (process.env.NODE_ENV === 'production') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  }

  next();
}

// ==========================================
// 4. Zod Request Body Validation Middleware
// ==========================================
export function validateBody<T>(schema: ZodSchema<T>) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      req.body = schema.parse(req.body);
      next();
    } catch (err: any) {
      if (err instanceof ZodError) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          code: 'VALIDATION_ERROR',
          details: err.issues.map(i => ({ path: i.path.join('.'), message: i.message }))
        });
      }
      return res.status(400).json({
        success: false,
        error: 'Malformed request payload',
        code: 'BAD_REQUEST'
      });
    }
  };
}

// ==========================================
// 5. Centralized Error Handling Middleware
// ==========================================
export function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  const isProduction = process.env.NODE_ENV === 'production';
  const statusCode = err.statusCode || 500;

  // Log error safely without leaking database passwords or secrets
  console.error('[Application Error]:', {
    timestamp: new Date().toISOString(),
    path: req.path,
    method: req.method,
    statusCode,
    message: err.message,
    code: err.code || 'INTERNAL_ERROR',
    stack: !isProduction ? err.stack : undefined
  });

  res.status(statusCode).json({
    success: false,
    error: isProduction && statusCode === 500 ? 'An internal server error occurred' : err.message,
    code: err.code || 'INTERNAL_SERVER_ERROR',
    ...(!isProduction && err.stack ? { stack: err.stack } : {})
  });
}
