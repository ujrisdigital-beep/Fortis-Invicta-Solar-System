import { z } from 'zod';

export type UserRole =
  | 'super_admin'
  | 'admin'
  | 'project_manager'
  | 'site_inspector'
  | 'installer'
  | 'engineer'
  | 'finance_officer'
  | 'institutional_admin'
  | 'client';

export interface AuthUser {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
  institutionId?: string | null;
  phone?: string | null;
  isEmailVerified?: boolean;
}

export interface JwtPayload {
  userId: string;
  email: string;
  role: UserRole;
  fullName: string;
  institutionId?: string | null;
  tokenType: 'access' | 'refresh';
}

export interface AuthenticatedUserPayload extends AuthUser {
  tokenType?: 'access' | 'refresh';
}
