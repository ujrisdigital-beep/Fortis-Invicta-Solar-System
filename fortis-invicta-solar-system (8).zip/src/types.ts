/**
 * Fortis Invicta Solar Project Management System - Type Definitions
 */

export type ClientSegment = 'gtuccu_member' | 'nagnmc_member' | 'diaspora' | 'non_union_individual';

export type ProjectStage =
  | 'lead'
  | 'assessment_scheduled'
  | 'assessment_complete'
  | 'payment_pending'
  | 'installation_scheduled'
  | 'installation_in_progress'
  | 'commissioning'
  | 'completed';

export type UserRole =
  | 'super_admin'
  | 'project_manager'
  | 'site_inspector'
  | 'installer'
  | 'finance_officer'
  | 'institutional_admin'
  | 'client';

export type PackageId = 'basic_backup' | 'hybrid_standard' | 'premium_executive' | 'commercial';

export type PaymentStatus =
  | 'pending'
  | 'confirmation_required'
  | 'confirmed'
  | 'partially_paid'
  | 'overdue'
  | 'failed';

export type PaymentMethod = 'bank_transfer' | 'teller_deposit' | 'salary_deduction' | 'ecobank_qr' | 'cash';

export type Currency = 'GMD' | 'USD' | 'GBP';

export type Priority = 'low' | 'medium' | 'high' | 'urgent';

export interface Team {
  id: string;
  name: string;
  teamLeader: string;
  region: string;
  active: boolean;
}

export interface SolarAssetSpec {
  inverter: string;
  solarPanels: string;
  batteryBank: string;
  mountingRacking: string;
  protectionSwitchgear: string;
  cablingAccessories: string;
}

export interface ForexInflationConfig {
  usdToGmdRate: number; // e.g. 68.5 GMD per USD
  gbpToGmdRate: number; // e.g. 85.0 GMD per GBP
  globalInflationPercent: number; // e.g. 5.0% price index adjustment
  lastUpdated: string;
  updatedBy: string;
}

export interface SupportedApplianceItem {
  name: string;
  countOrCapacity: string;
  category: 'lighting' | 'cooling' | 'refrigeration' | 'appliances' | 'pumping' | 'medical_heavy';
  iconName?: string;
}

export interface SolarPackage {
  id: PackageId;
  tier?: string;
  tierLabel?: string;
  name: string;
  tagline: string;
  description: string;
  priceMinGMD: number;
  priceMaxGMD: number;
  priceMinUSD: number;
  priceMaxUSD: number;
  priceMinGBP: number;
  priceMaxGBP: number;
  inverterCapacity: string;
  solarPanels: string;
  batteryBank: string;
  recommendedFor: string;
  features: string[];
  solarAssets: SolarAssetSpec;
  supportedAppliances: SupportedApplianceItem[];
  image: string;
}

export interface MultimediaRecord {
  id: string;
  clientId?: string;
  title: string;
  category: 'photo' | 'video' | 'report' | 'assessment' | 'maintenance' | 'audio' | 'document';
  mediaUrl: string; // Base64 data URL or Object URL
  fileType: string;
  fileSizeFormatted: string;
  description?: string;
  locationName?: string;
  gpsCoordinates?: {
    lat: number;
    lng: number;
    formatted?: string;
  };
  capturedAt: string;
  uploadedBy: string;
  uploadedByRole: UserRole;
}

export interface UnionConfig {
  id: string; // e.g. 'GTUCCU', 'NAGNMC', 'GAMPOST', 'GAMTEL', 'NAWEC_STAFF'
  name: string; // e.g. "Gambia Teachers Union Credit Union"
  shortCode: string; // e.g. "GTUCCU"
  sector: string; // e.g. "Education", "Healthcare", "Civil Service"
  qualifyingMonthsOptions: number[];
  defaultQualifyingMonths: number;
  adminFeePercent: number;
  defaultDownPaymentPercent: number;
  maxLoanCapGMD: number;
  requiredDocuments: string[];
  isActive: boolean;
  contactEmail?: string;
  contactPhone?: string;
  description?: string;
  createdAt: string;
}

export interface PropertyDetails {
  region: string; // e.g. 'Banjul City' | 'Kanifing / Serekunda' | 'Brikama / West Coast' | 'Kerewan / North Bank' | 'Mansakonko / Lower River' | 'Janjanbureh / Central River' | 'Basse / Upper River' or custom
  customRegion?: string;
  distanceFromDepotKM: number;
  logisticsSurchargeGMD: number;
  propertyType: string; // 'Residential Single Compound' | 'Multi-Story Villa' | 'Commercial Office' | 'Clinic / Hospital' | 'School / Institution' | 'Agricultural Farm' or custom
  customPropertyType?: string;
  roofType: string; // 'Corrugated Iron (Zinc)' | 'Concrete Roof Slab' | 'Clay Roof Tiles' | 'Standing Seam Metal' | 'Ground Mount' or custom
  customRoofType?: string;
  gridReliability: string; // 'Severe Outages (12+ hrs/day)' | 'Daily Outages (6-12 hrs/day)' | 'Off-Grid (No NAWEC)' | 'Stable Grid' or custom
  customGridReliability?: string;
  phaseType: string; // 'Single Phase 220V' | 'Three Phase 415V' or custom
  customPhaseType?: string;
  propertyOwnership: string; // 'Privately Owned' | 'Leased / Rented' | 'Institutional / State' or custom
  customPropertyOwnership?: string;
  notes?: string;
}

export interface MessageLog {
  id: string;
  clientId: string;
  channel: 'whatsapp' | 'email' | 'sms';
  templateType: 'onboarding' | 'inspection' | 'payment_reminder' | 'stage_update' | 'custom';
  recipient: string;
  messageText: string;
  sentAt: string;
  sentBy: string;
}

export interface Client {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  address: string;
  gpsCoordinates?: {
    lat: number;
    lng: number;
    formatted?: string;
  };
  propertyDetails?: PropertyDetails;
  clientSegment: ClientSegment | string; // GTUCCU, NAGNMC, or custom union ID
  institutionId?: string; // Union shortCode or ID
  institutionMemberId?: string;
  institutionVerified: boolean;
  institutionVerificationDate?: string;
  packageId: PackageId;
  projectStage: ProjectStage;
  priority: Priority;
  financingType: 'salary_deduction' | 'direct_bank_transfer' | 'teller_deposit' | 'ecobank_pay' | 'cash';
  totalQuotedGMD: number;
  customPackagePriceGMD?: number;
  appliedInflationRate?: number;
  appliedForexRateUSD?: number;
  priceLockedAt?: string;
  totalPaidGMD: number;
  outstandingBalanceGMD: number;
  paymentStatus: PaymentStatus;
  assignedTeamId?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  documents?: DocumentRecord[];
  multimedia?: MultimediaRecord[];
  messageHistory?: MessageLog[];
}

export interface PaymentRecord {
  id: string;
  clientId: string;
  clientName: string;
  amountGMD: number;
  currency: Currency;
  originalAmount?: number;
  paymentDate: string;
  paymentMethod: PaymentMethod;
  referenceNumber: string; // Ecobank transaction or teller ref
  ecobankMerchantCode: string; // "505825057"
  ecobankTerminalId: string;   // "32680928"
  bankBranch?: string;
  status: PaymentStatus;
  notes?: string;
  proofDocumentUrl?: string;
  confirmedBy?: string;
  confirmedAt?: string;
  receiptNumber?: string;
  createdAt: string;
}

export interface AssessmentReport {
  id: string;
  clientId: string;
  clientName: string;
  inspectorName: string;
  scheduledDate: string;
  completedDate?: string;
  roofType: 'corrugated_iron' | 'concrete' | 'tiled' | 'flat';
  roofCondition: 'good' | 'fair' | 'poor' | 'needs_repair';
  sunExposureHours: number; // e.g. 7.5 hrs/day
  shadingLevel: 'none' | 'minimal' | 'moderate' | 'heavy';
  electricalCompatibility: 'compatible' | 'needs_main_switch_upgrade' | 'wiring_overhaul_required';
  recommendedPanelCapacityKW: number;
  recommendedInverterKVA: number;
  recommendedBatteryKWH: number;
  outcome: 'approved' | 'approved_with_modifications' | 'rejected';
  modificationsRequired?: string;
  notes?: string;
  photosCount: number;
  gpsTagged: boolean;
  gpsCoordinates?: {
    latitude: number;
    longitude: number;
    accuracyMeters?: number;
    altitudeMeters?: number;
  };
  reportUrl?: string;
}

export interface InstallationLog {
  id: string;
  clientId: string;
  clientName: string;
  teamLeader: string;
  teamMembers: string[];
  startDate: string;
  targetCompletionDate: string;
  actualCompletionDate?: string;
  progressPercentage: number;
  currentTask: string;
  checklists: {
    roofMountingInstalled: boolean;
    panelsWiredAndGrounded: boolean;
    inverterAndBatteriesMounted: boolean;
    changeoverSwitchConnected: boolean;
    loadTestingPassed: boolean;
    safetyInspectionSigned: boolean;
  };
  serialNumbers?: {
    inverter?: string;
    batteries?: string[];
    panels?: string[];
  };
  issuesLogged?: string[];
  status: 'scheduled' | 'in_progress' | 'completed' | 'on_hold' | 'issues';
}

export interface InstitutionalMember {
  id: string;
  institutionId: 'GTUCCU' | 'NAGNMC';
  institutionName: string;
  memberId: string;
  fullName: string;
  email: string;
  phone: string;
  workplace: string; // e.g. "Brikama Senior Secondary" or "EFSTH Hospital"
  monthlySalaryGMD: number;
  eligibleCreditGMD: number;
  status: 'verified' | 'pending' | 'flagged' | 'inactive';
  linkedClientId?: string;
}

export interface SupportTicket {
  id: string;
  clientId: string;
  clientName: string;
  subject: string;
  category: 'payment' | 'installation' | 'maintenance' | 'general';
  description: string;
  status: 'open' | 'in_progress' | 'resolved';
  priority: Priority;
  createdAt: string;
  assignedTo?: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  details: string;
  clientId?: string;
}

export interface DocumentRecord {
  id: string;
  name: string;
  type: 'national_id' | 'salary_slip' | 'proof_of_address' | 'assessment_report' | 'payment_slip' | 'receipt' | 'commissioning_cert';
  uploadDate: string;
  size: string;
  url: string;
}
