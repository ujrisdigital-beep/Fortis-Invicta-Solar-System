import * as Sentry from '@sentry/react';
import { initFrontendSentry, reportClientError } from './services/sentry';

// Auto-initialize Sentry on import
initFrontendSentry();

export { Sentry, initFrontendSentry, reportClientError };
export default Sentry;
