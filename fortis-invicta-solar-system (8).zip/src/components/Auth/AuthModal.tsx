import React, { useState } from 'react';
import { useAuth } from '../../services/authContext';
import { UserRole } from '../../types';
import { isDisposableEmail } from '../../utils/tempMailValidator';
import {
  Shield,
  Lock,
  Mail,
  User,
  Phone,
  Building2,
  Key,
  CheckCircle,
  AlertCircle,
  X,
  Send,
  RefreshCw,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'signup' | 'verify';
  initialEmail?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
  initialEmail = ''
}) => {
  const { login, signup, verifyEmail, resendVerification } = useAuth();
  const [authView, setAuthView] = useState<'login' | 'signup' | 'verify'>(initialMode);
  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('client');
  const [institutionId, setInstitutionId] = useState('GTUCCU');

  // OTP State
  const [verificationCode, setVerificationCode] = useState('');
  const [demoCodeHint, setDemoCodeHint] = useState<string | null>(null);

  // Status & Validation State
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [tempMailWarning, setTempMailWarning] = useState<string | null>(null);

  if (!isOpen) return null;

  // Real-time Disposable Mail Validation
  const handleEmailChange = (val: string) => {
    setEmail(val);
    setError(null);
    if (authView === 'signup' && val.includes('@')) {
      const check = isDisposableEmail(val);
      if (check.isDisposable) {
        setTempMailWarning(check.reason || 'Temporary/disposable email addresses are strictly blocked.');
      } else {
        setTempMailWarning(null);
      }
    } else {
      setTempMailWarning(null);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    const res = await login(email, password);
    setLoading(false);

    if (res.success) {
      setSuccess('Authenticated successfully! Welcome to Fortis Invicta Solar.');
      setTimeout(() => onClose(), 700);
    } else if (res.requiresVerification) {
      setError(res.error || 'Email requires verification. A code has been dispatched.');
      setAuthView('verify');
    } else {
      setError(res.error || 'Login failed. Please check your email and password.');
    }
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    // Client-side Temp Mail Pre-check
    const check = isDisposableEmail(email);
    if (check.isDisposable) {
      setLoading(false);
      setError('Temporary or disposable email address detected. Please use a verified institutional, company, or authentic personal email.');
      return;
    }

    const res = await signup({
      email,
      password,
      fullName,
      phone,
      role,
      institutionId: role === 'institutional_admin' || role === 'client' ? institutionId : undefined
    });

    setLoading(false);

    if (res.success) {
      if (res.requiresVerification) {
        setAuthView('verify');
        if (res.verificationCodeDemo) {
          setDemoCodeHint(res.verificationCodeDemo);
        }
        setSuccess('Account created! Enter the 6-digit verification code sent to your email.');
      } else {
        setSuccess('Account verified and logged in!');
        setTimeout(() => onClose(), 800);
      }
    } else {
      setError(res.error || 'Registration failed. Please check all fields.');
    }
  };

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    const res = await verifyEmail(email, verificationCode);
    setLoading(false);

    if (res.success) {
      setSuccess('Email successfully verified! Granting access to your authorized portal...');
      setTimeout(() => onClose(), 800);
    } else {
      setError(res.error || 'Invalid verification code. Please check and try again.');
    }
  };

  const handleResendCode = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    const res = await resendVerification(email);
    setLoading(false);

    if (res.success) {
      setSuccess('A fresh 6-digit verification code has been dispatched.');
      if (res.verificationCodeDemo) {
        setDemoCodeHint(res.verificationCodeDemo);
      }
    } else {
      setError(res.error || 'Failed to resend verification code.');
    }
  };

  const handleQuickDemoFill = (type: 'admin' | 'pm' | 'engineer' | 'installer' | 'finance' | 'gtuccu' | 'nagnmc' | 'client') => {
    setAuthView('login');
    setError(null);
    setTempMailWarning(null);
    if (type === 'admin') {
      setEmail('admin@fortisinvicta.gm');
      setPassword('Fortis2026!Admin');
    } else if (type === 'pm') {
      setEmail('pm@fortisinvicta.gm');
      setPassword('ProjectManager2026!');
    } else if (type === 'engineer') {
      setEmail('engineer@fortisinvicta.gm');
      setPassword('SolarEngineer2026!');
    } else if (type === 'installer') {
      setEmail('installer@fortisinvicta.gm');
      setPassword('SolarInstaller2026!');
    } else if (type === 'finance') {
      setEmail('finance@fortisinvicta.gm');
      setPassword('FinanceEcobank2026!');
    } else if (type === 'gtuccu') {
      setEmail('gtuccu.admin@gtu.gm');
      setPassword('GTUCCU2026!Admin');
    } else if (type === 'nagnmc') {
      setEmail('nagnmc.admin@nurses.gm');
      setPassword('NAGNMC2026!Admin');
    } else {
      setEmail('client@example.com');
      setPassword('SolarClient2026!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl w-full max-w-lg shadow-2xl p-6 sm:p-8 text-white relative overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-amber-500/20">
            {authView === 'verify' ? <ShieldCheck className="w-6 h-6" /> : <Shield className="w-6 h-6" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-serif text-lg font-bold text-white tracking-wide">
                {authView === 'login' && 'Verified Sign In'}
                {authView === 'signup' && 'Register Verified Account'}
                {authView === 'verify' && 'Verify Email Address'}
              </h3>
              <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border border-emerald-500/40">
                PII Protected
              </span>
            </div>
            <p className="text-xs text-slate-400">Fortis Invicta Solar Operational Security Gateway</p>
          </div>
        </div>

        {/* Disposable Mail Warning Policy Banner */}
        {authView === 'signup' && (
          <div className="mb-4 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
            <span>
              <strong>Zero Temp Mail Policy:</strong> Disposable & temporary email domains are actively blocked. Access is granted only upon 6-digit OTP verification.
            </span>
          </div>
        )}

        {/* Quick Demo Credentials Tabs */}
        {authView === 'login' && (
          <div className="mb-4 bg-slate-800/80 p-2.5 rounded-2xl border border-slate-700/80">
            <p className="text-[10px] font-bold uppercase text-slate-400 mb-1.5 px-1 tracking-wider">
              Quick Sign-In Official Roles:
            </p>
            <div className="grid grid-cols-4 gap-1.5 text-[10px] font-bold">
              <button
                type="button"
                onClick={() => handleQuickDemoFill('admin')}
                className="py-1 px-1 rounded-lg bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30 text-center truncate cursor-pointer"
              >
                Super Admin
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoFill('pm')}
                className="py-1 px-1 rounded-lg bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30 text-center truncate cursor-pointer"
              >
                Project Mgr
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoFill('engineer')}
                className="py-1 px-1 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/30 text-center truncate cursor-pointer"
              >
                Inspector
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoFill('installer')}
                className="py-1 px-1 rounded-lg bg-purple-500/20 text-purple-300 hover:bg-purple-500/30 border border-purple-500/30 text-center truncate cursor-pointer"
              >
                Installer
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoFill('finance')}
                className="py-1 px-1 rounded-lg bg-blue-500/20 text-blue-300 hover:bg-blue-500/30 border border-blue-500/30 text-center truncate cursor-pointer"
              >
                Finance
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoFill('gtuccu')}
                className="py-1 px-1 rounded-lg bg-teal-500/20 text-teal-300 hover:bg-teal-500/30 border border-teal-500/30 text-center truncate cursor-pointer"
              >
                GTUCCU
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoFill('nagnmc')}
                className="py-1 px-1 rounded-lg bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/30 border border-indigo-500/30 text-center truncate cursor-pointer"
              >
                NAGNMC
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoFill('client')}
                className="py-1 px-1 rounded-lg bg-emerald-400/20 text-emerald-300 hover:bg-emerald-400/30 border border-emerald-400/30 text-center truncate cursor-pointer"
              >
                Client
              </button>
            </div>
          </div>
        )}

        {/* Feedback Messages */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}
        {tempMailWarning && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/25 border border-rose-500/60 text-rose-200 text-xs flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{tempMailWarning}</span>
          </div>
        )}
        {success && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{success}</span>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 1: SIGN IN */}
        {/* ========================================================================= */}
        {authView === 'login' && (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs text-slate-300 font-semibold mb-1">Registered Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => handleEmailChange(e.target.value)}
                  placeholder="e.g. amadou.jallow@fortisinvicta.gm"
                  className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-semibold mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold py-2.5 rounded-xl text-xs transition duration-200 flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 disabled:opacity-50 cursor-pointer"
            >
              <Key className="w-4 h-4" />
              <span>{loading ? 'Verifying Credentials...' : 'Sign In to Portal'}</span>
            </button>
          </form>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: REGISTER (TEMP MAIL BLOCKED) */}
        {/* ========================================================================= */}
        {authView === 'signup' && (
          <form onSubmit={handleSignupSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs text-slate-300 font-semibold mb-1">Full Legal Name</label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Lamin Ceesay"
                  className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">Assigned Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full bg-slate-800/90 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="client">Client / System Owner</option>
                  <option value="site_inspector">Site Inspector / Field Engineer</option>
                  <option value="finance_officer">Finance / Ecobank Controller</option>
                  <option value="institutional_admin">Union / Institutional Admin</option>
                  <option value="super_admin">Fortis Executive / Super Admin</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">Phone Number</label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+220 7XX XXXX"
                    className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>
            </div>

            {role === 'institutional_admin' && (
              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">Affiliated Union Registry</label>
                <div className="relative">
                  <Building2 className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <select
                    value={institutionId}
                    onChange={(e) => setInstitutionId(e.target.value)}
                    className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="GTUCCU">GTUCCU (Teachers Union Credit Union)</option>
                    <option value="NAGNMC">NAGNMC (Nurses & Midwives Council)</option>
                    <option value="GAMPOST">GAMPOST (Postal Services)</option>
                    <option value="GAMTEL">GAMTEL / GAMCEL</option>
                    <option value="NAWEC">NAWEC Staff Credit Union</option>
                  </select>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs text-slate-300 font-semibold mb-1">
                Authentic Email Address <span className="text-amber-400 font-normal">(Temp mail blocked)</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => handleEmailChange(e.target.value)}
                  placeholder="name@company.com or name@gtu.gm"
                  className={`w-full bg-slate-800/90 border rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none ${
                    tempMailWarning ? 'border-rose-500 focus:border-rose-400' : 'border-slate-700 focus:border-amber-400'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-semibold mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 8 characters with 1 uppercase, 1 number, 1 symbol"
                  className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading || !!tempMailWarning}
              className="w-full mt-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold py-2.5 rounded-xl text-xs transition duration-200 flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{loading ? 'Creating Account...' : 'Register & Dispatch Verification Code'}</span>
            </button>
          </form>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: 6-DIGIT EMAIL VERIFICATION OTP */}
        {/* ========================================================================= */}
        {authView === 'verify' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-center">
              <p className="text-xs text-emerald-300 font-semibold mb-1">Verification Code Dispatched</p>
              <p className="text-xs text-slate-300 font-mono">{email}</p>
              <p className="text-[11px] text-slate-400 mt-2">
                Enter the 6-digit OTP sent to your email to verify your address and activate portal access.
              </p>
            </div>

            {/* Simulated OTP Helper in Development / Preview */}
            {demoCodeHint && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between text-xs">
                <div>
                  <span className="text-[10px] uppercase font-bold text-amber-400 block">Simulated Email Inbox OTP</span>
                  <span className="font-mono text-base font-extrabold text-amber-300 tracking-widest">{demoCodeHint}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setVerificationCode(demoCodeHint)}
                  className="px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 font-bold text-[11px] hover:bg-amber-300 transition cursor-pointer"
                >
                  Auto-Fill Code
                </button>
              </div>
            )}

            <form onSubmit={handleVerifySubmit} className="space-y-4">
              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1 text-center">
                  6-Digit Verification Code
                </label>
                <div className="relative">
                  <Key className="w-4 h-4 absolute left-3 top-3.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="123456"
                    className="w-full bg-slate-800/90 border border-slate-700 rounded-xl py-2.5 text-center font-mono text-lg tracking-[0.4em] text-amber-300 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || verificationCode.length < 6}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold py-2.5 rounded-xl text-xs transition duration-200 flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 disabled:opacity-50 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{loading ? 'Verifying Code...' : 'Verify Email & Access Portal'}</span>
              </button>
            </form>

            <div className="flex items-center justify-between text-xs pt-2 text-slate-400">
              <button
                type="button"
                onClick={handleResendCode}
                disabled={loading}
                className="flex items-center gap-1 text-emerald-400 hover:underline font-semibold cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Resend Code</span>
              </button>
              <button
                type="button"
                onClick={() => setAuthView('signup')}
                className="text-slate-400 hover:text-white transition cursor-pointer"
              >
                Change Email
              </button>
            </div>
          </div>
        )}

        {/* View Toggle */}
        <div className="mt-5 text-center text-xs text-slate-400 border-t border-slate-800 pt-4">
          {authView === 'login' && (
            <p>
              Need to register an authentic email?{' '}
              <button
                type="button"
                onClick={() => {
                  setAuthView('signup');
                  setError(null);
                  setTempMailWarning(null);
                }}
                className="text-amber-300 font-bold hover:underline cursor-pointer"
              >
                Create Verified Account
              </button>
            </p>
          )}

          {authView === 'signup' && (
            <p>
              Already registered and verified?{' '}
              <button
                type="button"
                onClick={() => {
                  setAuthView('login');
                  setError(null);
                  setTempMailWarning(null);
                }}
                className="text-amber-300 font-bold hover:underline cursor-pointer"
              >
                Sign In
              </button>
            </p>
          )}

          {authView === 'verify' && (
            <p>
              Already verified?{' '}
              <button
                type="button"
                onClick={() => {
                  setAuthView('login');
                  setError(null);
                }}
                className="text-amber-300 font-bold hover:underline cursor-pointer"
              >
                Return to Sign In
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
