import React, { useState } from 'react';
import { useAuth } from '../../services/authContext';
import { UserRole } from '../../types';
import { isDisposableEmail } from '../../utils/tempMailValidator';
import { FortisLogo } from '../FortisLogo';
import {
  Shield,
  Lock,
  Mail,
  User,
  Phone,
  Building2,
  Key,
  CheckCircle,
  AlertCircle,
  Send,
  RefreshCw,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  ArrowRight,
  UserCheck,
  Check,
  Zap,
  Info,
  Copy
} from 'lucide-react';

interface OfficialCredential {
  roleName: string;
  role: UserRole;
  fullName: string;
  email: string;
  password: string;
  institutionId?: string;
  description: string;
  badgeColor: string;
}

export const OFFICIAL_CREDENTIALS: OfficialCredential[] = [
  {
    roleName: 'Super Admin (Command HQ)',
    role: 'super_admin',
    fullName: 'Amadou Jallow (Super Admin)',
    email: 'admin@fortisinvicta.gm',
    password: 'Fortis2026!Admin',
    description: 'Full administrative command, financial approvals, RLS policy oversight, union & system configuration.',
    badgeColor: 'bg-amber-400 text-slate-950 border-amber-300'
  },
  {
    roleName: 'Project Manager',
    role: 'project_manager',
    fullName: 'Modou Touray (Project Manager)',
    email: 'pm@fortisinvicta.gm',
    password: 'ProjectManager2026!',
    description: 'Project lifecycle oversight, 8-stage Kanban board, crew dispatching, timeline management.',
    badgeColor: 'bg-cyan-400 text-slate-950 border-cyan-300'
  },
  {
    roleName: 'Site Inspector / Engineer',
    role: 'site_inspector',
    fullName: 'Samba Baldeh (Site Inspector / Engineer)',
    email: 'engineer@fortisinvicta.gm',
    password: 'SolarEngineer2026!',
    description: 'Technical surveys, roof structural feasibility, electrical load analysis, solar sizing assessments.',
    badgeColor: 'bg-emerald-400 text-slate-950 border-emerald-300'
  },
  {
    roleName: 'Certified Field Installer',
    role: 'installer',
    fullName: 'Ebrima Sanyang (Certified Installer)',
    email: 'installer@fortisinvicta.gm',
    password: 'SolarInstaller2026!',
    description: 'Field installation execution, PV array mounting, inverter & battery commissioning checklists.',
    badgeColor: 'bg-purple-400 text-slate-950 border-purple-300'
  },
  {
    roleName: 'Finance Officer (Ecobank)',
    role: 'finance_officer',
    fullName: 'Fatoumatta Ceesay (Finance Controller)',
    email: 'finance@fortisinvicta.gm',
    password: 'FinanceEcobank2026!',
    description: 'Ecobank payment reconciliation, teller verification, credit committee sign-off, multi-currency ledger.',
    badgeColor: 'bg-blue-400 text-slate-950 border-blue-300'
  },
  {
    roleName: 'GTUCCU Union Admin',
    role: 'institutional_admin',
    fullName: 'Lamin Sowe (GTUCCU Union Admin)',
    email: 'gtuccu.admin@gtu.gm',
    password: 'GTUCCU2026!Admin',
    institutionId: 'GTUCCU',
    description: 'Gambia Teachers Union registry verification, monthly salary deduction approvals, credit limit checks.',
    badgeColor: 'bg-teal-400 text-slate-950 border-teal-300'
  },
  {
    roleName: 'NAGNMC Union Admin',
    role: 'institutional_admin',
    fullName: 'Isatou Bah (NAGNMC Union Admin)',
    email: 'nagnmc.admin@nurses.gm',
    password: 'NAGNMC2026!Admin',
    institutionId: 'NAGNMC',
    description: 'Nurses & Midwives Council registry verification, healthcare staff financing validation.',
    badgeColor: 'bg-indigo-400 text-slate-950 border-indigo-300'
  },
  {
    roleName: 'Verified Solar Client',
    role: 'client',
    fullName: 'Amara Jobe (Verified Client)',
    email: 'client@example.com',
    password: 'SolarClient2026!',
    description: 'Client Tracker Portal, live solar generation telemetry, quotation review, teller slip submission.',
    badgeColor: 'bg-emerald-300 text-emerald-950 border-emerald-200'
  }
];

export const AuthScreen: React.FC = () => {
  const { login, signup, verifyEmail, resendVerification } = useAuth();
  const [authView, setAuthView] = useState<'login' | 'signup' | 'verify'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('client');
  const [institutionId, setInstitutionId] = useState('GTUCCU');

  // OTP State
  const [verificationCode, setVerificationCode] = useState('');
  const [demoCodeHint, setDemoCodeHint] = useState<string | null>(null);

  // Status & Validation State
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [tempMailWarning, setTempMailWarning] = useState<string | null>(null);
  const [copiedEmail, setCopiedEmail] = useState<string | null>(null);

  // Real-time Disposable Mail Validation
  const handleEmailChange = (val: string) => {
    setEmail(val);
    setError(null);
    if (authView === 'signup' && val.includes('@')) {
      const check = isDisposableEmail(val);
      if (check.isDisposable) {
        setTempMailWarning(check.reason || 'Temporary/disposable email addresses are strictly blocked.');
      } else {
        setTempMailWarning(null);
      }
    } else {
      setTempMailWarning(null);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    const res = await login(email, password);
    setLoading(false);

    if (res.success) {
      setSuccess('Authenticated successfully! Entering Fortis Invicta Solar OS...');
    } else if (res.requiresVerification) {
      setError(res.error || 'Email requires verification. A code has been dispatched.');
      setAuthView('verify');
    } else {
      setError(res.error || 'Login failed. Please verify your email and password.');
    }
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    // Client-side Temp Mail Pre-check
    const check = isDisposableEmail(email);
    if (check.isDisposable) {
      setLoading(false);
      setError('Temporary or disposable email address detected. Please use a verified institutional, company, or authentic personal email.');
      return;
    }

    const res = await signup({
      email,
      password,
      fullName,
      phone,
      role,
      institutionId: role === 'institutional_admin' || role === 'client' ? institutionId : undefined
    });

    setLoading(false);

    if (res.success) {
      if (res.requiresVerification) {
        setAuthView('verify');
        if (res.verificationCodeDemo) {
          setDemoCodeHint(res.verificationCodeDemo);
        }
        setSuccess('Account registered! Enter the 6-digit verification code sent to your email.');
      } else {
        setSuccess('Account created and verified! Entering system...');
      }
    } else {
      setError(res.error || 'Registration failed. Please check all fields.');
    }
  };

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    const res = await verifyEmail(email, verificationCode);
    setLoading(false);

    if (res.success) {
      setSuccess('Email successfully verified! Granting access...');
    } else {
      setError(res.error || 'Invalid verification code. Please check and try again.');
    }
  };

  const handleResendCode = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    const res = await resendVerification(email);
    setLoading(false);

    if (res.success) {
      setSuccess('A fresh 6-digit verification code has been dispatched.');
      if (res.verificationCodeDemo) {
        setDemoCodeHint(res.verificationCodeDemo);
      }
    } else {
      setError(res.error || 'Failed to resend verification code.');
    }
  };

  const handleSelectCredential = (cred: OfficialCredential) => {
    setAuthView('login');
    setEmail(cred.email);
    setPassword(cred.password);
    setError(null);
    setTempMailWarning(null);
    setSuccess(`Loaded credentials for ${cred.roleName}. Click "Sign In" below or auto-sign in.`);
  };

  const handleCopy = (text: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(text);
    setCopiedEmail(text);
    setTimeout(() => setCopiedEmail(null), 2000);
  };

  return (
    <div className="min-h-screen bg-[#07130F] text-slate-100 font-sans flex flex-col justify-between relative overflow-hidden">
      {/* Background Decorative Gradients */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 -right-40 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 left-1/3 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header Bar */}
      <header className="border-b border-emerald-900/60 bg-[#0B1A14]/80 backdrop-blur-md px-4 sm:px-8 py-3.5 z-10">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <FortisLogo size="md" theme="dark" showText={true} />
            <span className="hidden sm:inline-block bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
              Operational Security Gateway
            </span>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <span className="hidden md:flex items-center gap-1.5 text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2.5 py-1 rounded-lg">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>UK GDPR & Gambia DPPA Compliant</span>
            </span>
            <span className="bg-[#1B4D3E] text-amber-300 font-bold px-3 py-1 rounded-lg border border-emerald-700/60">
              Access Restricted
            </span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 z-10 w-full flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Welcome & Sign In / Sign Up Form */}
          <div className="lg:col-span-7 bg-[#0E2019]/90 border border-emerald-800/80 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative overflow-hidden">
            {/* Header Tabs */}
            <div className="flex items-center justify-between border-b border-emerald-900/80 pb-5 mb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-amber-500/20">
                  {authView === 'verify' ? <ShieldCheck className="w-7 h-7" /> : <Shield className="w-7 h-7" />}
                </div>
                <div>
                  <h2 className="text-xl sm:text-2xl font-serif font-bold text-white tracking-wide">
                    {authView === 'login' && 'Sign In to Solar Platform'}
                    {authView === 'signup' && 'Register New Account'}
                    {authView === 'verify' && 'Verify Email Address (OTP)'}
                  </h2>
                  <p className="text-xs text-emerald-300/80 mt-0.5">
                    {authView === 'login' && 'Enter your registered email and password to access your role workspace.'}
                    {authView === 'signup' && 'Sign up with an authentic email. Disposable domains are blocked.'}
                    {authView === 'verify' && 'Enter the 6-digit OTP verification code sent to your email.'}
                  </p>
                </div>
              </div>

              {/* Mode Toggle Switch */}
              <div className="flex bg-[#07130F] p-1 rounded-xl border border-emerald-900 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setAuthView('login');
                    setError(null);
                    setSuccess(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                    authView === 'login'
                      ? 'bg-amber-400 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthView('signup');
                    setError(null);
                    setSuccess(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                    authView === 'signup'
                      ? 'bg-amber-400 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Sign Up
                </button>
              </div>
            </div>

            {/* Disposable Email Policy Banner for Sign Up */}
            {authView === 'signup' && (
              <div className="mb-5 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2.5">
                <ShieldAlert className="w-5 h-5 shrink-0 text-amber-400" />
                <span>
                  <strong>Strict Email Verification:</strong> Every user must first sign up with an authentic email and verify via 6-digit OTP. Temporary and disposable domains are actively rejected.
                </span>
              </div>
            )}

            {/* Error & Feedback Messages */}
            {error && (
              <div className="mb-5 p-3.5 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2.5">
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}
            {tempMailWarning && (
              <div className="mb-5 p-3.5 rounded-2xl bg-rose-500/25 border border-rose-500/60 text-rose-200 text-xs flex items-center gap-2.5">
                <ShieldAlert className="w-5 h-5 shrink-0 text-rose-400" />
                <span>{tempMailWarning}</span>
              </div>
            )}
            {success && (
              <div className="mb-5 p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2.5">
                <CheckCircle className="w-5 h-5 shrink-0 text-emerald-400" />
                <span>{success}</span>
              </div>
            )}

            {/* ========================================================================= */}
            {/* VIEW 1: SIGN IN */}
            {/* ========================================================================= */}
            {authView === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-emerald-200 uppercase tracking-wider mb-1.5">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => handleEmailChange(e.target.value)}
                      placeholder="e.g. admin@fortisinvicta.gm or your email"
                      className="w-full bg-[#07130F] border border-emerald-800/80 rounded-2xl pl-10 pr-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-bold text-emerald-200 uppercase tracking-wider">
                      Password
                    </label>
                    <span className="text-[11px] text-slate-400">
                      Case-sensitive
                    </span>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter password (e.g. Fortis2026!Admin)"
                      className="w-full bg-[#07130F] border border-emerald-800/80 rounded-2xl pl-10 pr-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black py-3.5 rounded-2xl text-xs uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 disabled:opacity-50 cursor-pointer transform active:scale-98"
                >
                  <Key className="w-4 h-4" />
                  <span>{loading ? 'Authenticating...' : 'Sign In with Email'}</span>
                </button>

                <p className="text-center text-xs text-slate-400 pt-2">
                  First time here?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setAuthView('signup');
                      setError(null);
                    }}
                    className="text-amber-300 font-bold hover:underline cursor-pointer"
                  >
                    Create and verify your account first →
                  </button>
                </p>
              </form>
            )}

            {/* ========================================================================= */}
            {/* VIEW 2: SIGN UP */}
            {/* ========================================================================= */}
            {authView === 'signup' && (
              <form onSubmit={handleSignupSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-emerald-200 uppercase tracking-wider mb-1.5">
                    Full Legal Name
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Lamin Ceesay or Modou Touray"
                      className="w-full bg-[#07130F] border border-emerald-800/80 rounded-2xl pl-10 pr-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-emerald-200 uppercase tracking-wider mb-1.5">
                      Assigned Role
                    </label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value as UserRole)}
                      className="w-full bg-[#07130F] border border-emerald-800/80 rounded-2xl px-3.5 py-3 text-xs text-white focus:outline-none focus:border-amber-400 transition cursor-pointer"
                    >
                      <option value="client">Client / System Owner</option>
                      <option value="site_inspector">Site Inspector / Field Engineer</option>
                      <option value="installer">Field Installer</option>
                      <option value="finance_officer">Finance / Ecobank Controller</option>
                      <option value="project_manager">Project Manager</option>
                      <option value="institutional_admin">Union / Institutional Admin</option>
                      <option value="super_admin">Fortis Executive / Super Admin</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-emerald-200 uppercase tracking-wider mb-1.5">
                      Phone Number
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+220 7XX XXXX"
                        className="w-full bg-[#07130F] border border-emerald-800/80 rounded-2xl pl-10 pr-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition"
                      />
                    </div>
                  </div>
                </div>

                {role === 'institutional_admin' && (
                  <div>
                    <label className="block text-xs font-bold text-emerald-200 uppercase tracking-wider mb-1.5">
                      Affiliated Union / Institution
                    </label>
                    <div className="relative">
                      <Building2 className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                      <select
                        value={institutionId}
                        onChange={(e) => setInstitutionId(e.target.value)}
                        className="w-full bg-[#07130F] border border-emerald-800/80 rounded-2xl pl-10 pr-4 py-3 text-xs text-white focus:outline-none focus:border-amber-400 transition cursor-pointer"
                      >
                        <option value="GTUCCU">GTUCCU (Gambia Teachers Union Credit Union)</option>
                        <option value="NAGNMC">NAGNMC (Nurses & Midwives Council)</option>
                        <option value="GAMPOST">GAMPOST (Postal Services)</option>
                        <option value="GAMTEL">GAMTEL / GAMCEL</option>
                        <option value="NAWEC">NAWEC Staff Credit Union</option>
                      </select>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-emerald-200 uppercase tracking-wider mb-1.5">
                    Authentic Email Address <span className="text-amber-400 font-normal">(No temp mail)</span>
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => handleEmailChange(e.target.value)}
                      placeholder="name@company.com, name@gtu.gm, or personal email"
                      className={`w-full bg-[#07130F] border rounded-2xl pl-10 pr-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none transition ${
                        tempMailWarning ? 'border-rose-500 focus:border-rose-400' : 'border-emerald-800/80 focus:border-amber-400'
                      }`}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-emerald-200 uppercase tracking-wider mb-1.5">
                    Create Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Minimum 8 characters with 1 uppercase, 1 number, 1 symbol"
                      className="w-full bg-[#07130F] border border-emerald-800/80 rounded-2xl pl-10 pr-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading || !!tempMailWarning}
                  className="w-full mt-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-3.5 rounded-2xl text-xs uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/20 disabled:opacity-50 cursor-pointer transform active:scale-98"
                >
                  <Send className="w-4 h-4" />
                  <span>{loading ? 'Registering...' : 'Sign Up & Request Verification Code'}</span>
                </button>

                <p className="text-center text-xs text-slate-400 pt-2">
                  Already registered?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setAuthView('login');
                      setError(null);
                    }}
                    className="text-amber-300 font-bold hover:underline cursor-pointer"
                  >
                    Sign in with existing credentials →
                  </button>
                </p>
              </form>
            )}

            {/* ========================================================================= */}
            {/* VIEW 3: OTP VERIFICATION */}
            {/* ========================================================================= */}
            {authView === 'verify' && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-center">
                  <p className="text-xs text-emerald-300 font-bold mb-1">6-Digit Verification Code Dispatched</p>
                  <p className="text-xs text-white font-mono font-bold">{email}</p>
                  <p className="text-[11px] text-slate-400 mt-2">
                    Enter the 6-digit OTP sent to your inbox to complete verification and enter the platform.
                  </p>
                </div>

                {demoCodeHint && (
                  <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] uppercase font-black text-amber-400 block">Development Inbox OTP</span>
                      <span className="font-mono text-lg font-black text-amber-300 tracking-widest">{demoCodeHint}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setVerificationCode(demoCodeHint)}
                      className="px-3 py-1.5 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs hover:bg-amber-300 transition cursor-pointer"
                    >
                      Auto-Fill OTP
                    </button>
                  </div>
                )}

                <form onSubmit={handleVerifySubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-emerald-200 uppercase tracking-wider mb-2 text-center">
                      Enter 6-Digit Code
                    </label>
                    <div className="relative">
                      <Key className="w-5 h-5 absolute left-4 top-3.5 text-slate-400" />
                      <input
                        type="text"
                        required
                        maxLength={6}
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                        placeholder="123456"
                        className="w-full bg-[#07130F] border border-emerald-800/80 rounded-2xl py-3 text-center font-mono text-xl tracking-[0.4em] font-black text-amber-300 focus:outline-none focus:border-amber-400 transition"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading || verificationCode.length < 6}
                    className="w-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black py-3.5 rounded-2xl text-xs uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 disabled:opacity-50 cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{loading ? 'Verifying Code...' : 'Verify Email & Access Portal'}</span>
                  </button>
                </form>

                <div className="flex items-center justify-between text-xs pt-2 text-slate-400">
                  <button
                    type="button"
                    onClick={handleResendCode}
                    disabled={loading}
                    className="flex items-center gap-1 text-emerald-400 hover:underline font-semibold cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Resend Code</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setAuthView('signup')}
                    className="text-slate-400 hover:text-white transition cursor-pointer"
                  >
                    Change Email
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Official Super Admin & Staff Credentials Reference */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-[#0E2019]/90 border border-emerald-800/80 rounded-3xl p-5 sm:p-6 shadow-2xl backdrop-blur-xl">
              <div className="flex items-center justify-between border-b border-emerald-900/80 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <Key className="w-5 h-5 text-amber-400" />
                  <div>
                    <h3 className="text-sm font-bold font-serif text-white">Official Sign-In Credentials</h3>
                    <p className="text-[11px] text-slate-400">Pre-configured operational accounts</p>
                  </div>
                </div>
                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                  8 Roles Active
                </span>
              </div>

              <p className="text-xs text-slate-300 mb-3">
                Click any official role below to auto-fill its registered email and password:
              </p>

              {/* Scrollable list of official credentials */}
              <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-emerald-800">
                {OFFICIAL_CREDENTIALS.map((cred) => (
                  <div
                    key={cred.email}
                    onClick={() => handleSelectCredential(cred)}
                    className="p-3 rounded-2xl bg-[#07130F]/90 border border-emerald-900/80 hover:border-amber-400/60 hover:bg-[#122A21] transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md border ${cred.badgeColor}`}>
                        {cred.roleName}
                      </span>
                      <span className="text-[10px] font-bold text-amber-400 group-hover:text-amber-300 flex items-center gap-1">
                        <span>Select</span>
                        <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                      </span>
                    </div>

                    <div className="text-xs font-mono font-bold text-white flex items-center justify-between">
                      <span className="truncate">{cred.email}</span>
                      <button
                        type="button"
                        onClick={(e) => handleCopy(cred.email, e)}
                        title="Copy email"
                        className="text-slate-400 hover:text-amber-300 p-1"
                      >
                        {copiedEmail === cred.email ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                      <span>Password: <strong className="text-slate-200 font-mono">{cred.password}</strong></span>
                      <span className="text-[10px] text-emerald-400">Verified</span>
                    </div>

                    <p className="text-[10px] text-slate-400/90 mt-1 line-clamp-2 leading-relaxed">
                      {cred.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Security & Compliance Note */}
            <div className="bg-[#0B1A14] border border-emerald-900/60 rounded-2xl p-4 text-xs text-slate-400 flex items-start gap-3">
              <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-200 block text-[11px]">Strict Access Control Enforced:</strong>
                <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                  Only authenticated users can view project metrics, customer files, and financial ledgers. All actions are cryptographically signed and audit-logged under UK GDPR and The Gambia Data Protection Act.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-emerald-900/60 bg-[#07130F] py-3 text-center text-xs text-slate-500 z-10">
        <p>© 2026 Fortis Invicta Ltd. Certified Solar Engineering & Project Financing Platform. Banjul, The Gambia.</p>
      </footer>
    </div>
  );
};
