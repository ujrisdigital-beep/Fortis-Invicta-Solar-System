import React, { useState, useEffect } from 'react';
import { ApiOrchestrator, MoodleCertificate, ORCHESTRATOR_ENV } from '../../services/api/orchestrator';
import { Award, CheckCircle, RefreshCw, AlertCircle, ShieldCheck } from 'lucide-react';

export const MoodleCertWidget: React.FC = () => {
  const [certs, setCerts] = useState<MoodleCertificate[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorState, setErrorState] = useState<string | null>(null);

  const fetchAccreditations = async () => {
    try {
      setLoading(true);
      const result = await ApiOrchestrator.fetchCertifications();
      if (result && result.success && result.data && result.data.length > 0) {
        setCerts(result.data);
        setErrorState(null);
      } else {
        setErrorState(result?.error || `Service Offline: Moodle on ${ORCHESTRATOR_ENV.MOODLE_URL}`);
        setCerts([]);
      }
    } catch {
      setErrorState(`Service Offline: Moodle on ${ORCHESTRATOR_ENV.MOODLE_URL}`);
      setCerts([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      try {
        setLoading(true);
        const result = await ApiOrchestrator.fetchCertifications();
        if (!isMounted) return;
        if (result && result.success && result.data && result.data.length > 0) {
          setCerts(result.data);
          setErrorState(null);
        } else {
          setErrorState(result?.error || `Service Offline: Moodle on ${ORCHESTRATOR_ENV.MOODLE_URL}`);
          setCerts([]);
        }
      } catch {
        if (!isMounted) return;
        setErrorState(`Service Offline: Moodle on ${ORCHESTRATOR_ENV.MOODLE_URL}`);
        setCerts([]);
      } finally {
        if (isMounted) setLoading(false);
      }
    };
    load();
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div id="moodle-cert-widget" className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-amber-50 text-amber-800 rounded-xl">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 font-serif">Moodle Academy Accreditation</h3>
            <p className="text-xs text-slate-500">Live technician certificates verified from Moodle LMS</p>
          </div>
        </div>

        <button
          onClick={fetchAccreditations}
          disabled={loading}
          className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors"
          title="Refresh Certifications"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {errorState ? (
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
          <div className="flex items-center gap-2 text-slate-700 text-xs font-semibold">
            <AlertCircle className="w-4 h-4 text-amber-500 shrink-0" />
            <span>{errorState}</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Ensure local Moodle container is listening on <code className="bg-slate-200/80 px-1 py-0.5 rounded font-mono">{ORCHESTRATOR_ENV.MOODLE_URL}</code>.
          </p>
        </div>
      ) : certs.length > 0 ? (
        <div className="space-y-3">
          {certs.map((c, idx) => (
            <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#1B4D3E]" />
                  <p className="text-xs font-bold text-slate-900">{c.installerName}</p>
                </div>
                <p className="text-[11px] text-slate-600 mt-0.5">{c.courseName}</p>
                {c.completionDate && (
                  <p className="text-[10px] text-slate-400">Certified Date: {c.completionDate}</p>
                )}
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 shrink-0">
                {c.certificationStatus}
              </span>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-4 text-center text-slate-400 text-xs">
          No active certifications returned from Moodle.
        </div>
      )}
    </div>
  );
};
