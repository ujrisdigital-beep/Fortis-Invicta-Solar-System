import React, { useState } from 'react';
import { Wrench, CheckSquare, Award, AlertTriangle, Cpu, Zap, ShieldCheck } from 'lucide-react';
import { InstallationLog, Client, Currency } from '../../types';
import { MoodleCertWidget } from './MoodleCertWidget';

interface InstallationHubProps {
  installations: InstallationLog[];
  clients: Client[];
  currency: Currency;
  onSaveInstallation: (log: InstallationLog) => void;
}

export const InstallationHub: React.FC<InstallationHubProps> = ({
  installations,
  clients,
  currency,
  onSaveInstallation
}) => {
  const [selectedInstId, setSelectedInstId] = useState<string>(installations[0]?.id || '');

  const currentLog = installations.find((i) => i.id === selectedInstId) || installations[0];

  const handleToggleChecklist = (key: keyof InstallationLog['checklists']) => {
    if (!currentLog) return;

    const updatedChecklists = {
      ...currentLog.checklists,
      [key]: !currentLog.checklists[key]
    };

    // Calculate progress
    const total = Object.keys(updatedChecklists).length;
    const completed = Object.values(updatedChecklists).filter(Boolean).length;
    const progressPercentage = Math.round((completed / total) * 100);

    const updatedLog: InstallationLog = {
      ...currentLog,
      checklists: updatedChecklists,
      progressPercentage,
      status: progressPercentage === 100 ? 'completed' : 'in_progress'
    };

    onSaveInstallation(updatedLog);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 font-serif">Installer Field Team Hub</h1>
          <p className="text-xs text-slate-500">
            Daily installation task tracking, equipment serial number logs, and commissioning certificates
          </p>
        </div>
      </div>

      {currentLog ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Active Job Progress */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-base font-bold text-slate-900 font-serif">{currentLog.clientName}</h2>
                <p className="text-xs text-slate-500">Team Leader: {currentLog.teamLeader}</p>
              </div>
              <span className="bg-purple-100 text-purple-800 text-xs font-bold px-3 py-1 rounded-full">
                {currentLog.progressPercentage}% Completed
              </span>
            </div>

            {/* Progress Bar */}
            <div>
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-[#1B4D3E] to-emerald-500 h-full transition-all duration-500"
                  style={{ width: `${currentLog.progressPercentage}%` }}
                />
              </div>
            </div>

            {/* Interactive Quality Checklist */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-bold uppercase text-slate-500">Installation Quality & Safety Checklist</h3>

              {Object.entries(currentLog.checklists).map(([key, val]) => (
                <label
                  key={key}
                  className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 cursor-pointer transition-colors text-xs font-medium text-slate-800"
                >
                  <input
                    type="checkbox"
                    checked={val}
                    onChange={() => handleToggleChecklist(key as any)}
                    className="w-4 h-4 text-[#1B4D3E] rounded cursor-pointer"
                  />
                  <span className="capitalize">{key.replace(/([A-Z])/g, ' $1').toLowerCase()}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Serial Numbers & Commissioning Certificate */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-slate-900 font-serif border-b border-slate-100 pb-3 flex items-center gap-2">
              <Cpu className="w-5 h-5 text-purple-700" />
              <span>Component Serial Numbers & Warranty Registration</span>
            </h2>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[10px]">Inverter Serial Number</span>
                <strong className="font-mono text-slate-900 text-sm">
                  {currentLog.serialNumbers?.inverter || 'FVS-55KVA-88391'}
                </strong>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[10px]">Lithium Battery Module ID</span>
                <strong className="font-mono text-slate-900 text-sm">
                  {currentLog.serialNumbers?.batteries?.[0] || 'LFP-10KWH-20260711'}
                </strong>
              </div>
            </div>

            {currentLog.progressPercentage === 100 && (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 text-xs space-y-2">
                <div className="flex items-center gap-2 font-bold text-sm text-emerald-900">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  COMMISSIONING CERTIFICATE READY
                </div>
                <p>System fully tested and operational. Official warranty active.</p>
                <button
                  onClick={() => alert(`Official Fortis Invicta Commissioning Certificate generated for ${currentLog.clientName}.`)}
                  className="bg-[#1B4D3E] hover:bg-[#143B2F] text-white font-bold px-4 py-2 rounded-xl shadow-sm text-xs"
                >
                  Download Signed Certificate
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-8 text-center text-slate-500">
          No active installations logged yet.
        </div>
      )}

      {/* Moodle LMS Academy Verified Accreditations */}
      <MoodleCertWidget />
    </div>
  );
};
