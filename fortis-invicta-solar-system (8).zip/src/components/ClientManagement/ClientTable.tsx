import React, { useState } from 'react';
import { Search, Filter, Plus, FileText, ChevronRight, CheckCircle2, AlertCircle, MessageSquare, Mail, Phone, Send, ShieldCheck } from 'lucide-react';
import { Client, ClientSegment, Currency, ProjectStage, UserRole } from '../../types';
import { formatCurrency, getStageLabel, getStageColor, getSegmentBadge, getPaymentStatusBadge } from '../../utils/formatters';
import { dispatchNotification } from '../../utils/messaging';
import { maskPhone, maskEmail, maskMemberID, maskAddress, formatGDPRFinancial } from '../../utils/gdpr';
import { QuickMessageModal } from '../Messaging/QuickMessageModal';

interface ClientTableProps {
  clients: Client[];
  currency: Currency;
  userRole?: UserRole;
  isGdprActive?: boolean;
  onSelectClient: (client: Client) => void;
  onNewClient: () => void;
  onUpdateStage: (clientId: string, newStage: ProjectStage) => void;
}

export const ClientTable: React.FC<ClientTableProps> = ({
  clients,
  currency,
  userRole = 'super_admin',
  isGdprActive = true,
  onSelectClient,
  onNewClient,
  onUpdateStage
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [segmentFilter, setSegmentFilter] = useState<string>('all');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [messagingClient, setMessagingClient] = useState<Client | null>(null);

  const isUnionAdmin = userRole === 'institutional_admin';

  const filteredClients = clients.filter((c) => {
    const matchesSearch =
      c.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.institutionMemberId && c.institutionMemberId.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesSegment = segmentFilter === 'all' || c.clientSegment === segmentFilter;
    const matchesStage = stageFilter === 'all' || c.projectStage === stageFilter;

    return matchesSearch && matchesSegment && matchesStage;
  });

  const stages: ProjectStage[] = [
    'lead',
    'assessment_scheduled',
    'assessment_complete',
    'payment_pending',
    'installation_scheduled',
    'installation_in_progress',
    'commissioning',
    'completed'
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header Controls */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 font-serif">Client Directory & Solar Projects</h1>
          <p className="text-xs text-slate-500">Manage 500+ solar onboarding records across all client segments</p>
        </div>

        <button
          onClick={onNewClient}
          className="flex items-center gap-2 bg-[#1B4D3E] hover:bg-[#143B2F] text-white font-semibold px-4 py-2.5 rounded-xl text-sm shadow-md transition-all"
        >
          <Plus className="w-4 h-4 text-amber-300" />
          <span>Onboard New Client</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by name, email, address, or GTUCCU/NAGNMC Member ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-[#1B4D3E]"
          />
        </div>

        {/* Segment Filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={segmentFilter}
            onChange={(e) => setSegmentFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-700 focus:outline-none"
          >
            <option value="all">All Segments ({clients.length})</option>
            <option value="gtuccu_member">GTUCCU Members</option>
            <option value="nagnmc_member">NAGNMC Healthcare</option>
            <option value="diaspora">Diaspora Clients</option>
            <option value="non_union_individual">Non-Union Individuals</option>
          </select>
        </div>

        {/* Stage Filter */}
        <select
          value={stageFilter}
          onChange={(e) => setStageFilter(e.target.value)}
          className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-700 focus:outline-none"
        >
          <option value="all">All 8 Project Stages</option>
          {stages.map((stg) => (
            <option key={stg} value={stg}>
              {getStageLabel(stg)}
            </option>
          ))}
        </select>
      </div>

      {/* Clients Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 uppercase font-semibold text-[10px] tracking-wider">
                <th className="p-3.5">Client Info</th>
                <th className="p-3.5">Segment & Member ID</th>
                <th className="p-3.5">Package</th>
                <th className="p-3.5">Stage & Quick Update</th>
                <th className="p-3.5">Payment State</th>
                <th className="p-3.5">{isUnionAdmin ? 'Total Quoted (Restricted)' : 'Total Quoted'}</th>
                <th className="p-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredClients.map((client) => {
                const segBadge = getSegmentBadge(client.clientSegment);
                const payBadge = getPaymentStatusBadge(client.paymentStatus);

                const displayEmail = isGdprActive ? maskEmail(client.email) : client.email;
                const displayPhone = isGdprActive ? maskPhone(client.phone) : client.phone;
                const displayAddress = isGdprActive ? maskAddress(client.address) : client.address;
                const displayMemberID = isGdprActive ? maskMemberID(client.institutionMemberId) : client.institutionMemberId;

                return (
                  <tr key={client.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Name & Contact */}
                    <td className="p-3.5 font-bold text-slate-900">
                      <div className="text-sm font-semibold text-slate-900">{client.fullName}</div>
                      <div className="text-[11px] font-normal text-slate-500">{displayEmail} • {displayPhone}</div>
                      <div className="text-[10px] font-normal text-slate-400 truncate max-w-[200px]">{displayAddress}</div>
                    </td>

                    {/* Segment Badge */}
                    <td className="p-3.5">
                      <span className={`inline-block border px-2 py-0.5 rounded text-[11px] font-semibold ${segBadge.color}`}>
                        {segBadge.label}
                      </span>
                      {client.institutionMemberId && (
                        <div className="text-[10px] font-mono text-emerald-700 font-bold mt-1">
                          ID: {displayMemberID}
                        </div>
                      )}
                    </td>

                    {/* Solar Package */}
                    <td className="p-3.5 font-medium text-slate-800">
                      <span className="capitalize font-bold text-slate-900">
                        {client.packageId.replace('_', ' ')}
                      </span>
                      <div className="text-[10px] text-slate-500 capitalize">
                        Financing: {client.financingType.replace('_', ' ')}
                      </div>
                    </td>

                    {/* Project Stage */}
                    <td className="p-3.5">
                      <select
                        value={client.projectStage}
                        onChange={(e) => onUpdateStage(client.id, e.target.value as ProjectStage)}
                        className={`text-[11px] font-semibold px-2 py-1 rounded border cursor-pointer focus:outline-none ${getStageColor(
                          client.projectStage
                        )}`}
                      >
                        {stages.map((stg) => (
                          <option key={stg} value={stg} className="bg-white text-slate-900">
                            {getStageLabel(stg)}
                          </option>
                        ))}
                      </select>
                    </td>

                    {/* Payment Badge */}
                    <td className="p-3.5">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${payBadge.color}`}>
                        {payBadge.label}
                      </span>
                      <div className="text-[10px] text-slate-500 mt-1">
                        Paid: {isUnionAdmin ? '[Restricted]' : formatCurrency(client.totalPaidGMD, currency)}
                      </div>
                    </td>

                    {/* Total Quoted */}
                    <td className="p-3.5 font-extrabold text-slate-900">
                      {isUnionAdmin ? (
                        <span className="text-slate-400 font-mono text-[11px] bg-slate-100 px-2 py-1 rounded">
                          [Restricted - Union View]
                        </span>
                      ) : (
                        formatCurrency(client.totalQuotedGMD, currency)
                      )}
                    </td>

                    {/* View Action & Quick WhatsApp Chat */}
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => dispatchNotification('whatsapp', 'stage_update', client)}
                          title="WhatsApp Click-to-Chat Direct"
                          className="bg-emerald-700 hover:bg-emerald-800 text-amber-300 p-2 rounded-xl text-xs font-bold shadow-sm transition-all cursor-pointer flex items-center gap-1"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">WhatsApp</span>
                        </button>

                        <button
                          onClick={() => setMessagingClient(client)}
                          title="Open Message Dispatch Hub"
                          className="bg-amber-400 hover:bg-amber-300 text-slate-950 p-2 rounded-xl text-xs font-extrabold shadow-sm transition-all cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => onSelectClient(client)}
                          className="bg-[#1B4D3E] hover:bg-[#143B2F] text-white px-3 py-2 rounded-xl font-semibold text-xs shadow-sm transition-all cursor-pointer"
                        >
                          View Record
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredClients.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500">
                    No clients found matching filter parameters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Message Modal Render */}
      {messagingClient && (
        <QuickMessageModal
          client={messagingClient}
          isOpen={!!messagingClient}
          onClose={() => setMessagingClient(null)}
          defaultTemplate="stage_update"
        />
      )}
    </div>
  );
};
