import React, { useState } from 'react';
import {
  X,
  User,
  MapPin,
  Phone,
  Mail,
  Building2,
  Calendar,
  CreditCard,
  FileText,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Send,
  Download,
  Copy,
  Check,
  Printer,
  Upload,
  FolderOpen,
  Tag,
  Trash2,
  Compass,
  Loader2,
  FileCheck,
  Image as ImageIcon,
  MessageSquare
} from 'lucide-react';
import { Client, Currency, PaymentRecord, ProjectStage, MultimediaRecord, UserRole } from '../../types';
import { formatCurrency, getStageLabel, getSegmentBadge, getPaymentStatusBadge, getStageColor } from '../../utils/formatters';
import { StorageService } from '../../services/storage';
import { PDFDocumentGenerator } from '../../utils/pdfGenerator';
import { dispatchNotification, MessageChannel, TemplateType } from '../../utils/messaging';
import { maskPhone, maskEmail, maskMemberID, maskAddress } from '../../utils/gdpr';
import { safeCopyToClipboard } from '../../utils/clipboard';
import { QuickMessageModal } from '../Messaging/QuickMessageModal';

interface ClientDetailModalProps {
  client: Client | null;
  onClose: () => void;
  currency: Currency;
  userRole?: UserRole;
  isGdprActive?: boolean;
  onConfirmPayment: (paymentId: string) => void;
  onUpdateStage: (clientId: string, newStage: ProjectStage) => void;
  payments: PaymentRecord[];
}

export const ClientDetailModal: React.FC<ClientDetailModalProps> = ({
  client,
  onClose,
  currency,
  userRole = 'super_admin',
  isGdprActive = true,
  onConfirmPayment,
  onUpdateStage,
  payments
}) => {
  if (!client) return null;

  const isUnionAdmin = userRole === 'institutional_admin';

  const [activeTab, setActiveTab] = useState<'overview' | 'property' | 'documents' | 'ecobank' | 'inspection' | 'messaging' | 'notes'>('overview');
  const [isMsgModalOpen, setIsMsgModalOpen] = useState(false);
  const [msgTemplateType, setMsgTemplateType] = useState<TemplateType>('stage_update');
  const [copiedHTML, setCopiedHTML] = useState(false);
  const [detectingGps, setDetectingGps] = useState(false);
  const [gpsMessage, setGpsMessage] = useState<string | null>(null);

  // Document Upload State
  const [docCategory, setDocCategory] = useState<'site_photo' | 'contract' | 'assessment_report' | 'payslip' | 'receipt' | 'other'>('site_photo');
  const [docTitle, setDocTitle] = useState('');
  const [docDescription, setDocDescription] = useState('');
  const [docFileUrl, setDocFileUrl] = useState('');

  const clientPayments = payments.filter((p) => p.clientId === client.id);
  const segBadge = getSegmentBadge(client.clientSegment);
  const payBadge = getPaymentStatusBadge(client.paymentStatus);

  // Get project documents for this client
  const [multimedia, setMultimedia] = useState<MultimediaRecord[]>(() =>
    StorageService.getMultimedia(client.id)
  );

  const openSolarHTML = StorageService.generateOpenSolarDirectPaymentInstructions(
    client.fullName,
    client.outstandingBalanceGMD > 0 ? client.outstandingBalanceGMD : client.totalQuotedGMD,
    `ECO-REF-${client.id.toUpperCase()}`
  );

  const handleCopyHTML = () => {
    safeCopyToClipboard(openSolarHTML).catch(() => {});
    setCopiedHTML(true);
    setTimeout(() => setCopiedHTML(false), 2500);
  };

  // Browser Geolocation API Capture
  const handleCaptureGps = () => {
    if (!navigator.geolocation) {
      setGpsMessage('Browser does not support Geolocation API.');
      return;
    }

    setDetectingGps(true);
    setGpsMessage(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = parseFloat(pos.coords.latitude.toFixed(6));
        const lng = parseFloat(pos.coords.longitude.toFixed(6));
        const formatted = `${lat}° N, ${lng}° W (Device Auto-Captured)`;

        const updatedClient = {
          ...client,
          gpsCoordinates: { lat, lng, formatted }
        };

        StorageService.saveClient(updatedClient, 'Project Manager', 'project_manager');
        setDetectingGps(false);
        setGpsMessage(`✓ GPS Coordinates updated: ${formatted}`);
        setTimeout(() => setGpsMessage(null), 4000);
      },
      (err) => {
        setDetectingGps(false);
        setGpsMessage(`GPS Access Failed: ${err.message}. Defaulting to region center.`);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Handle Document Upload
  const handleUploadDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim()) return;

    StorageService.addMultimedia(
      {
        title: docTitle,
        category: docCategory === 'site_photo' ? 'photo' : docCategory === 'assessment_report' ? 'assessment' : 'report',
        mediaUrl: docFileUrl || 'https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&q=80&w=800',
        fileType: docFileUrl.endsWith('.pdf') ? 'pdf' : 'image',
        fileSizeFormatted: '1.2 MB',
        description: docDescription,
        clientId: client.id,
        gpsCoordinates: client.gpsCoordinates || {
          lat: 13.3981,
          lng: -16.7121,
          formatted: '13.3981° N, 16.7121° W (Site Location)'
        },
        uploadedBy: 'Project Manager',
        uploadedByRole: 'project_manager'
      },
      'Project Manager',
      'project_manager'
    );

    setMultimedia(StorageService.getMultimedia(client.id));
    setDocTitle('');
    setDocDescription('');
    setDocFileUrl('');
  };

  const handleDeleteDocument = (docId: string) => {
    StorageService.deleteMultimedia(docId, 'Project Manager');
    setMultimedia(StorageService.getMultimedia(client.id));
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Header Modal */}
        <div className="bg-[#12241D] text-white p-6 border-b border-[#1B4D3E] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#1B4D3E] text-amber-300 flex items-center justify-center font-bold text-xl">
              {client.fullName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold font-serif">{client.fullName}</h2>
                <span className={`px-2.5 py-0.5 rounded text-[11px] font-bold ${segBadge.color}`}>
                  {segBadge.label}
                </span>
              </div>
              <p className="text-xs text-emerald-300/80">
                {isGdprActive ? maskEmail(client.email) : client.email} • {isGdprActive ? maskPhone(client.phone) : client.phone} • GPS: {client.gpsCoordinates?.formatted || 'Not set'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#1B4D3E] hover:bg-[#236350] text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* PDF Quick Generation Toolbar */}
        <div className="bg-[#0D1A15] px-6 py-2 border-b border-emerald-900/60 flex items-center gap-2 overflow-x-auto text-xs scrollbar-none">
          <span className="text-amber-400 font-bold uppercase text-[10px] tracking-wider whitespace-nowrap flex items-center gap-1">
            <Printer className="w-3.5 h-3.5" /> PDF Documents:
          </span>

          <button
            onClick={() => PDFDocumentGenerator.generateQuotationPDF(client, currency)}
            className="bg-[#1B4D3E] hover:bg-emerald-800 text-amber-300 px-2.5 py-1 rounded-md font-semibold text-[11px] flex items-center gap-1 whitespace-nowrap transition-colors cursor-pointer border border-emerald-700/50"
          >
            <FileText className="w-3 h-3" />
            <span>Quotation</span>
          </button>

          <button
            onClick={() => PDFDocumentGenerator.generateInvoicePDF(client, currency)}
            className="bg-[#1B4D3E] hover:bg-emerald-800 text-white px-2.5 py-1 rounded-md font-semibold text-[11px] flex items-center gap-1 whitespace-nowrap transition-colors cursor-pointer border border-emerald-700/50"
          >
            <FileCheck className="w-3 h-3 text-cyan-300" />
            <span>Invoice</span>
          </button>

          <button
            onClick={() => {
              const lastConfirmed = clientPayments.find((p) => p.status === 'confirmed') || clientPayments[0];
              if (lastConfirmed) {
                PDFDocumentGenerator.generateReceiptPDF(client, lastConfirmed, currency);
              } else {
                alert('No payments logged yet for receipt generation. Generate quotation or invoice first.');
              }
            }}
            className="bg-[#1B4D3E] hover:bg-emerald-800 text-emerald-300 px-2.5 py-1 rounded-md font-semibold text-[11px] flex items-center gap-1 whitespace-nowrap transition-colors cursor-pointer border border-emerald-700/50"
          >
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>Payment Receipt</span>
          </button>

          <button
            onClick={() => PDFDocumentGenerator.generateAssessmentPDF(client, undefined, currency)}
            className="bg-[#1B4D3E] hover:bg-emerald-800 text-indigo-300 px-2.5 py-1 rounded-md font-semibold text-[11px] flex items-center gap-1 whitespace-nowrap transition-colors cursor-pointer border border-emerald-700/50"
          >
            <ShieldCheck className="w-3 h-3 text-indigo-400" />
            <span>Assessment Report</span>
          </button>

          <button
            onClick={() => PDFDocumentGenerator.generatePaymentOptionsPDF(client, currency)}
            className="bg-[#1B4D3E] hover:bg-emerald-800 text-amber-300 px-2.5 py-1 rounded-md font-semibold text-[11px] flex items-center gap-1 whitespace-nowrap transition-colors cursor-pointer border border-emerald-700/50"
          >
            <CreditCard className="w-3 h-3 text-amber-400" />
            <span>Ecobank Options Sheet</span>
          </button>

          <span className="text-amber-400 font-bold uppercase text-[10px] tracking-wider whitespace-nowrap ml-2 flex items-center gap-1">
            <MessageSquare className="w-3.5 h-3.5" /> Direct Messaging:
          </span>

          <button
            onClick={() => dispatchNotification('whatsapp', 'stage_update', client)}
            className="bg-emerald-700 hover:bg-emerald-800 text-white px-2.5 py-1 rounded-md font-bold text-[11px] flex items-center gap-1 whitespace-nowrap transition-colors cursor-pointer"
          >
            <MessageSquare className="w-3 h-3 text-amber-300" />
            <span>WhatsApp</span>
          </button>

          <button
            onClick={() => dispatchNotification('email', 'stage_update', client)}
            className="bg-blue-700 hover:bg-blue-800 text-white px-2.5 py-1 rounded-md font-bold text-[11px] flex items-center gap-1 whitespace-nowrap transition-colors cursor-pointer"
          >
            <Mail className="w-3 h-3 text-blue-200" />
            <span>Email</span>
          </button>

          <button
            onClick={() => dispatchNotification('sms', 'stage_update', client)}
            className="bg-purple-700 hover:bg-purple-800 text-white px-2.5 py-1 rounded-md font-bold text-[11px] flex items-center gap-1 whitespace-nowrap transition-colors cursor-pointer"
          >
            <Phone className="w-3 h-3 text-purple-200" />
            <span>SMS</span>
          </button>
        </div>

        {/* Tab Selection */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 flex gap-4 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'overview'
                ? 'border-[#1B4D3E] text-[#1B4D3E] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Project Overview & Financials
          </button>
          <button
            onClick={() => setActiveTab('property')}
            className={`py-3 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'property'
                ? 'border-[#1B4D3E] text-[#1B4D3E] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Property & Site Logistics
          </button>
          <button
            onClick={() => setActiveTab('messaging')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'messaging'
                ? 'border-[#1B4D3E] text-[#1B4D3E] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
            Messaging & Notifications ({(client.messageHistory || []).length})
          </button>
          <button
            onClick={() => setActiveTab('documents')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'documents'
                ? 'border-[#1B4D3E] text-[#1B4D3E] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <FolderOpen className="w-3.5 h-3.5 text-teal-600" />
            Project Documents ({multimedia.length})
          </button>
          <button
            onClick={() => setActiveTab('ecobank')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'ecobank'
                ? 'border-[#1B4D3E] text-[#1B4D3E] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5 text-amber-600" />
            Ecobank Direct Transfer
          </button>
          <button
            onClick={() => setActiveTab('inspection')}
            className={`py-3 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'inspection'
                ? 'border-[#1B4D3E] text-[#1B4D3E] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Site Assessment
          </button>
          <button
            onClick={() => setActiveTab('notes')}
            className={`py-3 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'notes'
                ? 'border-[#1B4D3E] text-[#1B4D3E] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Notes & Verification
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 max-h-[70vh] overflow-y-auto space-y-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Stage Progress Banner */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div className="flex justify-between items-center mb-2 text-xs">
                  <span className="font-bold text-slate-700">Project Stage Progress</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${getStageColor(client.projectStage)}`}>
                    Current: {getStageLabel(client.projectStage)}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
                  <div className="text-center bg-white p-2 rounded-xl border border-slate-200 text-xs">
                    <span className="text-slate-400 block text-[10px]">Package</span>
                    <strong className="text-slate-900 capitalize">{client.packageId.replace('_', ' ')}</strong>
                  </div>
                  <div className="text-center bg-white p-2 rounded-xl border border-slate-200 text-xs">
                    <span className="text-slate-400 block text-[10px]">Quoted Amount</span>
                    <strong className="text-slate-900">
                      {isUnionAdmin ? '[Restricted]' : formatCurrency(client.totalQuotedGMD, currency)}
                    </strong>
                  </div>
                  <div className="text-center bg-white p-2 rounded-xl border border-slate-200 text-xs">
                    <span className="text-slate-400 block text-[10px]">Total Paid</span>
                    <strong className="text-emerald-700">
                      {isUnionAdmin ? '[Restricted]' : formatCurrency(client.totalPaidGMD, currency)}
                    </strong>
                  </div>
                  <div className="text-center bg-white p-2 rounded-xl border border-slate-200 text-xs">
                    <span className="text-slate-400 block text-[10px]">Outstanding</span>
                    <strong className="text-rose-600">
                      {isUnionAdmin ? '[Restricted]' : formatCurrency(client.outstandingBalanceGMD, currency)}
                    </strong>
                  </div>
                </div>

                {/* Application-Time Inflation & Forex Snapshot */}
                {(client.appliedInflationRate !== undefined || client.appliedForexRateUSD !== undefined) && (
                  <div className="mt-3 p-2.5 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-950 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 font-bold">
                      <span className="bg-amber-200 text-amber-900 px-2 py-0.5 rounded text-[10px]">
                        Pricing Snapshot Lock
                      </span>
                      <span>
                        Base Rate: {formatCurrency(client.customPackagePriceGMD || client.totalQuotedGMD, currency)}
                      </span>
                      {client.appliedInflationRate !== undefined && (
                        <span>• Inflation Buffer: +{client.appliedInflationRate}%</span>
                      )}
                    </div>
                    {client.appliedForexRateUSD && (
                      <span className="font-mono text-slate-700 text-[10px]">
                        Forex Lock: 1 USD = {client.appliedForexRateUSD} GMD ({client.priceLockedAt ? new Date(client.priceLockedAt).toLocaleDateString() : 'Application Time'})
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Institutional Verification Status */}
              {client.institutionId && (
                <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="w-6 h-6 text-teal-700" />
                    <div>
                      <div className="font-bold text-teal-950">
                        Institutional Affiliation: {client.institutionId} Member
                      </div>
                      <div className="text-teal-800">
                        Member ID: <span className="font-mono font-bold">{isGdprActive ? maskMemberID(client.institutionMemberId) : client.institutionMemberId}</span> • Verification Status: {client.institutionVerified ? 'APPROVED' : 'PENDING'}
                      </div>
                    </div>
                  </div>
                  <span className="bg-teal-200 text-teal-900 px-2.5 py-1 rounded-lg font-bold text-[10px]">
                    24-Month Salary Deduction Scheme
                  </span>
                </div>
              )}

              {/* Recorded Payments List */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-slate-900 font-serif">Recorded Ecobank Payments & Ledger</h3>
                {clientPayments.length === 0 ? (
                  <p className="text-xs text-slate-500 italic bg-slate-50 p-4 rounded-xl text-center">
                    No payment records logged yet. Use Ecobank payment module to submit teller slip or bank wire.
                  </p>
                ) : (
                  <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[10px]">
                        <tr className="border-b border-slate-200">
                          <th className="p-3">Ref Code</th>
                          <th className="p-3">Method</th>
                          <th className="p-3">Amount GMD</th>
                          <th className="p-3">Status</th>
                          <th className="p-3 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {clientPayments.map((p) => (
                          <tr key={p.id}>
                            <td className="p-3 font-mono font-bold text-slate-900">{p.referenceNumber}</td>
                            <td className="p-3 capitalize">{p.paymentMethod.replace('_', ' ')}</td>
                            <td className="p-3 font-bold text-emerald-800">{formatCurrency(p.amountGMD, currency)}</td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${getPaymentStatusBadge(p.status).color}`}>
                                {getPaymentStatusBadge(p.status).label}
                              </span>
                            </td>
                            <td className="p-3 text-right">
                              {p.status === 'confirmation_required' && (
                                <button
                                  onClick={() => onConfirmPayment(p.id)}
                                  className="bg-amber-600 hover:bg-amber-700 text-white font-bold px-2.5 py-1 rounded text-[10px]"
                                >
                                  Confirm Deposit
                                </button>
                              )}
                              {p.status === 'confirmed' && (
                                <span className="text-[10px] text-emerald-700 font-bold">Receipt {p.receiptNumber}</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'property' && (
            <div className="space-y-4 text-xs">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <h3 className="text-sm font-bold text-slate-900 font-serif flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#1B4D3E]" />
                  <span>Site Property Parameters & Logistics Metadata</span>
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Region / Division</span>
                    <strong className="text-slate-900 text-xs">{client.propertyDetails?.region || 'West Coast / Kombo'}</strong>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Distance & Surcharge</span>
                    <strong className="text-emerald-800 text-xs">
                      {client.propertyDetails?.distanceFromDepotKM || 20} KM (+GMD {client.propertyDetails?.logisticsSurchargeGMD || 0})
                    </strong>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Property Type</span>
                    <strong className="text-slate-900 text-xs">{client.propertyDetails?.propertyType || 'Residential Compound'}</strong>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Roof Racking Structure</span>
                    <strong className="text-slate-900 text-xs">{client.propertyDetails?.roofType || 'Corrugated Iron (Zinc)'}</strong>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">NAWEC Grid Conditions</span>
                    <strong className="text-amber-700 text-xs">{client.propertyDetails?.gridReliability || 'Daily Outages (6-12 hrs)'}</strong>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Electrical Phase Supply</span>
                    <strong className="text-slate-900 text-xs">{client.propertyDetails?.phaseType || 'Single Phase 220V'}</strong>
                  </div>
                </div>
              </div>

              {/* GPS Location Details & Auto-Capture */}
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] uppercase font-bold text-emerald-800 block">Verified GPS Site Coordinates</span>
                  <span className="font-mono font-bold text-emerald-950 text-xs">{client.gpsCoordinates?.formatted || '13.3981° N, 16.7121° W'}</span>
                  {gpsMessage && (
                    <div className="text-[10px] font-bold text-emerald-800 mt-1">{gpsMessage}</div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCaptureGps}
                    disabled={detectingGps}
                    className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-1.5 rounded-xl text-[11px] flex items-center gap-1.5 transition-all shadow-sm cursor-pointer disabled:opacity-50"
                  >
                    {detectingGps ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Compass className="w-3.5 h-3.5" />
                    )}
                    <span>{detectingGps ? 'Capturing GPS...' : 'Auto-Capture GPS'}</span>
                  </button>

                  <a
                    href={`https://maps.google.com/?q=${client.gpsCoordinates?.lat || 13.3981},${client.gpsCoordinates?.lng || -16.7121}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#1B4D3E] text-amber-300 font-bold px-3 py-1.5 rounded-xl text-[11px] flex items-center gap-1 cursor-pointer"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    View on Map
                  </a>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="space-y-6 text-xs">
              {/* Document Upload Box */}
              <form onSubmit={handleUploadDocument} className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <h3 className="text-sm font-bold text-slate-900 font-serif flex items-center gap-2">
                  <Upload className="w-4 h-4 text-[#1B4D3E]" />
                  <span>Upload & Categorize New Project File</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Document Category / Tag</label>
                    <select
                      value={docCategory}
                      onChange={(e) => setDocCategory(e.target.value as any)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800"
                    >
                      <option value="site_photo">📸 Site Photo (Roof / Inverter Room / Meter)</option>
                      <option value="contract">📄 Signed Contract / Agreement PDF</option>
                      <option value="assessment_report">📋 Technical Site Assessment Report</option>
                      <option value="payslip">📑 Member Payslip / Union Identity Card</option>
                      <option value="receipt">🎟️ Bank Transfer / Ecobank Deposit Receipt</option>
                      <option value="other">📁 General Project File</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Document Title *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Roof Array Structure Photo or GTUCCU Contract"
                      value={docTitle}
                      onChange={(e) => setDocTitle(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">File URL / Attachment</label>
                    <input
                      type="text"
                      placeholder="https://... or leave empty for sample placeholder"
                      value={docFileUrl}
                      onChange={(e) => setDocFileUrl(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Description / Notes</label>
                    <input
                      type="text"
                      placeholder="Additional details regarding this document..."
                      value={docDescription}
                      onChange={(e) => setDocDescription(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 transition-all cursor-pointer shadow-sm"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Attach & Save Document</span>
                </button>
              </form>

              {/* Document List Grid */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-slate-900 text-sm font-serif">
                    Attached Files for {client.fullName} ({multimedia.length})
                  </h3>
                </div>

                {multimedia.length === 0 ? (
                  <div className="text-center p-8 bg-slate-50 rounded-2xl border border-dashed border-slate-300 text-slate-500">
                    <FolderOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="font-medium">No project files uploaded yet.</p>
                    <p className="text-[11px] text-slate-400 mt-1">Use the upload box above to attach contracts, photos, or assessment reports.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {multimedia.map((item) => (
                      <div key={item.id} className="bg-white border border-slate-200 rounded-2xl p-3 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start gap-2 mb-2">
                            <span className="bg-teal-100 text-teal-800 font-bold px-2 py-0.5 rounded text-[10px] uppercase tracking-wider flex items-center gap-1">
                              <Tag className="w-3 h-3" />
                              {item.category.replace('_', ' ')}
                            </span>
                            <button
                              onClick={() => handleDeleteDocument(item.id)}
                              className="text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                              title="Delete Document"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <h4 className="font-bold text-slate-900 text-xs mb-1">{item.title}</h4>
                          <p className="text-[11px] text-slate-500 line-clamp-2">{item.description || 'No description'}</p>

                          {item.fileType === 'image' && (
                            <img
                              src={item.mediaUrl}
                              alt={item.title}
                              className="w-full h-24 object-cover rounded-xl my-2 border border-slate-100"
                            />
                          )}
                        </div>

                        <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[10px] text-slate-400 mt-2">
                          <span>{new Date(item.capturedAt).toLocaleDateString()}</span>
                          <a
                            href={item.mediaUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                          >
                            <Download className="w-3 h-3" />
                            <span>View / Download</span>
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'ecobank' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-serif">OpenSolar Direct Payment Table</h3>
                  <p className="text-xs text-slate-500">Auto-generated HTML table for email/proposal sending</p>
                </div>

                <button
                  onClick={handleCopyHTML}
                  className="flex items-center gap-1.5 bg-[#1B4D3E] hover:bg-[#143B2F] text-white font-semibold text-xs px-3 py-1.5 rounded-xl shadow-sm transition-all"
                >
                  {copiedHTML ? <Check className="w-3.5 h-3.5 text-amber-300" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedHTML ? 'Copied HTML!' : 'Copy Formatted Instructions'}</span>
                </button>
              </div>

              {/* Renders OpenSolar HTML Table */}
              <div
                className="p-4 bg-slate-50 rounded-2xl border border-slate-200"
                dangerouslySetInnerHTML={{ __html: openSolarHTML }}
              />
            </div>
          )}

          {activeTab === 'messaging' && (
            <div className="space-y-6 text-xs">
              {/* Quick Messaging Launcher */}
              <div className="p-5 rounded-2xl bg-emerald-50/80 border border-emerald-300 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-emerald-800" />
                    <h3 className="font-bold text-slate-900 text-sm font-serif">
                      Instant Zero-Cost Client Messaging
                    </h3>
                  </div>
                  <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-2 py-0.5 rounded">
                    100% Free / Direct Link
                  </span>
                </div>
                <p className="text-slate-600 text-xs leading-relaxed">
                  Send pre-formatted notifications directly to <strong>{client.fullName}</strong> ({client.phone || client.email}). Opens natively on PC/Desktop (WhatsApp Web/Mail), iPad, and Mobile devices.
                </p>

                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    onClick={() => dispatchNotification('whatsapp', 'stage_update', client)}
                    className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-md transition-all cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4 text-amber-300" />
                    <span>WhatsApp Stage Update</span>
                  </button>

                  <button
                    onClick={() => dispatchNotification('email', 'payment_reminder', client)}
                    className="bg-blue-700 hover:bg-blue-800 text-white font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-md transition-all cursor-pointer"
                  >
                    <Mail className="w-4 h-4 text-blue-200" />
                    <span>Email Payment Notice</span>
                  </button>

                  <button
                    onClick={() => dispatchNotification('sms', 'inspection', client)}
                    className="bg-purple-700 hover:bg-purple-800 text-white font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-md transition-all cursor-pointer"
                  >
                    <Phone className="w-4 h-4 text-purple-200" />
                    <span>SMS Inspection Alert</span>
                  </button>

                  <button
                    onClick={() => {
                      setMsgTemplateType('custom');
                      setIsMsgModalOpen(true);
                    }}
                    className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-md transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4 text-slate-950" />
                    <span>Open Custom Dispatch Hub</span>
                  </button>
                </div>
              </div>

              {/* Message Dispatch History Log */}
              <div className="space-y-3">
                <h3 className="font-bold text-slate-900 text-sm font-serif">
                  Dispatched Message History Log ({(client.messageHistory || []).length})
                </h3>

                {(!client.messageHistory || client.messageHistory.length === 0) ? (
                  <p className="text-slate-500 italic bg-slate-50 p-4 rounded-xl text-center">
                    No message dispatches logged yet for this client. Use buttons above to dispatch a notice.
                  </p>
                ) : (
                  <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                    {client.messageHistory.map((msg, idx) => (
                      <div key={`${msg.id || 'msg'}-${idx}`} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] text-slate-500">
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded font-bold uppercase ${
                              msg.channel === 'whatsapp'
                                ? 'bg-emerald-100 text-emerald-800'
                                : msg.channel === 'email'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-purple-100 text-purple-800'
                            }`}>
                              {msg.channel}
                            </span>
                            <span className="font-bold text-slate-700">
                              Template: {msg.templateType.replace('_', ' ').toUpperCase()}
                            </span>
                          </div>
                          <span>
                            {new Date(msg.sentAt).toLocaleString()} • Sent by: <strong>{msg.sentBy}</strong>
                          </span>
                        </div>
                        <p className="font-mono text-[11px] text-slate-800 bg-white p-2.5 rounded-xl border border-slate-200 whitespace-pre-wrap">
                          {msg.messageText}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'inspection' && (
            <div className="space-y-4 text-xs text-slate-700">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <h3 className="font-bold text-slate-900 text-sm">Site Inspector Checklist Summary</h3>
                <p>Location: {client.address}</p>
                <p>GPS Coordinates: {client.gpsCoordinates?.formatted || 'Recorded on Site'}</p>
                <div className="pt-2 text-emerald-800 font-semibold">
                  ✓ Roof Structural Evaluation: Approved for Monocrystalline Array
                </div>
              </div>
            </div>
          )}

          {activeTab === 'notes' && (
            <div className="space-y-4 text-xs text-slate-700">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <h3 className="font-bold text-slate-900 text-sm">Project Notes</h3>
                <p>{client.notes || 'No special notes recorded.'}</p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-between items-center text-xs">
          <span className="text-slate-500">System Reference: {client.id}</span>
          <button
            onClick={onClose}
            className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold px-4 py-2 rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

        {/* Messaging Dispatch Modal */}
        <QuickMessageModal
          client={client}
          isOpen={isMsgModalOpen}
          onClose={() => setIsMsgModalOpen(false)}
          defaultTemplate={msgTemplateType}
        />
      </div>
    </div>
  );
};
