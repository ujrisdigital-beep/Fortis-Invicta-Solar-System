import React from 'react';
import fortisLogoImg from '../assets/images/fortis_invicta_logo_1786434562107.jpg';

interface FortisLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'hero';
  showText?: boolean;
  layout?: 'horizontal' | 'vertical';
  theme?: 'dark' | 'light' | 'gold';
  className?: string;
}

export const FortisLogo: React.FC<FortisLogoProps> = ({
  size = 'md',
  showText = true,
  layout = 'horizontal',
  theme = 'dark',
  className = ''
}) => {
  // Size dimensions
  const dimensions = {
    sm: { icon: 36, fontMain: 'text-sm', fontSub: 'text-[9px]' },
    md: { icon: 48, fontMain: 'text-lg', fontSub: 'text-[10px]' },
    lg: { icon: 72, fontMain: 'text-2xl', fontSub: 'text-xs' },
    xl: { icon: 96, fontMain: 'text-3xl', fontSub: 'text-sm' },
    hero: { icon: 120, fontMain: 'text-4xl', fontSub: 'text-base' }
  }[size];

  const textColorClass = theme === 'light' ? 'text-slate-900' : 'text-white';
  const subTextColorClass = theme === 'light' ? 'text-emerald-700 font-semibold' : 'text-amber-300 font-medium';

  return (
    <div
      className={`inline-flex items-center gap-3 ${
        layout === 'vertical' ? 'flex-col text-center' : 'flex-row'
      } ${className}`}
    >
      {/* Emblem 3D Render Image */}
      <div
        className="relative shrink-0 flex items-center justify-center rounded-2xl overflow-hidden border border-amber-500/40 shadow-xl bg-slate-900 p-0.5"
        style={{ width: dimensions.icon, height: dimensions.icon }}
      >
        <img
          src={fortisLogoImg}
          alt="Fortis Invicta Ltd Official Logo"
          className="w-full h-full object-cover rounded-xl"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Brand Typography */}
      {showText && (
        <div className={layout === 'vertical' ? 'text-center' : 'text-left'}>
          <div className="flex items-center gap-1.5 justify-center sm:justify-start">
            <span className={`font-black font-serif tracking-wider ${dimensions.fontMain} ${textColorClass}`}>
              FORTIS INVICTA
            </span>
            <span className="text-[10px] bg-gradient-to-r from-amber-400 to-amber-600 text-slate-950 font-extrabold px-1.5 py-0.5 rounded shadow-sm tracking-widest uppercase">
              LTD
            </span>
          </div>
          <p className={`${dimensions.fontSub} ${subTextColorClass} tracking-wide uppercase font-sans mt-0.5`}>
            Solar Power Systems & Project Financing
          </p>
        </div>
      )}
    </div>
  );
};
