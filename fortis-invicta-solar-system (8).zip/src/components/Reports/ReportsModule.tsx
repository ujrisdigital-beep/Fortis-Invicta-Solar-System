import React from 'react';
import { BarChart3, Download, FileSpreadsheet, TrendingUp, DollarSign, Users } from 'lucide-react';
import { Client, Currency, PaymentRecord } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface ReportsModuleProps {
  clients: Client[];
  payments: PaymentRecord[];
  currency: Currency;
  metrics: any;
}

export const ReportsModule: React.FC<ReportsModuleProps> = ({
  clients,
  payments,
  currency,
  metrics
}) => {
  const handleExportCSV = () => {
    const headers = ['Client Name', 'Segment', 'Package', 'Stage', 'Payment Status', 'Total Quoted GMD', 'Total Paid GMD'];
    const rows = clients.map((c) => [
      `"${c.fullName}"`,
      `"${c.clientSegment}"`,
      `"${c.packageId}"`,
      `"${c.projectStage}"`,
      `"${c.paymentStatus}"`,
      c.totalQuotedGMD,
      c.totalPaidGMD
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `fortis_invicta_solar_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 font-serif">Financial & Installation Reports</h1>
          <p className="text-xs text-slate-500">Revenue analytics, GTUCCU/NAGNMC remittance audit, and CSV exporter</p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 bg-[#1B4D3E] hover:bg-[#143B2F] text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-md"
        >
          <Download className="w-4 h-4 text-amber-300" />
          <span>Export Full CSV Audit Log</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-2">
          <span className="text-xs font-bold uppercase text-slate-500">Total Contract Value</span>
          <div className="text-2xl font-extrabold text-slate-900">
            {formatCurrency(metrics.totalQuotedGMD, currency)}
          </div>
          <p className="text-[11px] text-slate-500">Total pipeline across 8 stages</p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-2">
          <span className="text-xs font-bold uppercase text-slate-500">Ecobank Confirmed Collected</span>
          <div className="text-2xl font-extrabold text-emerald-800">
            {formatCurrency(metrics.totalCollectedGMD, currency)}
          </div>
          <p className="text-[11px] text-slate-500">Verified bank wires & teller deposits</p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-2">
          <span className="text-xs font-bold uppercase text-slate-500">Outstanding Balance</span>
          <div className="text-2xl font-extrabold text-rose-600">
            {formatCurrency(metrics.outstandingBalanceGMD, currency)}
          </div>
          <p className="text-[11px] text-slate-500">Pending installments & union deductions</p>
        </div>
      </div>
    </div>
  );
};
