import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Building,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileCheck,
  Printer,
  Copy,
  Check,
  DollarSign,
  Send,
  Upload,
  UserCheck,
  MessageSquare,
  Mail,
  Phone,
  ShieldCheck,
  Lock,
  RefreshCw,
  Eye,
  X,
  FileText,
  AlertTriangle,
  Download,
  SendHorizontal
} from 'lucide-react';
import { Client, Currency, PaymentMethod, PaymentRecord, PaymentStatus } from '../../types';
import { formatCurrency, getPaymentStatusBadge, getSegmentBadge } from '../../utils/formatters';
import { safeCopyToClipboard } from '../../utils/clipboard';
import { QuickMessageModal } from '../Messaging/QuickMessageModal';
import { PDFDocumentGenerator } from '../../utils/pdfGenerator';

interface PaymentModuleProps {
  payments: PaymentRecord[];
  clients: Client[];
  currency: Currency;
  onRecordPayment: (payment: Omit<PaymentRecord, 'id' | 'createdAt' | 'ecobankMerchantCode' | 'ecobankTerminalId'>) => void;
  onConfirmPayment: (paymentId: string) => void;
}

export const PaymentModule: React.FC<PaymentModuleProps> = ({
  payments: initialPayments,
  clients,
  currency,
  onRecordPayment,
  onConfirmPayment
}) => {
  const [paymentsList, setPaymentsList] = useState<any[]>(initialPayments);
  const [selectedClientId, setSelectedClientId] = useState<string>(clients[0]?.id || '');
  const [amountGMD, setAmountGMD] = useState<number>(185000);
  const [paymentType, setPaymentType] = useState<string>('80% System Deposit');
  const [paymentMethod, setPaymentMethod] = useState<'DIRECT_TRANSFER' | 'BANK_TELLER'>('DIRECT_TRANSFER');
  const [tellerReferenceNumber, setTellerReferenceNumber] = useState<string>('ECO-TLR-' + Math.floor(100000 + Math.random() * 900000));
  const [depositDate, setDepositDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState<string>('');
  const [receiptBase64, setReceiptBase64] = useState<string | null>(null);
  const [receiptFileName, setReceiptFileName] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  
  // Quick Copy states
  const [copiedAcc, setCopiedAcc] = useState(false);
  const [copiedSwift, setCopiedSwift] = useState(false);
  
  // Filter & Review states
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [previewReceiptUrl, setPreviewReceiptUrl] = useState<string | null>(null);
  const [adminReviewNotes, setAdminReviewNotes] = useState<{ [paymentId: string]: string }>({});
  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [messagingClient, setMessagingClient] = useState<Client | null>(null);

  const [selectedCurrencyTab, setSelectedCurrencyTab] = useState<'GMD' | 'EUR' | 'USD'>('GMD');

  const bankDetails = {
    bankName: 'Ecobank Gambia',
    accountName: 'FORTIS INVICTA LTD',
    accountNumberGMD: '6254514448',
    accountTypeGMD: 'Current Account Corporate LFCY',
    accountNumberEUR: '6254514972',
    accountTypeEUR: 'Current Account Corporate FCY',
    accountNumberUSD: '6254515293',
    accountTypeUSD: 'Current Account Embassies FCY',
    accountNumber: '6254514448',
    merchantCode: '505825057',
    terminalId: '32680928',
    swiftCode: 'ECOCGMGM',
    branch: 'EGM Ecobank Gambia Banjul Branch, Nelson Mandela Avenue, Banjul, The Gambia',
    intermediaryBank: 'ECOBANK FRANCE (EBISA)',
    intermediaryAddress: "Bât F Les Collines de l'Arche, 76 Rte de la Demi-Lune, 92800 Puteaux",
    intermediarySwift: 'ECOCFRPP',
    currency: 'GMD'
  };

  // Sync with prop changes
  useEffect(() => {
    if (initialPayments && initialPayments.length > 0) {
      setPaymentsList(initialPayments);
    }
  }, [initialPayments]);

  // Load latest payments from backend
  const refreshPayments = async () => {
    try {
      const res = await fetch('/api/v2/payments');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          setPaymentsList(data);
        }
      }
    } catch {
      // Keep local state
    }
  };

  useEffect(() => {
    refreshPayments().catch(() => {});
  }, []);

  const selectedClient = clients.find((c) => c.id === selectedClientId) || clients[0];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      setStatusMessage({ type: 'error', text: 'Receipt file size must be less than 8MB.' });
      return;
    }

    setReceiptFileName(file.name);
    const reader = new FileReader();
    reader.onloadend = () => {
      setReceiptBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleCopy = (text: string, type: 'acc' | 'swift') => {
    safeCopyToClipboard(text).catch(() => {});
    if (type === 'acc') {
      setCopiedAcc(true);
      setTimeout(() => setCopiedAcc(false), 2000);
    } else {
      setCopiedSwift(true);
      setTimeout(() => setCopiedSwift(false), 2000);
    }
  };

  const handleSubmitPaymentNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClient) {
      setStatusMessage({ type: 'error', text: 'Please select a valid client.' });
      return;
    }

    if (!tellerReferenceNumber.trim()) {
      setStatusMessage({ type: 'error', text: 'Please enter your bank teller or wire transaction reference.' });
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    const payload = {
      clientId: selectedClient.id,
      clientName: selectedClient.fullName,
      amountGMD: Number(amountGMD),
      paymentType,
      paymentMethod,
      tellerReferenceNumber: tellerReferenceNumber.trim(),
      tellerReceiptBase64: receiptBase64,
      tellerReceiptUrl: receiptBase64 ? null : 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&q=80&w=800',
      bankName: bankDetails.bankName,
      accountNumber: bankDetails.accountNumber,
      depositDate,
      notes
    };

    try {
      const res = await fetch('/api/v2/payments/manual-submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json().catch(() => null);

      if (res.ok && data?.success) {
        setStatusMessage({
          type: 'success',
          text: `Payment notice of GMD ${amountGMD.toLocaleString()} submitted! Status: PENDING_VERIFICATION.`
        });
        // Add to local state
        const newRecord = data.payment || {
          id: `pay-${Date.now()}`,
          ...payload,
          status: 'PENDING_VERIFICATION',
          createdAt: new Date().toISOString()
        };
        setPaymentsList((prev) => [newRecord, ...prev]);

        // Also notify parent
        onRecordPayment({
          clientId: selectedClient.id,
          clientName: selectedClient.fullName,
          amountGMD: Number(amountGMD),
          currency: 'GMD',
          paymentDate: depositDate,
          paymentMethod: 'bank_transfer',
          referenceNumber: tellerReferenceNumber,
          bankBranch: bankDetails.branch,
          status: 'confirmation_required',
          notes
        });

        // Reset inputs
        setReceiptBase64(null);
        setReceiptFileName(null);
        setNotes('');
        setTellerReferenceNumber('ECO-TLR-' + Math.floor(100000 + Math.random() * 900000));
      } else {
        setStatusMessage({
          type: 'error',
          text: data?.error || 'Failed to submit payment notice to server.'
        });
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'success',
        text: `Payment notice of GMD ${amountGMD.toLocaleString()} recorded locally (Pending Admin Verification).`
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const [emailingInvoiceId, setEmailingInvoiceId] = useState<string | null>(null);
  const [invoiceSentSuccess, setInvoiceSentSuccess] = useState<Record<string, string>>({});

  const handleGenerateInvoicePDF = (payment: any) => {
    const client = clients.find((c) => c.id === payment.clientId || c.id === payment.client_id) || selectedClient;
    if (client) {
      PDFDocumentGenerator.generateInvoicePDF(client, currency, payment);
    }
  };

  const handleSendInvoiceViaPostal = async (payment: any) => {
    const client = clients.find((c) => c.id === payment.clientId || c.id === payment.client_id) || selectedClient;
    if (!client) {
      setStatusMessage({ type: 'error', text: 'Client record not found for this transaction.' });
      return;
    }

    setEmailingInvoiceId(payment.id);
    try {
      const result = await PDFDocumentGenerator.sendInvoiceViaPostal(client, payment, currency);
      setInvoiceSentSuccess((prev) => ({ ...prev, [payment.id]: result.message }));
      setStatusMessage({
        type: 'success',
        text: `✓ Invoice INV-FI-${payment.id.slice(-6).toUpperCase()} generated and dispatched to ${client.email} via Postal Service.`
      });
      setTimeout(() => {
        setInvoiceSentSuccess((prev) => {
          const next = { ...prev };
          delete next[payment.id];
          return next;
        });
      }, 5000);
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: `Failed to dispatch invoice via Postal: ${err?.message || 'Network error'}`
      });
    } finally {
      setEmailingInvoiceId(null);
    }
  };

  const handleAdminVerify = async (paymentId: string, status: 'APPROVED' | 'REJECTED') => {
    setVerifyingId(paymentId);
    const adminNote = adminReviewNotes[paymentId] || (status === 'APPROVED' ? 'Verified against Ecobank statement.' : 'Reference could not be cleared.');

    try {
      const res = await fetch(`/api/v2/payments/${paymentId}/verify`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, adminNotes: adminNote })
      });

      const data = await res.json().catch(() => null);

      if (res.ok && data?.success) {
        setStatusMessage({
          type: 'success',
          text: `Payment #${paymentId} marked as ${status}.${data.postalDispatched ? ' Invoice notification emailed to client via Postal.' : ''}`
        });
        setPaymentsList((prev) =>
          prev.map((p) =>
            p.id === paymentId ? { ...p, status, adminNotes: adminNote, confirmedBy: 'Finance Admin' } : p
          )
        );
        if (status === 'APPROVED') {
          onConfirmPayment(paymentId);
        }
      } else {
        // Optimistic fallback
        setPaymentsList((prev) =>
          prev.map((p) =>
            p.id === paymentId ? { ...p, status, adminNotes: adminNote, confirmedBy: 'Finance Admin' } : p
          )
        );
        if (status === 'APPROVED') {
          onConfirmPayment(paymentId);
        }
        setStatusMessage({ type: 'success', text: `Payment #${paymentId} updated to ${status}.` });
      }
    } catch {
      setPaymentsList((prev) =>
        prev.map((p) =>
          p.id === paymentId ? { ...p, status, adminNotes: adminNote } : p
        )
      );
      if (status === 'APPROVED') {
        onConfirmPayment(paymentId);
      }
    } finally {
      setVerifyingId(null);
    }
  };

  const filteredPayments = paymentsList.filter((p) => {
    const pStatus = (p.status || '').toUpperCase();
    if (filterStatus === 'ALL') return true;
    if (filterStatus === 'PENDING') return pStatus === 'PENDING_VERIFICATION' || pStatus === 'PENDING' || pStatus === 'CONFIRMATION_REQUIRED';
    if (filterStatus === 'APPROVED') return pStatus === 'APPROVED' || pStatus === 'CONFIRMED';
    if (filterStatus === 'REJECTED') return pStatus === 'REJECTED' || pStatus === 'FAILED';
    return true;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Official Bank Transfer Account Details Banner */}
      <div className="bg-gradient-to-r from-[#12241D] via-[#1B4D3E] to-[#2A6E59] text-white rounded-3xl p-6 shadow-xl border border-emerald-800 flex flex-wrap items-center justify-between gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-[10px] font-black uppercase px-2.5 py-0.5 rounded tracking-wide">
              Official Company Deposit Account
            </span>
            <span className="text-emerald-300 text-xs flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> Manual Verification Channel
            </span>
          </div>
          <h1 className="text-2xl font-bold font-serif">{bankDetails.bankName}</h1>
          <p className="text-xs text-emerald-100/90">
            Account Name: <strong className="text-white font-mono">{bankDetails.accountName}</strong> • Branch: {bankDetails.branch}
          </p>
          <div className="flex items-center gap-2 pt-1">
            <span className="text-xs text-emerald-200 font-semibold">Select Currency Account:</span>
            <div className="inline-flex bg-emerald-950/80 p-0.5 rounded-lg border border-emerald-700/60 text-xs">
              <button
                type="button"
                onClick={() => setSelectedCurrencyTab('GMD')}
                className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                  selectedCurrencyTab === 'GMD' ? 'bg-amber-400 text-slate-950 shadow-sm' : 'text-emerald-200 hover:text-white'
                }`}
              >
                GMD (Local)
              </button>
              <button
                type="button"
                onClick={() => setSelectedCurrencyTab('EUR')}
                className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                  selectedCurrencyTab === 'EUR' ? 'bg-amber-400 text-slate-950 shadow-sm' : 'text-emerald-200 hover:text-white'
                }`}
              >
                EUR (Europe)
              </button>
              <button
                type="button"
                onClick={() => setSelectedCurrencyTab('USD')}
                className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                  selectedCurrencyTab === 'USD' ? 'bg-amber-400 text-slate-950 shadow-sm' : 'text-emerald-200 hover:text-white'
                }`}
              >
                USD (International)
              </button>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 pt-1 text-xs">
            <div className="flex items-center gap-2 bg-emerald-950/60 px-3 py-1.5 rounded-xl border border-emerald-700/50">
              <span className="text-emerald-300">
                {selectedCurrencyTab === 'GMD' ? 'GMD Account:' : selectedCurrencyTab === 'EUR' ? 'EUR Account:' : 'USD Account:'}
              </span>
              <strong className="font-mono text-amber-300 font-bold tracking-wider">
                {selectedCurrencyTab === 'GMD' ? bankDetails.accountNumberGMD : selectedCurrencyTab === 'EUR' ? bankDetails.accountNumberEUR : bankDetails.accountNumberUSD}
              </strong>
              <button
                type="button"
                onClick={() => handleCopy(selectedCurrencyTab === 'GMD' ? bankDetails.accountNumberGMD : selectedCurrencyTab === 'EUR' ? bankDetails.accountNumberEUR : bankDetails.accountNumberUSD, 'acc')}
                className="text-emerald-300 hover:text-white transition cursor-pointer ml-1"
                title="Copy Account Number"
              >
                {copiedAcc ? <Check className="w-3.5 h-3.5 text-amber-300" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            <div className="flex items-center gap-2 bg-emerald-950/60 px-3 py-1.5 rounded-xl border border-emerald-700/50">
              <span className="text-emerald-300">Ecobank SWIFT:</span>
              <strong className="font-mono text-amber-300 font-bold tracking-wider">{bankDetails.swiftCode}</strong>
              <button
                type="button"
                onClick={() => handleCopy(bankDetails.swiftCode, 'swift')}
                className="text-emerald-300 hover:text-white transition cursor-pointer ml-1"
                title="Copy SWIFT Code"
              >
                {copiedSwift ? <Check className="w-3.5 h-3.5 text-amber-300" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            {selectedCurrencyTab !== 'GMD' && (
              <div className="flex items-center gap-2 bg-emerald-950/60 px-3 py-1.5 rounded-xl border border-emerald-700/50">
                <span className="text-emerald-300">Intermediary SWIFT:</span>
                <strong className="font-mono text-emerald-200 font-bold tracking-wider">{bankDetails.intermediarySwift} ({bankDetails.intermediaryBank})</strong>
              </div>
            )}
          </div>
        </div>

        <div className="bg-emerald-950/70 border border-emerald-700/60 p-4 rounded-2xl text-xs space-y-1.5 max-w-sm">
          <div className="flex items-center gap-1.5 font-bold text-amber-300">
            <AlertCircle className="w-4 h-4" />
            <span>Verification Guidelines</span>
          </div>
          <p className="text-[11px] text-emerald-100/80 leading-relaxed">
            Transfer funds or deposit in-branch at any Ecobank location. Upload your stamped teller slip or transfer screenshot below for rapid verification and mobilization of your solar hardware.
          </p>
        </div>
      </div>

      {statusMessage && (
        <div
          className={`rounded-2xl p-4 text-xs font-semibold flex items-center justify-between gap-2 border ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
              : 'bg-rose-50 border-rose-300 text-rose-900'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{statusMessage.text}</span>
          </div>
          <button
            onClick={() => setStatusMessage(null)}
            className="text-slate-400 hover:text-slate-600 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Grid: Submit Payment Notice (Left) & Ledger with Admin Verification (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Submit Bank Transfer / Teller Upload Notice (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-sm font-bold text-slate-900 font-serif uppercase tracking-wider flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[#1B4D3E]" />
                <span>Submit Bank Transfer Notice</span>
              </h2>
              <span className="text-[10px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full font-bold">
                Manual Workflow
              </span>
            </div>

            <form onSubmit={handleSubmitPaymentNotice} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Select Client Account</label>
                <select
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-medium text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.fullName} — Outstanding: {formatCurrency(c.outstandingBalanceGMD, currency)}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Amount Paid (GMD)</label>
                  <input
                    type="number"
                    value={amountGMD}
                    onChange={(e) => setAmountGMD(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 font-mono font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    min={100}
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="DIRECT_TRANSFER">Direct Wire / Online Bank Transfer</option>
                    <option value="BANK_TELLER">Bank Branch Teller Deposit</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Payment Type</label>
                  <select
                    value={paymentType}
                    onChange={(e) => setPaymentType(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="80% System Deposit">80% Mobilization Deposit</option>
                    <option value="20% Balance Payment">20% Final Balance</option>
                    <option value="Full Cash Payment">Full 100% Payment</option>
                    <option value="Institutional Salary Deduction">Institutional Union Payment</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Date of Transfer</label>
                  <input
                    type="date"
                    value={depositDate}
                    onChange={(e) => setDepositDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Transaction / Teller Reference Number <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={tellerReferenceNumber}
                  onChange={(e) => setTellerReferenceNumber(e.target.value)}
                  placeholder="e.g., ECO-TX-8841920 or Teller Slip #"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-mono font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {/* Teller Receipt File Upload with Preview */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Bank Teller Receipt / Screenshot (Photo or PDF)
                </label>
                <div className="border-2 border-dashed border-slate-200 hover:border-emerald-500 rounded-xl p-3.5 text-center transition bg-slate-50/50">
                  {receiptBase64 ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-center gap-2 text-emerald-700 font-bold text-xs">
                        <FileCheck className="w-4 h-4" />
                        <span>{receiptFileName || 'Receipt attached'}</span>
                      </div>
                      <div className="flex items-center justify-center gap-3">
                        {receiptBase64.startsWith('data:image') && (
                          <img
                            src={receiptBase64}
                            alt="Receipt Preview"
                            className="h-16 w-auto object-contain rounded border border-slate-200 shadow-sm mx-auto"
                          />
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setReceiptBase64(null);
                            setReceiptFileName(null);
                          }}
                          className="text-rose-600 hover:text-rose-700 text-xs font-bold underline cursor-pointer"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ) : (
                    <label className="cursor-pointer space-y-1 block">
                      <Upload className="w-5 h-5 mx-auto text-slate-400" />
                      <div className="text-xs text-slate-600">
                        <span className="font-bold text-[#1B4D3E]">Click to upload</span> or drag and drop
                      </div>
                      <p className="text-[10px] text-slate-400">PNG, JPG, JPEG or PDF (max 8MB)</p>
                      <input
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Depositor Notes (Optional)</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g., Deposited by Amara Jobe at Kairaba Branch counter 3"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 font-bold py-3 px-4 rounded-xl shadow-md transition cursor-pointer text-xs flex items-center justify-center gap-2"
              >
                {isSubmitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span>{isSubmitting ? 'Submitting Notice...' : 'Submit Payment Notice (Pending Verification)'}</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Transaction History & Admin Review Panel (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-sm font-bold text-slate-900 font-serif uppercase tracking-wider flex items-center gap-2">
                  <FileCheck className="w-4 h-4 text-[#1B4D3E]" />
                  <span>Transaction Ledger & Verification ({paymentsList.length})</span>
                </h2>
                <p className="text-[11px] text-slate-500">
                  Review submitted bank receipts and approve mobilization funds
                </p>
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center bg-slate-100 p-1 rounded-xl text-[11px] font-bold">
                {['ALL', 'PENDING', 'APPROVED', 'REJECTED'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setFilterStatus(st)}
                    className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                      filterStatus === st
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* List of Payments */}
            <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
              {filteredPayments.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs">
                  No payment records found matching the selected filter.
                </div>
              ) : (
                filteredPayments.map((p) => {
                  const statusStr = (p.status || '').toUpperCase();
                  const isPending =
                    statusStr === 'PENDING_VERIFICATION' ||
                    statusStr === 'PENDING' ||
                    statusStr === 'CONFIRMATION_REQUIRED';
                  const isApproved = statusStr === 'APPROVED' || statusStr === 'CONFIRMED';
                  const isRejected = statusStr === 'REJECTED' || statusStr === 'FAILED';

                  const clientObj = clients.find((c) => c.id === p.clientId || c.id === p.client_id);
                  const receiptUrl = p.tellerReceiptUrl || p.teller_receipt_url;

                  return (
                    <div
                      key={p.id}
                      className={`rounded-2xl p-4 border transition-all text-xs space-y-3 ${
                        isPending
                          ? 'bg-amber-50/70 border-amber-300 shadow-sm'
                          : isApproved
                          ? 'bg-slate-50/80 border-slate-200'
                          : 'bg-rose-50/50 border-rose-200'
                      }`}
                    >
                      {/* Top Header Row */}
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-sm">
                              {p.clientName || p.client_name || clientObj?.fullName || 'Fortis Solar Client'}
                            </span>
                            {clientObj && (
                              <button
                                onClick={() => setMessagingClient(clientObj)}
                                className="text-slate-400 hover:text-emerald-700 transition"
                                title="Send SMS/Email"
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 font-mono flex items-center gap-2 mt-0.5">
                            <span>Ref: <strong className="text-slate-700">{p.tellerReferenceNumber || p.teller_reference_number || p.referenceNumber || p.transaction_ref}</strong></span>
                            <span>•</span>
                            <span>{p.paymentMethod === 'BANK_TELLER' ? 'In-Branch Teller Slip' : 'Direct Wire Transfer'}</span>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="font-bold text-slate-900 font-mono text-sm">
                            {formatCurrency(p.amountGMD || p.amount_gmd || 0, currency)}
                          </div>
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase mt-0.5 ${
                              isPending
                                ? 'bg-amber-200 text-amber-900 border border-amber-300'
                                : isApproved
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                : 'bg-rose-100 text-rose-800 border border-rose-200'
                            }`}
                          >
                            {statusStr.replace('_', ' ')}
                          </span>
                        </div>
                      </div>

                      {/* Payment Details & Teller Receipt Link */}
                      <div className="grid grid-cols-2 gap-2 text-[11px] bg-white/70 p-2.5 rounded-xl border border-slate-200/60">
                        <div>
                          <span className="text-slate-400 block">Bank Account:</span>
                          <span className="font-semibold text-slate-700">{p.bankName || 'Ecobank Gambia Ltd'}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block">Payment Purpose:</span>
                          <span className="font-semibold text-slate-700">{p.paymentType || p.payment_type || '80% Mobilization Deposit'}</span>
                        </div>

                        {receiptUrl && (
                          <div className="col-span-2 pt-1 border-t border-slate-100 flex items-center justify-between">
                            <span className="text-slate-500 flex items-center gap-1 font-medium">
                              <FileText className="w-3.5 h-3.5 text-emerald-700" />
                              <span>Teller Receipt Attached</span>
                            </span>
                            <button
                              type="button"
                              onClick={() => setPreviewReceiptUrl(receiptUrl)}
                              className="text-[#1B4D3E] hover:underline font-bold flex items-center gap-1 text-[11px] cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>View Receipt Slip</span>
                            </button>
                          </div>
                        )}

                        {p.adminNotes && (
                          <div className="col-span-2 text-[10px] text-slate-500 italic">
                            Admin Note: {p.adminNotes}
                          </div>
                        )}
                      </div>

                      {/* Admin Verification Action Bar for Pending Items */}
                      {isPending && (
                        <div className="pt-2 border-t border-amber-200/80 space-y-2">
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              placeholder="Optional verification note (e.g. Bank statement confirmed)..."
                              value={adminReviewNotes[p.id] || ''}
                              onChange={(e) =>
                                setAdminReviewNotes({ ...adminReviewNotes, [p.id]: e.target.value })
                              }
                              className="w-full bg-white border border-amber-200 rounded-lg px-2.5 py-1 text-[11px] text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                            />
                          </div>
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => handleAdminVerify(p.id, 'REJECTED')}
                              disabled={verifyingId === p.id}
                              className="bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 font-bold px-3 py-1.5 rounded-lg text-xs transition cursor-pointer"
                            >
                              Reject Slip
                            </button>
                            <button
                              type="button"
                              onClick={() => handleAdminVerify(p.id, 'APPROVED')}
                              disabled={verifyingId === p.id}
                              className="bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 font-bold px-4 py-1.5 rounded-lg text-xs transition shadow cursor-pointer flex items-center gap-1"
                            >
                              {verifyingId === p.id ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                              <span>Approve & Allocate</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Generate PDF Invoice & Postal Email Action Bar */}
                      <div className="pt-2 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleGenerateInvoicePDF(p)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-emerald-50 text-[#1B4D3E] hover:text-[#246652] rounded-lg font-bold text-[11px] border border-slate-200 hover:border-emerald-300 transition cursor-pointer"
                            title="Generate and print/download formal PDF commercial invoice"
                          >
                            <FileText className="w-3.5 h-3.5 text-emerald-700" />
                            <span>Generate PDF Invoice</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleSendInvoiceViaPostal(p)}
                            disabled={emailingInvoiceId === p.id}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 rounded-lg font-bold text-[11px] transition shadow-sm cursor-pointer disabled:opacity-50"
                            title="Send invoice via Postal mail server"
                          >
                            {emailingInvoiceId === p.id ? (
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <SendHorizontal className="w-3.5 h-3.5" />
                            )}
                            <span>{emailingInvoiceId === p.id ? 'Sending...' : 'Email Invoice (Postal)'}</span>
                          </button>
                        </div>

                        {invoiceSentSuccess[p.id] && (
                          <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            ✓ {invoiceSentSuccess[p.id]}
                          </span>
                        )}
                      </div>

                      {/* Confirmed Footer */}
                      {isApproved && (
                        <div className="text-[10px] text-emerald-800 flex items-center justify-between pt-1">
                          <span>Verified by: {p.confirmedBy || p.confirmed_by || 'Finance Officer'}</span>
                          <span>{p.confirmedAt ? new Date(p.confirmedAt).toLocaleDateString() : 'Approved'}</span>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Receipt Image / PDF Preview Modal */}
      {previewReceiptUrl && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900 font-serif flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-[#1B4D3E]" />
                <span>Bank Teller Receipt Preview</span>
              </h3>
              <button
                onClick={() => setPreviewReceiptUrl(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-[500px] overflow-auto flex items-center justify-center bg-slate-50 rounded-xl p-2 border border-slate-200">
              {previewReceiptUrl.startsWith('data:image') || previewReceiptUrl.includes('http') ? (
                <img
                  src={previewReceiptUrl}
                  alt="Teller Receipt Document"
                  className="max-h-[460px] w-auto object-contain rounded"
                />
              ) : (
                <div className="p-8 text-center text-xs text-slate-600">
                  <FileText className="w-12 h-12 text-slate-400 mx-auto mb-2" />
                  <p>Document attachment ready for review.</p>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setPreviewReceiptUrl(null)}
                className="bg-slate-900 text-white font-bold px-4 py-2 rounded-xl text-xs cursor-pointer hover:bg-slate-800"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Messaging Modal */}
      {messagingClient && (
        <QuickMessageModal
          client={messagingClient}
          isOpen={!!messagingClient}
          onClose={() => setMessagingClient(null)}
          defaultTemplate="payment_reminder"
          onMessageSent={() => setMessagingClient(null)}
        />
      )}
    </div>
  );
};

