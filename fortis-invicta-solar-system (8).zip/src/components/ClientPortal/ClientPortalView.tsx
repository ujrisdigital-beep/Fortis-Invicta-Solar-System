import React, { useState } from 'react';
import {
  UserCheck,
  Search,
  ShieldCheck,
  CreditCard,
  Upload,
  CheckCircle2,
  Printer,
  FileText,
  FileCheck,
  FolderLock,
  FileSpreadsheet,
  Download,
  Eye,
  ShieldAlert,
  Clock,
  Check,
  AlertCircle
} from 'lucide-react';
import { FortisLogo } from '../FortisLogo';
import { Client, Currency, PaymentRecord } from '../../types';
import { StorageService } from '../../services/storage';
import { SOLAR_PACKAGES } from '../../data/mockData';
import { formatCurrency, getStageLabel, getStageColor } from '../../utils/formatters';
import { PDFDocumentGenerator } from '../../utils/pdfGenerator';
import { useAuth } from '../../services/authContext';

interface ClientPortalViewProps {
  clients: Client[];
  payments: PaymentRecord[];
  currency: Currency;
  onRecordPayment: (payment: any) => void;
}

export const ClientPortalView: React.FC<ClientPortalViewProps> = ({
  clients,
  payments,
  currency,
  onRecordPayment
}) => {
  const { user, isAuthenticated } = useAuth();
  
  // If the authenticated user is a client, match to their profile or first client
  const clientMatch = isAuthenticated && user?.role === 'client'
    ? clients.find((c) => c.email?.toLowerCase() === user.email?.toLowerCase()) || clients[0]
    : clients[0] || null;

  const [queryId, setQueryId] = useState<string>(clientMatch?.id || 'cli-001');
  const [activeClient, setActiveClient] = useState<Client | null>(clientMatch);

  const [tellerRef, setTellerRef] = useState<string>('');
  const [tellerAmount, setTellerAmount] = useState<number>(activeClient?.totalPaidGMD || 50000);
  const [activeFolderTab, setActiveFolderTab] = useState<'documents' | 'payments' | 'specs'>('documents');
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    const match = clients.find(
      (c) =>
        c.id.toLowerCase() === queryId.trim().toLowerCase() ||
        c.email.toLowerCase() === queryId.trim().toLowerCase() ||
        c.fullName.toLowerCase().includes(queryId.trim().toLowerCase())
    );
    if (match) {
      setActiveClient(match);
    } else {
      alert(`Client reference ${queryId} not found.`);
    }
  };

  const handleTellerUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeClient) return;

    onRecordPayment({
      clientId: activeClient.id,
      clientName: activeClient.fullName,
      amountGMD: tellerAmount,
      currency: 'GMD',
      paymentDate: new Date().toISOString().split('T')[0],
      paymentMethod: 'teller_deposit',
      referenceNumber: tellerRef || 'ECO-TLR-' + Math.floor(100000 + Math.random() * 900000),
      bankBranch: 'Ecobank Gambia Ltd',
      status: 'confirmation_required',
      notes: 'Submitted via Verified Client Portal upload.'
    });

    setUploadSuccess('Bank teller deposit slip successfully submitted to Finance for reconciliation.');
    setTellerRef('');
    setTimeout(() => setUploadSuccess(null), 5000);
  };

  const clientPayments = activeClient ? payments.filter((p) => p.clientId === activeClient.id) : [];

  return (
    <div className="space-y-6 pb-12">
      {/* Client Gateway Top Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-emerald-500/30 shadow-xl relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-wrap items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-amber-500/20">
              <FolderLock className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold font-serif text-white">
                  {isAuthenticated && user?.role === 'client'
                    ? `Welcome, ${user.fullName}`
                    : 'Client Private Solar Portal & Document Vault'}
                </h1>
                <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full border border-emerald-500/40">
                  PII Vault Isolated
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Access your solar quotation, field inspection reports, warranty certificates, and Ecobank direct payment ledger.
              </p>
            </div>
          </div>

          {/* If Super Admin or testing, allow quick lookup, otherwise locked to current user */}
          {(!isAuthenticated || user?.role !== 'client') && (
            <form onSubmit={handleLookup} className="flex gap-2 text-xs">
              <input
                type="text"
                placeholder="Lookup Client ID..."
                value={queryId}
                onChange={(e) => setQueryId(e.target.value)}
                className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 font-semibold focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold px-4 py-2 rounded-xl transition cursor-pointer shadow-md"
              >
                View Vault
              </button>
            </form>
          )}
        </div>
      </div>

      {activeClient ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Column 1 & 2: Project Overview, Stage Progress, & Personal Document Vault */}
          <div className="lg:col-span-2 space-y-6">
            {/* Project Stage Tracker Card */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Active System Record</span>
                  <h2 className="text-lg font-bold text-slate-900 font-serif">{activeClient.fullName}</h2>
                  <p className="text-xs text-slate-500">{activeClient.address} • {activeClient.propertyDetails?.region || 'Greater Banjul Area'}</p>
                </div>
                <div className="text-right">
                  <span className={`px-3 py-1 rounded-full text-xs font-extrabold ${getStageColor(activeClient.projectStage)}`}>
                    {getStageLabel(activeClient.projectStage)}
                  </span>
                  <p className="text-[10px] text-slate-400 mt-1 font-mono">Ref: {activeClient.id}</p>
                </div>
              </div>

              {/* Financial Snapshot */}
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
                  <span className="text-[10px] text-slate-500 uppercase font-bold block">Total Quoted</span>
                  <span className="text-sm font-extrabold text-slate-900">{formatCurrency(activeClient.totalQuotedGMD, currency)}</span>
                </div>
                <div className="bg-emerald-50/60 p-3 rounded-2xl border border-emerald-100">
                  <span className="text-[10px] text-emerald-700 uppercase font-bold block">Verified Paid</span>
                  <span className="text-sm font-extrabold text-emerald-700">{formatCurrency(activeClient.totalPaidGMD, currency)}</span>
                </div>
                <div className="bg-amber-50/60 p-3 rounded-2xl border border-amber-100">
                  <span className="text-[10px] text-amber-700 uppercase font-bold block">Balance Due</span>
                  <span className="text-sm font-extrabold text-amber-700">{formatCurrency(activeClient.outstandingBalanceGMD, currency)}</span>
                </div>
              </div>

              {/* Official Downloadable Documents */}
              <div className="bg-slate-900 text-white p-4 rounded-2xl border border-emerald-800/50 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Printer className="w-4 h-4 text-amber-400" />
                    Formal PDF Certificates & Documents
                  </span>
                  <span className="text-[10px] text-slate-400">Cryptographically Tagged</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <button
                    onClick={() => PDFDocumentGenerator.generateQuotationPDF(activeClient, currency)}
                    className="bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold p-2.5 rounded-xl flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer transition shadow-sm"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Quotation</span>
                  </button>
                  <button
                    onClick={() => PDFDocumentGenerator.generateInvoicePDF(activeClient, currency)}
                    className="bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold p-2.5 rounded-xl flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer transition shadow-sm"
                  >
                    <FileCheck className="w-3.5 h-3.5" />
                    <span>Invoice</span>
                  </button>
                  <button
                    onClick={() => {
                      const lastConfirmed = clientPayments.find((p) => p.status === 'confirmed') || clientPayments[0];
                      if (lastConfirmed) {
                        PDFDocumentGenerator.generateReceiptPDF(activeClient, lastConfirmed, currency);
                      } else {
                        alert('No confirmed payment on record yet.');
                      }
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-emerald-300 font-bold p-2.5 rounded-xl flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer transition shadow-sm"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Receipt</span>
                  </button>
                  <button
                    onClick={() => PDFDocumentGenerator.generateAssessmentPDF(activeClient, undefined, currency)}
                    className="bg-slate-800 hover:bg-slate-700 text-indigo-300 font-bold p-2.5 rounded-xl flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer transition shadow-sm"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Survey</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Folder Vault Navigation Tabs */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
              <div className="flex border-b border-slate-100 gap-2">
                <button
                  onClick={() => setActiveFolderTab('documents')}
                  className={`pb-2 px-3 text-xs font-bold transition border-b-2 cursor-pointer ${
                    activeFolderTab === 'documents'
                      ? 'border-amber-500 text-amber-600'
                      : 'border-transparent text-slate-400 hover:text-slate-700'
                  }`}
                >
                  Project Folders & Assets ({activeClient.multimedia?.length || 3})
                </button>
                <button
                  onClick={() => setActiveFolderTab('payments')}
                  className={`pb-2 px-3 text-xs font-bold transition border-b-2 cursor-pointer ${
                    activeFolderTab === 'payments'
                      ? 'border-amber-500 text-amber-600'
                      : 'border-transparent text-slate-400 hover:text-slate-700'
                  }`}
                >
                  Payment History ({clientPayments.length})
                </button>
                <button
                  onClick={() => setActiveFolderTab('specs')}
                  className={`pb-2 px-3 text-xs font-bold transition border-b-2 cursor-pointer ${
                    activeFolderTab === 'specs'
                      ? 'border-amber-500 text-amber-600'
                      : 'border-transparent text-slate-400 hover:text-slate-700'
                  }`}
                >
                  Solar Hardware Specifications
                </button>
              </div>

              {/* Tab 1: Documents & Vault Files */}
              {activeFolderTab === 'documents' && (
                <div className="space-y-3">
                  <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center font-bold">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">Signed Solar Procurement Agreement</p>
                        <p className="text-[10px] text-slate-400">PDF Document • Formal 5-Year Warranty Guarantee</p>
                      </div>
                    </div>
                    <button
                      onClick={() => PDFDocumentGenerator.generateQuotationPDF(activeClient, currency)}
                      className="text-amber-600 hover:underline font-bold text-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-600 flex items-center justify-center font-bold">
                        <FileSpreadsheet className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">Engineering Roof & Electrical Survey Report</p>
                        <p className="text-[10px] text-slate-400">Completed by Fortis Field Inspection Team</p>
                      </div>
                    </div>
                    <button
                      onClick={() => PDFDocumentGenerator.generateAssessmentPDF(activeClient, undefined, currency)}
                      className="text-cyan-600 hover:underline font-bold text-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center font-bold">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">Ecobank Merchant Direct Settlement Notice</p>
                        <p className="text-[10px] text-slate-400">Account: 10100582505701 • Verified Bank Channel</p>
                      </div>
                    </div>
                    <span className="text-emerald-700 font-bold text-[11px] bg-emerald-100 px-2 py-0.5 rounded-full">
                      Verified
                    </span>
                  </div>
                </div>
              )}

              {/* Tab 2: Payment History */}
              {activeFolderTab === 'payments' && (
                <div className="space-y-2 text-xs">
                  {clientPayments.length === 0 ? (
                    <p className="text-slate-400 text-center py-4">No payment transactions on record yet.</p>
                  ) : (
                    clientPayments.map((p) => (
                      <div key={p.id} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
                        <div>
                          <p className="font-bold text-slate-900">{formatCurrency(p.amountGMD, currency)}</p>
                          <p className="text-[10px] text-slate-400 font-mono">Ref: {p.referenceNumber} • {p.paymentDate}</p>
                        </div>
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          p.status === 'confirmed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {p.status.toUpperCase()}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Tab 3: Hardware Specifications */}
              {activeFolderTab === 'specs' && (() => {
                const pkg = SOLAR_PACKAGES.find((p) => p.id === activeClient.packageId) || SOLAR_PACKAGES[0];
                return (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Solar PV Array</span>
                      <span className="font-bold text-slate-800">{pkg.solarAssets?.solarPanels || 'Tier 1 Mono-PERC Panels'}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Hybrid Inverter Unit</span>
                      <span className="font-bold text-slate-800">{pkg.solarAssets?.inverter || 'Smart Hybrid Inverter (Pure Sine)'}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Lithium Battery Bank</span>
                      <span className="font-bold text-slate-800">{pkg.solarAssets?.batteryBank || 'LiFePO4 Deep Cycle Bank'}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Protection Switchgear</span>
                      <span className="font-bold text-slate-800">{pkg.solarAssets?.protectionSwitchgear || 'SPD Surge Protection & DC Breakers'}</span>
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>

          {/* Column 3: Ecobank Direct Instructions & Upload Deposit Slip */}
          <div className="space-y-6">
            {/* Upload Teller Slip Form */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
              <h3 className="font-bold text-slate-900 font-serif text-sm flex items-center gap-2 border-b border-slate-100 pb-3">
                <Upload className="w-4 h-4 text-amber-600" />
                <span>Upload Ecobank Deposit Slip</span>
              </h3>

              {uploadSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>{uploadSuccess}</span>
                </div>
              )}

              <form onSubmit={handleTellerUpload} className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Teller / Transfer Reference</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ECO-TLR-99201"
                    value={tellerRef}
                    onChange={(e) => setTellerRef(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl font-mono text-xs focus:outline-none focus:border-amber-400 font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Amount Paid (GMD)</label>
                  <input
                    type="number"
                    required
                    value={tellerAmount}
                    onChange={(e) => setTellerAmount(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs focus:outline-none focus:border-amber-400 font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Slip Photo / PDF Attachment</label>
                  <div className="border-2 border-dashed border-slate-200 p-4 text-center rounded-2xl bg-slate-50 hover:bg-slate-100 transition cursor-pointer">
                    <Upload className="w-5 h-5 text-slate-400 mx-auto mb-1" />
                    <span className="text-[11px] text-slate-600 font-medium block">Click to attach bank slip</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#1B4D3E] hover:bg-[#143B2F] text-white font-extrabold py-2.5 rounded-xl shadow-md text-xs transition cursor-pointer"
                >
                  Submit Slip for Finance Confirmation
                </button>
              </form>
            </div>

            {/* Direct OpenSolar Ecobank Transfer Details */}
            <div
              className="p-3 bg-white rounded-3xl border border-slate-200 text-xs shadow-sm"
              dangerouslySetInnerHTML={{
                __html: StorageService.generateOpenSolarDirectPaymentInstructions(
                  activeClient.fullName,
                  activeClient.outstandingBalanceGMD,
                  `ECO-REF-${activeClient.id.toUpperCase()}`
                )
              }}
            />
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-4">
          <AlertCircle className="w-10 h-10 text-amber-500 mx-auto" />
          <h3 className="text-base font-bold text-slate-900 font-serif">No Client Record Found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Please log in with your verified email account or use the search bar above with your official client ID.
          </p>
        </div>
      )}
    </div>
  );
};
