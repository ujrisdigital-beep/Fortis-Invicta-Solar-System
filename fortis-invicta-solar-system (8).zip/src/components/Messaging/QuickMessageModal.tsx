import React, { useState } from 'react';
import { MessageSquare, Mail, Phone, Send, X, Check, Sparkles, AlertCircle, Copy } from 'lucide-react';
import { Client } from '../../types';
import { dispatchNotification, generateMessageTemplate, MessageChannel, TemplateType } from '../../utils/messaging';
import { safeCopyToClipboard } from '../../utils/clipboard';

interface QuickMessageModalProps {
  client: Client;
  isOpen: boolean;
  onClose: () => void;
  defaultTemplate?: TemplateType;
  actorName?: string;
  onMessageSent?: () => void;
}

export const QuickMessageModal: React.FC<QuickMessageModalProps> = ({
  client,
  isOpen,
  onClose,
  defaultTemplate = 'onboarding',
  actorName = 'Fortis Support Officer',
  onMessageSent
}) => {
  const [channel, setChannel] = useState<MessageChannel>('whatsapp');
  const [templateType, setTemplateType] = useState<TemplateType>(defaultTemplate);
  const [customNote, setCustomNote] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const template = generateMessageTemplate(templateType, client, customNote);

  const handleSend = () => {
    dispatchNotification(channel, templateType, client, customNote, actorName);
    if (onMessageSent) onMessageSent();
    onClose();
  };

  const handleCopyText = () => {
    safeCopyToClipboard(template.body).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden my-auto transition-all">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#12241D] to-[#1B4D3E] p-4 sm:p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold shrink-0 shadow-md">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-serif text-white">Instant Client Messaging</h3>
              <p className="text-xs text-emerald-100/90">Direct zero-cost WhatsApp, Email, & SMS dispatches</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-emerald-950/80 text-emerald-200 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 sm:p-6 space-y-4 text-xs">
          {/* Recipient Details */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-2">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 block">Recipient</span>
              <strong className="text-slate-900 text-sm font-serif">{client.fullName}</strong>
            </div>
            <div className="text-right text-[11px] text-slate-600 font-mono">
              <div>Phone: {client.phone || 'N/A'}</div>
              <div>Email: {client.email || 'N/A'}</div>
            </div>
          </div>

          {/* Channel Selector */}
          <div>
            <label className="block font-bold text-slate-800 mb-1.5 uppercase text-[10px] tracking-wider">
              1. Select Dispatch Channel (100% Free / Zero API Overhead)
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setChannel('whatsapp')}
                className={`p-3 rounded-2xl border font-bold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                  channel === 'whatsapp'
                    ? 'bg-emerald-50 border-emerald-600 text-emerald-950 ring-2 ring-emerald-600 shadow-sm'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <MessageSquare className="w-5 h-5 text-emerald-600" />
                <span className="text-xs">WhatsApp</span>
                <span className="text-[9px] text-emerald-700 font-normal">Direct Link</span>
              </button>

              <button
                type="button"
                onClick={() => setChannel('email')}
                className={`p-3 rounded-2xl border font-bold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                  channel === 'email'
                    ? 'bg-blue-50 border-blue-600 text-blue-950 ring-2 ring-blue-600 shadow-sm'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Mail className="w-5 h-5 text-blue-600" />
                <span className="text-xs">Email</span>
                <span className="text-[9px] text-blue-700 font-normal">Native Mail</span>
              </button>

              <button
                type="button"
                onClick={() => setChannel('sms')}
                className={`p-3 rounded-2xl border font-bold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                  channel === 'sms'
                    ? 'bg-purple-50 border-purple-600 text-purple-950 ring-2 ring-purple-600 shadow-sm'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Phone className="w-5 h-5 text-purple-600" />
                <span className="text-xs">Cellular SMS</span>
                <span className="text-[9px] text-purple-700 font-normal">Direct SMS</span>
              </button>
            </div>
          </div>

          {/* Template Selector */}
          <div>
            <label className="block font-bold text-slate-800 mb-1.5 uppercase text-[10px] tracking-wider">
              2. Select Message Template
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-[11px]">
              {(
                [
                  { id: 'onboarding', label: 'Onboarding Welcome' },
                  { id: 'inspection', label: 'Inspection Notice' },
                  { id: 'payment_reminder', label: 'Payment Notice' },
                  { id: 'stage_update', label: 'Stage Progress' },
                  { id: 'custom', label: 'Custom Message' }
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTemplateType(item.id)}
                  className={`p-2 rounded-xl font-medium transition-all text-left cursor-pointer border ${
                    templateType === item.id
                      ? 'bg-[#1B4D3E] text-amber-300 border-[#1B4D3E] font-bold shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Note or Override */}
          <div>
            <label className="block font-bold text-slate-800 mb-1 uppercase text-[10px] tracking-wider">
              3. Additional Notes / Inspector Instructions (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Please ensure site access at 10:00 AM or upload bank deposit receipt."
              value={customNote}
              onChange={(e) => setCustomNote(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 p-2.5 rounded-xl font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1B4D3E]"
            />
          </div>

          {/* Preview Box */}
          <div className="p-3.5 rounded-2xl bg-slate-900 text-slate-100 space-y-2 border border-slate-800">
            <div className="flex items-center justify-between text-[10px] border-b border-slate-800 pb-1.5 text-slate-400">
              <span className="font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Live Message Preview ({channel.toUpperCase()})
              </span>
              <button
                type="button"
                onClick={handleCopyText}
                className="hover:text-amber-300 transition-colors flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy Text'}</span>
              </button>
            </div>

            {channel === 'email' && (
              <div className="text-[11px] font-bold text-amber-200 border-b border-slate-800/80 pb-1">
                Subject: {template.subject}
              </div>
            )}

            <div className="text-[11px] font-mono leading-relaxed whitespace-pre-wrap max-h-36 overflow-y-auto pr-1 text-slate-300">
              {template.body}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <AlertCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Opens natively on Desktop, iPad, & Mobile</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSend}
              className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-extrabold px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-lg transition-all cursor-pointer transform active:scale-95"
            >
              <Send className="w-4 h-4 text-amber-400" />
              <span>Dispatch via {channel.toUpperCase()}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
