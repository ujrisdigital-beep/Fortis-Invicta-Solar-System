import React, { useState, useEffect } from 'react';
import {
  Building2,
  ShieldCheck,
  Search,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  Download,
  Users,
  CreditCard,
  Settings,
  Clock,
  Check,
  X,
  FileText,
  UserCheck,
  Plus,
  RefreshCw
} from 'lucide-react';
import { InstitutionalMember, Currency, UserRole } from '../../types';
import { StorageService } from '../../services/storage';
import { formatCurrency } from '../../utils/formatters';
import { UnionManagerView } from './UnionManagerView';

interface InstitutionalModuleProps {
  members: InstitutionalMember[];
  currency: Currency;
  currentRole?: UserRole;
  selectedUnionId?: string;
  isGdprActive?: boolean;
  onVerifyMember?: (institutionId: 'GTUCCU' | 'NAGNMC', memberId: string) => void;
}

export const InstitutionalModule: React.FC<InstitutionalModuleProps> = ({
  members,
  currency,
  currentRole = 'super_admin',
  selectedUnionId = 'GTUCCU',
  isGdprActive = true
}) => {
  const isUnionAdmin = currentRole === 'institutional_admin';
  const effectiveUnion = isUnionAdmin ? (selectedUnionId === 'NAGNMC' ? 'NAGNMC' : 'GTUCCU') : 'GTUCCU';

  const [subTab, setSubTab] = useState<'members' | 'admin_queue' | 'unions_admin'>('members');
  const [selectedInstitution, setSelectedInstitution] = useState<'GTUCCU' | 'NAGNMC'>(effectiveUnion);
  const [memberIdQuery, setMemberIdQuery] = useState<string>('');
  const [searchResult, setSearchResult] = useState<InstitutionalMember | null | 'NOT_FOUND' | 'DENIED'>(null);

  // Sync selectedInstitution when effectiveUnion changes
  useEffect(() => {
    if (isUnionAdmin) {
      setSelectedInstitution(effectiveUnion);
    }
  }, [effectiveUnion, isUnionAdmin]);

  // Admin Queue State
  const [reviewQueue, setReviewQueue] = useState<any[]>([]);
  const [isLoadingQueue, setIsLoadingQueue] = useState(false);
  const [selectedQueueItem, setSelectedQueueItem] = useState<any | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [customCreditLimit, setCustomCreditLimit] = useState<number>(350000);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // New Dossier Submission Modal State
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [newMemberId, setNewMemberId] = useState('');
  const [newMemberName, setNewMemberName] = useState('');
  const [newWorkplace, setNewWorkplace] = useState('');
  const [newSalary, setNewSalary] = useState(18000);
  const [newInstitution, setNewInstitution] = useState(effectiveUnion);

  const fetchQueue = async () => {
    setIsLoadingQueue(true);
    try {
      const url = isUnionAdmin
        ? `/api/v2/verify-member/queue?institutionId=${effectiveUnion}`
        : '/api/v2/verify-member/queue';
      const res = await fetch(url);
      const data = await res.json();
      if (data.queue) {
        setReviewQueue(data.queue);
      }
    } catch {
      // Fallback
    } finally {
      setIsLoadingQueue(false);
    }
  };

  useEffect(() => {
    if (subTab === 'admin_queue') {
      fetchQueue().catch(() => {});
    }
  }, [subTab, selectedInstitution, effectiveUnion]);

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberIdQuery.trim()) return;

    // Enforce Tenant Boundary check
    if (isUnionAdmin && selectedInstitution !== effectiveUnion) {
      setSearchResult('DENIED');
      return;
    }

    const res = StorageService.verifyMember(selectedInstitution, memberIdQuery, currentRole, effectiveUnion);
    if (res) {
      setSearchResult(res);
    } else {
      setSearchResult('NOT_FOUND');
    }
  };

  const handleReviewAction = async (status: 'APPROVED' | 'REJECTED' | 'MORE_INFO_REQUIRED') => {
    if (!selectedQueueItem) return;

    try {
      const res = await fetch(`/api/v2/verify-member/review/${selectedQueueItem.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          adminNotes: adminNote,
          approvedCreditLimit: customCreditLimit,
          reviewerName: 'Fatou Jallow (Finance Officer)'
        })
      });

      const data = await res.json();
      if (data.success) {
        setActionSuccessMsg(`Dossier #${selectedQueueItem.id} status updated to ${status}`);
        setSelectedQueueItem(null);
        setAdminNote('');
        fetchQueue();
        setTimeout(() => setActionSuccessMsg(null), 4000);
      }
    } catch (err: any) {
      alert(`Error updating review: ${err.message}`);
    }
  };

  const handleSubmitNewDossier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberId || !newMemberName) return;

    try {
      const res = await fetch('/api/v2/verify-member/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          institutionId: newInstitution,
          memberId: newMemberId,
          memberName: newMemberName,
          workplace: newWorkplace,
          monthlyGrossSalaryGMD: Number(newSalary)
        })
      });

      const data = await res.json();
      if (data.success) {
        setActionSuccessMsg(`Verification request for ${newMemberName} submitted to Admin Queue`);
        setShowSubmitModal(false);
        setNewMemberId('');
        setNewMemberName('');
        setNewWorkplace('');
        if (subTab === 'admin_queue') fetchQueue();
        setTimeout(() => setActionSuccessMsg(null), 4000);
      }
    } catch (err: any) {
      alert(`Failed to submit: ${err.message}`);
    }
  };

  const filteredMembers = members.filter((m) => m.institutionId === selectedInstitution);

  return (
    <div className="space-y-6 pb-12">
      {/* Module Navigation Sub-Tabs */}
      <div className="flex flex-wrap border-b border-slate-200 bg-white rounded-2xl p-1.5 shadow-sm max-w-2xl gap-1">
        <button
          onClick={() => setSubTab('members')}
          className={`flex items-center gap-2 py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            subTab === 'members'
              ? 'bg-[#1B4D3E] text-amber-300 shadow'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Member Verification Registry</span>
        </button>

        <button
          onClick={() => setSubTab('admin_queue')}
          className={`flex items-center gap-2 py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            subTab === 'admin_queue'
              ? 'bg-[#1B4D3E] text-amber-300 shadow'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Human-in-the-Loop Review Queue</span>
        </button>

        <button
          onClick={() => setSubTab('unions_admin')}
          className={`flex items-center gap-2 py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            subTab === 'unions_admin'
              ? 'bg-[#1B4D3E] text-amber-300 shadow'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Union Admin & Onboarding</span>
        </button>
      </div>

      {actionSuccessMsg && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-2xl p-4 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {subTab === 'unions_admin' ? (
        <UnionManagerView currency={currency} />
      ) : subTab === 'admin_queue' ? (
        /* Human-in-the-Loop Review Queue View */
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-slate-900 font-serif">
                Institutional Verification Admin Queue
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                Human-in-the-Loop review of GTUCCU, NAGNMC, and civil service payroll deduction applications with Gambian 33.3% net salary statutory cap validation.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowSubmitModal(true)}
                className="inline-flex items-center gap-1.5 bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 text-xs font-bold py-2 px-3.5 rounded-xl transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Submit Verification Dossier</span>
              </button>

              <button
                onClick={fetchQueue}
                className="p-2 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-600 cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingQueue ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h2 className="text-sm font-bold text-slate-900 font-serif uppercase tracking-wider">
              Pending & Processed Dossiers ({reviewQueue.length})
            </h2>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700 border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 uppercase font-semibold text-[10px]">
                    <th className="p-3">Dossier ID</th>
                    <th className="p-3">Institution</th>
                    <th className="p-3">Member ID</th>
                    <th className="p-3">Member Name</th>
                    <th className="p-3">Workplace</th>
                    <th className="p-3">Monthly Salary</th>
                    <th className="p-3">Credit Limit</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {reviewQueue.map((item) => {
                    const isPending = item.status === 'PENDING';
                    return (
                      <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3 font-mono font-bold text-slate-600">{item.id}</td>
                        <td className="p-3 font-bold text-[#1B4D3E]">{item.institutionId}</td>
                        <td className="p-3 font-mono font-bold text-slate-900">{item.memberId}</td>
                        <td className="p-3 font-bold text-slate-900">{item.memberName}</td>
                        <td className="p-3 text-slate-600">{item.workplace}</td>
                        <td className="p-3 font-mono">{formatCurrency(item.monthlyGrossSalaryGMD || 0, currency)}</td>
                        <td className="p-3 font-mono font-bold text-emerald-800">
                          {item.approvedCreditLimitGMD ? formatCurrency(item.approvedCreditLimitGMD, currency) : 'Pending Calc'}
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full font-black text-[10px] uppercase ${
                              item.status === 'APPROVED'
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.status === 'REJECTED'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {item.status}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => {
                              setSelectedQueueItem(item);
                              setAdminNote(item.adminNotes || '');
                              setCustomCreditLimit(item.approvedCreditLimitGMD || Math.round(item.monthlyGrossSalaryGMD * 18));
                            }}
                            className="bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 font-bold px-3 py-1 rounded-lg text-xs transition cursor-pointer"
                          >
                            Review
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Review Modal */}
          {selectedQueueItem && (
            <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden text-xs p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 font-serif">
                      Review Verification Dossier: {selectedQueueItem.memberName}
                    </h3>
                    <span className="text-slate-500 font-mono text-[11px]">
                      {selectedQueueItem.institutionId} • Member ID: {selectedQueueItem.memberId}
                    </span>
                  </div>
                  <button
                    onClick={() => setSelectedQueueItem(null)}
                    className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                  <div>
                    <span className="text-slate-500 block">Workplace / Ministry:</span>
                    <strong className="text-slate-900">{selectedQueueItem.workplace}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Gross Monthly Salary:</span>
                    <strong className="text-slate-900">{formatCurrency(selectedQueueItem.monthlyGrossSalaryGMD || 0, currency)}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Statutory Net Cap (33.3%):</span>
                    <strong className="text-emerald-800">
                      {formatCurrency(Math.round((selectedQueueItem.monthlyGrossSalaryGMD || 0) * 0.85 * 0.333), currency)} / mo
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Current Status:</span>
                    <strong className="uppercase font-bold text-amber-700">{selectedQueueItem.status}</strong>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Approved Credit Limit (GMD)</label>
                  <input
                    type="number"
                    value={customCreditLimit}
                    onChange={(e) => setCustomCreditLimit(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono font-bold text-xs"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Credit Committee Audit Notes & Remarks</label>
                  <textarea
                    rows={3}
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                    placeholder="Enter verification remarks, payslip check details, or reason for rejection..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    onClick={() => handleReviewAction('REJECTED')}
                    className="bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold px-4 py-2 rounded-xl transition cursor-pointer"
                  >
                    Reject Dossier
                  </button>

                  <button
                    onClick={() => handleReviewAction('MORE_INFO_REQUIRED')}
                    className="bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold px-4 py-2 rounded-xl transition cursor-pointer"
                  >
                    Request More Info
                  </button>

                  <button
                    onClick={() => handleReviewAction('APPROVED')}
                    className="bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 font-bold px-5 py-2 rounded-xl shadow transition cursor-pointer"
                  >
                    Approve & Issue HMAC Token
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Submit New Dossier Modal */}
          {showSubmitModal && (
            <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <form onSubmit={handleSubmitNewDossier} className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden text-xs p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h3 className="text-base font-bold text-slate-900 font-serif">Submit Verification Dossier</h3>
                  <button type="button" onClick={() => setShowSubmitModal(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Institution</label>
                  <select
                    value={newInstitution}
                    onChange={(e) => setNewInstitution(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-bold"
                  >
                    <option value="GTUCCU">Gambia Teachers Union (GTUCCU)</option>
                    <option value="NAGNMC">Nurses Council (NAGNMC)</option>
                    <option value="GAMPOST">Gambia Postal Services (GAMPOST)</option>
                    <option value="GAMTEL">GAMTEL Telecommunications</option>
                    <option value="NAWEC">NAWEC Water & Electricity</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Member ID</label>
                  <input
                    type="text"
                    value={newMemberId}
                    onChange={(e) => setNewMemberId(e.target.value)}
                    placeholder="e.g. GTU-99201"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Full Member Name</label>
                  <input
                    type="text"
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                    placeholder="e.g. Modou Ceesay"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Workplace / School / Clinic</label>
                  <input
                    type="text"
                    value={newWorkplace}
                    onChange={(e) => setNewWorkplace(e.target.value)}
                    placeholder="e.g. Nusrat Senior Secondary School"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Gross Monthly Salary (GMD)</label>
                  <input
                    type="number"
                    value={newSalary}
                    onChange={(e) => setNewSalary(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-xs"
                    min={1000}
                    required
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowSubmitModal(false)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 font-bold shadow"
                  >
                    Submit to Review Queue
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      ) : (
        /* Registry View */
        <>
          {/* Header & Compliance Scope */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-slate-900 font-serif">
                  Institutional Member Verification & Payroll Financing
                </h1>
                <span className="bg-teal-100 text-teal-800 text-xs font-bold px-2.5 py-0.5 rounded-full border border-teal-300">
                  Salary Deduction Active
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Verify union member eligibility for salary deduction solar financing under UK GDPR & Gambia Data Protection Act
              </p>
            </div>

            {/* Tenant Boundary Indicator */}
            {isUnionAdmin ? (
              <div className="flex items-center gap-2 bg-amber-50 border border-amber-300 px-3 py-1.5 rounded-xl text-xs text-amber-900 font-bold">
                <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Tenant Isolation: <strong>{effectiveUnion} Only</strong></span>
              </div>
            ) : (
              <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-300 px-3 py-1.5 rounded-xl text-xs text-emerald-900 font-bold">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Cross-Institutional Controller Scope (Audit Logged)</span>
              </div>
            )}
          </div>

          {/* Member Verification Lookup Tool */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-slate-900 font-serif flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-teal-700" />
              <span>Real-time Member Verification Lookup</span>
            </h2>

            <form onSubmit={handleLookup} className="flex flex-wrap items-center gap-3 text-xs">
              <select
                value={selectedInstitution}
                onChange={(e) => !isUnionAdmin && setSelectedInstitution(e.target.value as 'GTUCCU' | 'NAGNMC')}
                disabled={isUnionAdmin}
                className={`border border-slate-200 rounded-xl px-3 py-2.5 font-bold text-slate-800 focus:outline-none ${
                  isUnionAdmin ? 'bg-slate-100 text-slate-500 cursor-not-allowed' : 'bg-slate-50'
                }`}
              >
                <option value="GTUCCU">Gambia Teachers Union (GTUCCU)</option>
                <option value="NAGNMC">Nurses Council (NAGNMC)</option>
              </select>

              <div className="relative flex-1 min-w-[220px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder={`Enter ${selectedInstitution} Member ID (e.g. ${selectedInstitution === 'GTUCCU' ? 'GTU-88421' : 'NAG-4109'})...`}
                  value={memberIdQuery}
                  onChange={(e) => setMemberIdQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="bg-[#1B4D3E] hover:bg-[#143B2F] text-white font-bold px-5 py-2.5 rounded-xl shadow-sm transition-all cursor-pointer"
              >
                Verify Member ID
              </button>
            </form>

            {/* Search Result Box */}
            {searchResult === 'DENIED' && (
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-xs flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0" />
                <div>
                  <strong>Access Denied: Cross-Tenant Query Forbidden</strong>
                  <p className="text-[11px] text-amber-800">Under UK GDPR Art 32 & The Gambia Data Protection Act Sec 24, institutional administrators cannot query members outside their designated union.</p>
                </div>
              </div>
            )}

            {searchResult === 'NOT_FOUND' && (
              <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
                <div>
                  <strong>Member Not Found in {selectedInstitution} Active Registry</strong>
                  <p className="text-[11px] text-rose-700">Please verify member ID spelling or submit a verification dossier for committee review.</p>
                </div>
              </div>
            )}

            {typeof searchResult === 'object' && searchResult !== null && (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs space-y-2">
                <div className="flex justify-between items-center text-emerald-950 font-bold border-b border-emerald-200 pb-2">
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    VERIFIED ACTIVE MEMBER: {searchResult.fullName}
                  </span>
                  <span className="bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded text-[10px] uppercase font-bold">
                    Payroll Deduction Eligible
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-slate-700">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Member ID</span>
                    <strong className="font-mono text-slate-900">{searchResult.memberId}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Workplace</span>
                    <strong className="text-slate-900">{searchResult.workplace}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Monthly Salary</span>
                    <strong className="text-slate-900">{isGdprActive ? '*** (Protected)' : formatCurrency(searchResult.monthlySalaryGMD, currency)}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Max Credit Limit</span>
                    <strong className="text-emerald-800">{formatCurrency(searchResult.eligibleCreditGMD, currency)}</strong>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Institutional Member Table */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900 font-serif">
                  {selectedInstitution} Pre-Approved Member Database
                </h2>
                <p className="text-xs text-slate-500">Official registry of members with payroll deduction authorization</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700 border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 uppercase font-semibold text-[10px]">
                    <th className="p-3">Member ID</th>
                    <th className="p-3">Full Name</th>
                    <th className="p-3">Workplace</th>
                    <th className="p-3">Monthly Salary</th>
                    <th className="p-3">Max Credit Limit</th>
                    <th className="p-3 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredMembers.map((m) => (
                    <tr key={m.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3 font-mono font-bold text-teal-800">{m.memberId}</td>
                      <td className="p-3 font-bold text-slate-900">{m.fullName}</td>
                      <td className="p-3 text-slate-600">{m.workplace}</td>
                      <td className="p-3 font-medium">{isGdprActive ? '*** GMD' : formatCurrency(m.monthlySalaryGMD, currency)}</td>
                      <td className="p-3 font-bold text-emerald-800">{formatCurrency(m.eligibleCreditGMD, currency)}</td>
                      <td className="p-3 text-right">
                        <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded text-[10px] uppercase">
                          {m.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {filteredMembers.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-500">
                        No members found for {selectedInstitution} under current role scope.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
