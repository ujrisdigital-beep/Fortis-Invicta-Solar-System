import React, { useState } from 'react';
import {
  Building2,
  Plus,
  ShieldCheck,
  Edit,
  Trash2,
  CheckCircle2,
  XCircle,
  FileSpreadsheet,
  Percent,
  Calendar,
  DollarSign,
  Download,
  FileText,
  Sparkles,
  Info,
  X
} from 'lucide-react';
import { UnionConfig, Currency } from '../../types';
import { StorageService } from '../../services/storage';
import { formatCurrency } from '../../utils/formatters';

interface UnionManagerViewProps {
  currency: Currency;
  onUnionsUpdated?: () => void;
}

export const UnionManagerView: React.FC<UnionManagerViewProps> = ({
  currency,
  onUnionsUpdated
}) => {
  const [unions, setUnions] = useState<UnionConfig[]>(() => StorageService.getUnions());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUnion, setEditingUnion] = useState<UnionConfig | null>(null);

  // Form state for creating/editing union
  const [name, setName] = useState('');
  const [shortCode, setShortCode] = useState('');
  const [sector, setSector] = useState('');
  const [defaultQualifyingMonths, setDefaultQualifyingMonths] = useState(24);
  const [adminFeePercent, setAdminFeePercent] = useState(5.0);
  const [defaultDownPaymentPercent, setDefaultDownPaymentPercent] = useState(10);
  const [maxLoanCapGMD, setMaxLoanCapGMD] = useState(750000);
  const [requiredDocsInput, setRequiredDocsInput] = useState('Latest Salary Payslip, Union Member ID, National Biometric ID');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [description, setDescription] = useState('');

  const refreshList = () => {
    const list = StorageService.getUnions();
    setUnions(list);
    if (onUnionsUpdated) onUnionsUpdated();
  };

  const handleOpenAdd = () => {
    setEditingUnion(null);
    setName('');
    setShortCode('');
    setSector('Civil Service / Public Sector');
    setDefaultQualifyingMonths(24);
    setAdminFeePercent(5.0);
    setDefaultDownPaymentPercent(10);
    setMaxLoanCapGMD(750000);
    setRequiredDocsInput('Latest Salary Payslip, Union ID Card, National Biometric ID');
    setContactEmail('');
    setContactPhone('');
    setDescription('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (u: UnionConfig) => {
    setEditingUnion(u);
    setName(u.name);
    setShortCode(u.shortCode);
    setSector(u.sector);
    setDefaultQualifyingMonths(u.defaultQualifyingMonths);
    setAdminFeePercent(u.adminFeePercent);
    setDefaultDownPaymentPercent(u.defaultDownPaymentPercent);
    setMaxLoanCapGMD(u.maxLoanCapGMD);
    setRequiredDocsInput(u.requiredDocuments.join(', '));
    setContactEmail(u.contactEmail || '');
    setContactPhone(u.contactPhone || '');
    setDescription(u.description || '');
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !shortCode) return;

    const docs = requiredDocsInput
      .split(',')
      .map((d) => d.trim())
      .filter((d) => d.length > 0);

    const unionData: UnionConfig = {
      id: editingUnion ? editingUnion.id : shortCode.toUpperCase().replace(/\s+/g, '_'),
      name,
      shortCode: shortCode.toUpperCase(),
      sector,
      qualifyingMonthsOptions: [12, 18, 24, 36],
      defaultQualifyingMonths,
      adminFeePercent,
      defaultDownPaymentPercent,
      maxLoanCapGMD,
      requiredDocuments: docs.length > 0 ? docs : ['Latest Salary Payslip', 'National ID'],
      isActive: editingUnion ? editingUnion.isActive : true,
      contactEmail,
      contactPhone,
      description,
      createdAt: editingUnion ? editingUnion.createdAt : new Date().toISOString()
    };

    StorageService.saveUnion(unionData, 'Admin');
    refreshList();
    setIsModalOpen(false);
  };

  const handleToggleStatus = (unionId: string) => {
    StorageService.toggleUnionStatus(unionId, 'Admin');
    refreshList();
  };

  const handleExportCSV = () => {
    const csvHeader = 'Union ID,Union Name,Short Code,Sector,Admin Fee %,Max Loan Cap GMD,Status\n';
    const csvRows = unions
      .map(
        (u) =>
          `"${u.id}","${u.name}","${u.shortCode}","${u.sector}",${u.adminFeePercent},${u.maxLoanCapGMD},"${
            u.isActive ? 'Active' : 'Inactive'
          }"`
      )
      .join('\n');

    const blob = new Blob([csvHeader + csvRows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fortis_institutional_unions_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#1B4D3E] text-amber-300 rounded-xl">
              <Building2 className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold text-slate-900 font-serif">
              Dynamic Institutional Union Onboarding & Administration
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Onboard new intending civil service unions, cooperatives, and corporations dynamically with zero developer intervention
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-md transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Onboard New Union</span>
          </button>
        </div>
      </div>

      {/* Union Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {unions.map((u, idx) => (
          <div
            key={`${u.id}-${idx}`}
            className={`bg-white rounded-2xl border p-5 shadow-sm space-y-4 relative flex flex-col justify-between transition-all ${
              u.isActive ? 'border-slate-200/80 hover:border-emerald-500' : 'border-slate-200 opacity-60'
            }`}
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="bg-[#12241D] text-amber-300 font-extrabold text-xs px-2.5 py-1 rounded-lg font-mono">
                  {u.shortCode}
                </span>
                <button
                  onClick={() => handleToggleStatus(u.id)}
                  className={`flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border cursor-pointer ${
                    u.isActive
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      : 'bg-slate-200 text-slate-600 border-slate-300'
                  }`}
                >
                  {u.isActive ? (
                    <>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Active
                    </>
                  ) : (
                    <>
                      <XCircle className="w-3 h-3 text-slate-500" /> Deactivated
                    </>
                  )}
                </button>
              </div>

              <h3 className="text-sm font-bold text-slate-900 font-serif leading-snug">{u.name}</h3>
              <p className="text-[11px] text-slate-500 font-medium">{u.sector}</p>

              {u.description && <p className="text-xs text-slate-600 mt-2 line-clamp-2">{u.description}</p>}
            </div>

            {/* Financial Parameters */}
            <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-400 block font-medium">Qualifying Term</span>
                  <span className="font-bold text-slate-800">{u.defaultQualifyingMonths} Months</span>
                </div>

                <div>
                  <span className="text-slate-400 block font-medium">Admin Fee</span>
                  <span className="font-bold text-emerald-800">{u.adminFeePercent}%</span>
                </div>

                <div>
                  <span className="text-slate-400 block font-medium">Down Payment</span>
                  <span className="font-bold text-slate-800">{u.defaultDownPaymentPercent}%</span>
                </div>

                <div>
                  <span className="text-slate-400 block font-medium">Max Loan Cap</span>
                  <span className="font-bold text-[#1B4D3E]">
                    {formatCurrency(u.maxLoanCapGMD, currency)}
                  </span>
                </div>
              </div>

              {/* Required Documents Tagging */}
              <div className="pt-2 border-t border-slate-200/60">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Required Checklist ({u.requiredDocuments.length})
                </span>
                <div className="flex flex-wrap gap-1">
                  {u.requiredDocuments.map((doc, idx) => (
                    <span
                      key={idx}
                      className="bg-white border border-slate-200 text-slate-700 text-[9px] px-1.5 py-0.5 rounded font-medium"
                    >
                      {doc}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-[10px] text-slate-400">ID: {u.id}</span>
              <button
                onClick={() => handleOpenEdit(u)}
                className="text-[#1B4D3E] font-bold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Configure Parameters</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Onboard / Edit Union Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] overflow-y-auto">
            <div className="bg-[#12241D] text-white p-4 flex items-center justify-between border-b border-[#1B4D3E]">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold font-serif">
                  {editingUnion ? 'Edit Institutional Union Configuration' : 'Onboard New Intending Union'}
                </h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-emerald-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-4 text-xs">
              {/* Union Name & Short Code */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-slate-700">Union / Institution Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Gambia Postal Services Staff Union..."
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:ring-2 focus:ring-[#1B4D3E]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Short Code *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. GAMPOST"
                    value={shortCode}
                    onChange={(e) => setShortCode(e.target.value.toUpperCase())}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-emerald-900 focus:ring-2 focus:ring-[#1B4D3E]"
                  />
                </div>
              </div>

              {/* Sector & Max Loan Cap */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Sector / Public Body</label>
                  <input
                    type="text"
                    placeholder="e.g. Postal Services & Telecommunications..."
                    value={sector}
                    onChange={(e) => setSector(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Max Member Credit Limit (GMD)</label>
                  <input
                    type="number"
                    required
                    step={10000}
                    value={maxLoanCapGMD}
                    onChange={(e) => setMaxLoanCapGMD(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-[#1B4D3E]"
                  />
                </div>
              </div>

              {/* Financial Terms: Qualifying Months, Admin Fee %, Down Payment % */}
              <div className="grid grid-cols-3 gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 text-[11px]">Default Term (Mos)</label>
                  <select
                    value={defaultQualifyingMonths}
                    onChange={(e) => setDefaultQualifyingMonths(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-xl px-2 py-1.5 text-xs font-bold"
                  >
                    <option value={12}>12 Months</option>
                    <option value={18}>18 Months</option>
                    <option value={24}>24 Months</option>
                    <option value={36}>36 Months</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 text-[11px]">Admin Fee %</label>
                  <input
                    type="number"
                    step={0.5}
                    value={adminFeePercent}
                    onChange={(e) => setAdminFeePercent(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-xl px-2 py-1.5 text-xs font-bold text-emerald-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 text-[11px]">Down Payment %</label>
                  <input
                    type="number"
                    step={5}
                    value={defaultDownPaymentPercent}
                    onChange={(e) => setDefaultDownPaymentPercent(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-xl px-2 py-1.5 text-xs font-bold"
                  />
                </div>
              </div>

              {/* Required Documents Checklist */}
              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Required Document Checklist (Comma Separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Latest Salary Payslip, Union Member ID Card, National Biometric ID..."
                  value={requiredDocsInput}
                  onChange={(e) => setRequiredDocsInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                />
              </div>

              {/* Contact Information & Description */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Union Contact Email</label>
                  <input
                    type="email"
                    placeholder="welfare@union.gm"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Union Contact Phone</label>
                  <input
                    type="text"
                    placeholder="+220 449 0000"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Union Overview & Notes</label>
                <textarea
                  rows={2}
                  placeholder="Describe salary deduction terms or government ministry affiliation..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs"
                />
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2 rounded-xl text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold px-5 py-2 rounded-xl text-xs shadow-md"
                >
                  {editingUnion ? 'Save Changes' : 'Activate Union Onboarding'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
