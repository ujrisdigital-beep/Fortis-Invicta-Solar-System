import React, { useState } from 'react';
import {
  Camera,
  Video,
  FileText,
  Upload,
  MapPin,
  Trash2,
  X,
  Plus,
  Image as ImageIcon,
  CheckCircle2,
  PlayCircle,
  Eye,
  Tag,
  Sparkles,
  Info,
  Compass
} from 'lucide-react';
import { MultimediaRecord, UserRole } from '../../types';
import { StorageService } from '../../services/storage';

interface MultimediaManagerProps {
  clientId?: string;
  clientName?: string;
  currentRole?: UserRole;
  currentUser?: string;
  onMediaAdded?: (record: MultimediaRecord) => void;
  compact?: boolean;
}

export const MultimediaManager: React.FC<MultimediaManagerProps> = ({
  clientId,
  clientName,
  currentRole = 'site_inspector',
  currentUser = 'Field Inspector',
  onMediaAdded,
  compact = false
}) => {
  const [mediaList, setMediaList] = useState<MultimediaRecord[]>(() =>
    StorageService.getMultimedia(clientId)
  );
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activePreview, setActivePreview] = useState<MultimediaRecord | null>(null);

  // Form states for new recording
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<MultimediaRecord['category']>('photo');
  const [description, setDescription] = useState('');
  const [locationName, setLocationName] = useState(clientName ? `${clientName} Site` : 'Brikama Site');
  const [gpsCoordinates, setGpsCoordinates] = useState<{ lat: number; lng: number; formatted?: string } | null>(null);
  const [fileDataUrl, setFileDataUrl] = useState<string>('');
  const [fileType, setFileType] = useState<string>('image/jpeg');
  const [fileSizeFormatted, setFileSizeFormatted] = useState<string>('1.5 MB');
  const [isDetectingGps, setIsDetectingGps] = useState(false);

  // Refresh media list
  const refreshMedia = () => {
    setMediaList(StorageService.getMultimedia(clientId));
  };

  // Get current device location
  const handleDetectGPS = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser');
      return;
    }
    setIsDetectingGps(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = parseFloat(pos.coords.latitude.toFixed(4));
        const lng = parseFloat(pos.coords.longitude.toFixed(4));
        setGpsCoordinates({
          lat,
          lng,
          formatted: `${lat}° N, ${lng}° W`
        });
        setIsDetectingGps(false);
      },
      (err) => {
        console.warn('Geolocation error:', err.message);
        // Fallback default coordinates for The Gambia
        setGpsCoordinates({
          lat: 13.4549,
          lng: -16.579,
          formatted: '13.4549° N, 16.5790° W (Default Banjul Metro)'
        });
        setIsDetectingGps(false);
      },
      { timeout: 8000 }
    );
  };

  // Handle local media file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const sizeInMB = (file.size / (1024 * 1024)).toFixed(1);
    setFileSizeFormatted(`${sizeInMB} MB`);
    setFileType(file.type);

    if (!title) {
      setTitle(file.name.replace(/\.[^/.]+$/, ''));
    }

    if (file.type.startsWith('video/')) {
      setCategory('video');
    } else if (file.type.startsWith('image/')) {
      setCategory('photo');
    } else {
      setCategory('report');
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setFileDataUrl(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Submit media record
  const handleSaveMedia = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    // Default sample image if no file was uploaded
    const sampleImage =
      category === 'video'
        ? 'https://images.unsplash.com/photo-1559302504-64aae6ca6b6d?auto=format&fit=crop&q=80&w=800'
        : 'https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=800';

    const finalMediaUrl = fileDataUrl || sampleImage;

    const newRecord = StorageService.addMultimedia(
      {
        clientId,
        title,
        category,
        mediaUrl: finalMediaUrl,
        fileType,
        fileSizeFormatted,
        description,
        locationName,
        gpsCoordinates: gpsCoordinates || {
          lat: 13.3981,
          lng: -16.7121,
          formatted: '13.3981° N, 16.7121° W (Brusubi)'
        },
        uploadedBy: currentUser,
        uploadedByRole: currentRole as UserRole
      },
      currentUser,
      currentRole as UserRole
    );

    if (onMediaAdded) onMediaAdded(newRecord);

    refreshMedia();
    setIsModalOpen(false);
    // Reset form
    setTitle('');
    setDescription('');
    setFileDataUrl('');
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this multimedia log?')) {
      StorageService.deleteMultimedia(id, currentUser);
      refreshMedia();
    }
  };

  const filteredMedia = mediaList.filter((m) => {
    if (selectedCategory === 'all') return true;
    return m.category === selectedCategory;
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-emerald-100 text-[#1B4D3E] rounded-lg">
              <Camera className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 font-serif">
              Multimedia Assessment & Site Recordings
            </h3>
            <span className="bg-amber-100 text-amber-900 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-amber-300">
              {mediaList.length} Assets Logged
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Photos, videos, roof inspections, electrical box testing, and GPS tagged site reports
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            handleDetectGPS();
            setIsModalOpen(true);
          }}
          className="flex items-center gap-1.5 bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold text-xs px-3.5 py-2 rounded-xl shadow-sm transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Record Photo / Video</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto text-xs pb-1 scrollbar-none">
        {[
          { id: 'all', label: 'All Media' },
          { id: 'photo', label: 'Photos' },
          { id: 'video', label: 'Videos' },
          { id: 'assessment', label: 'Assessments' },
          { id: 'maintenance', label: 'Maintenance' },
          { id: 'report', label: 'Reports' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedCategory(tab.id)}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer whitespace-nowrap ${
              selectedCategory === tab.id
                ? 'bg-slate-900 text-amber-300 shadow-sm'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Grid Gallery */}
      {filteredMedia.length === 0 ? (
        <div className="text-center py-8 bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-6 space-y-2">
          <ImageIcon className="w-8 h-8 text-slate-300 mx-auto" />
          <p className="text-xs font-semibold text-slate-600">No multimedia assets recorded for this section.</p>
          <p className="text-[11px] text-slate-400">
            Click "Record Photo / Video" above to capture site photos, roof inspections, or test videos.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {filteredMedia.map((m) => (
            <div
              key={m.id}
              className="group relative bg-slate-50 rounded-xl border border-slate-200 overflow-hidden hover:shadow-md transition-all flex flex-col justify-between"
            >
              {/* Media Thumbnail */}
              <div className="relative h-36 bg-slate-900 overflow-hidden cursor-pointer" onClick={() => setActivePreview(m)}>
                {m.category === 'video' ? (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 z-10 group-hover:bg-black/20 transition-all">
                    <PlayCircle className="w-10 h-10 text-amber-400 drop-shadow-md transform group-hover:scale-110 transition-transform" />
                  </div>
                ) : null}

                <img
                  src={m.mediaUrl}
                  alt={m.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />

                <span className="absolute top-2 left-2 bg-slate-900/80 text-amber-300 text-[10px] font-black px-2 py-0.5 rounded-md uppercase backdrop-blur-sm">
                  {m.category}
                </span>

                <span className="absolute bottom-2 right-2 bg-black/70 text-white text-[10px] font-mono px-2 py-0.5 rounded backdrop-blur-sm">
                  {m.fileSizeFormatted}
                </span>
              </div>

              {/* Card Details */}
              <div className="p-3 space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{m.title}</h4>
                  {m.description && <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">{m.description}</p>}
                </div>

                <div className="pt-2 border-t border-slate-200/60 text-[10px] text-slate-500 space-y-1">
                  <div className="flex items-center gap-1 text-emerald-800 font-semibold">
                    <MapPin className="w-3 h-3 text-emerald-700 shrink-0" />
                    <span className="truncate">{m.locationName}</span>
                  </div>

                  {m.gpsCoordinates && (
                    <div className="flex items-center gap-1 font-mono text-[9px] text-slate-400">
                      <Compass className="w-3 h-3 text-slate-400 shrink-0" />
                      <span>{m.gpsCoordinates.formatted || `${m.gpsCoordinates.lat}° N, ${m.gpsCoordinates.lng}° W`}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-slate-400 pt-1">
                    <span>{new Date(m.capturedAt).toLocaleDateString('en-GB')}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setActivePreview(m)}
                        className="text-emerald-800 font-bold hover:underline flex items-center gap-0.5"
                      >
                        <Eye className="w-3 h-3" /> View
                      </button>
                      {(currentRole === 'super_admin' || currentRole === 'project_manager') && (
                        <button onClick={() => handleDelete(m.id)} className="text-rose-600 hover:text-rose-800 p-0.5">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Record Media Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="bg-[#12241D] text-white p-4 flex items-center justify-between border-b border-[#1B4D3E]">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold font-serif">Record Site Photo, Video or Assessment Report</h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-emerald-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMedia} className="p-5 space-y-4 text-xs">
              {/* Media File Upload Input */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 uppercase tracking-wider block">
                  Select File or Capture Camera Video
                </label>
                <div className="border-2 border-dashed border-slate-300 hover:border-[#1B4D3E] rounded-2xl p-4 text-center bg-slate-50 transition-colors cursor-pointer relative">
                  <input
                    type="file"
                    accept="image/*,video/*,application/pdf"
                    onChange={handleFileChange}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                  />
                  <Upload className="w-6 h-6 text-emerald-800 mx-auto mb-1" />
                  <span className="font-bold text-slate-800 block text-xs">
                    {fileDataUrl ? 'Media Selected (Click to Change)' : 'Click or Drag Photo / Video / PDF'}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    Supports camera photos, site inspection MP4 videos, and PDF reports
                  </span>
                </div>
              </div>

              {/* Title & Category */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Record Title *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Inverter Box Cable Test..."
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:ring-2 focus:ring-[#1B4D3E]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:ring-2 focus:ring-[#1B4D3E]"
                  >
                    <option value="photo">Site Photo</option>
                    <option value="video">Installation Video</option>
                    <option value="assessment">Site Assessment</option>
                    <option value="maintenance">Maintenance Inspection</option>
                    <option value="report">PDF Document / Certificate</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Inspection Notes / Details</label>
                <textarea
                  rows={2}
                  placeholder="Describe electrical box condition, roof tilt angle, or battery testing outcome..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs focus:ring-2 focus:ring-[#1B4D3E]"
                />
              </div>

              {/* Location & GPS */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-slate-700">Site Location Name & GPS Coordinates</label>
                  <button
                    type="button"
                    onClick={handleDetectGPS}
                    className="text-emerald-800 font-bold hover:underline flex items-center gap-1 text-[11px]"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    {isDetectingGps ? 'Detecting Location...' : 'Auto-Detect GPS'}
                  </button>
                </div>

                <input
                  type="text"
                  placeholder="e.g. Brusubi Phase 2 Villa, West Coast Region"
                  value={locationName}
                  onChange={(e) => setLocationName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                />

                {gpsCoordinates && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2 text-[10px] text-emerald-900 font-mono flex items-center justify-between">
                    <span>GPS Tag: {gpsCoordinates.formatted}</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                  </div>
                )}
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2 rounded-xl text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold px-5 py-2 rounded-xl text-xs shadow-md"
                >
                  Save Multimedia Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Lightbox Preview Modal */}
      {activePreview && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-slate-700">
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold font-serif text-amber-300">{activePreview.title}</h3>
                <p className="text-[10px] text-slate-400">{activePreview.locationName}</p>
              </div>
              <button onClick={() => setActivePreview(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-950 p-4 flex justify-center max-h-[400px]">
              <img
                src={activePreview.mediaUrl}
                alt={activePreview.title}
                className="max-h-[360px] object-contain rounded-xl border border-slate-800 shadow-xl"
              />
            </div>

            <div className="p-4 bg-white text-xs space-y-2">
              <p className="text-slate-700 font-medium">{activePreview.description || 'No notes attached.'}</p>
              <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                <span>Uploaded by: <strong>{activePreview.uploadedBy}</strong> ({activePreview.uploadedByRole})</span>
                <span className="font-mono">{new Date(activePreview.capturedAt).toLocaleString('en-GB')}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
