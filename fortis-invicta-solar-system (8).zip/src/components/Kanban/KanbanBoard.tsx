import React, { useState } from 'react';
import {
  Kanban as KanbanIcon,
  Filter,
  Plus,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Clock,
  Wrench,
  AlertCircle
} from 'lucide-react';
import { Client, ProjectStage, Currency } from '../../types';
import { formatCurrency, getStageLabel, getSegmentBadge, getPaymentStatusBadge } from '../../utils/formatters';

interface KanbanBoardProps {
  clients: Client[];
  currency: Currency;
  onUpdateStage: (clientId: string, newStage: ProjectStage) => void;
  onSelectClient: (client: Client) => void;
  onNewClient: () => void;
}

export const KanbanBoard: React.FC<KanbanBoardProps> = ({
  clients,
  currency,
  onUpdateStage,
  onSelectClient,
  onNewClient
}) => {
  const [segmentFilter, setSegmentFilter] = useState<string>('all');

  const stages: { key: ProjectStage; title: string; color: string }[] = [
    { key: 'lead', title: '1. Lead', color: 'border-slate-300 bg-slate-50' },
    { key: 'assessment_scheduled', title: '2. Assessment Scheduled', color: 'border-blue-300 bg-blue-50/50' },
    { key: 'assessment_complete', title: '3. Assessment Complete', color: 'border-indigo-300 bg-indigo-50/50' },
    { key: 'payment_pending', title: '4. Payment Pending', color: 'border-amber-300 bg-amber-50/50' },
    { key: 'installation_scheduled', title: '5. Install Scheduled', color: 'border-cyan-300 bg-cyan-50/50' },
    { key: 'installation_in_progress', title: '6. Install In Progress', color: 'border-purple-300 bg-purple-50/50' },
    { key: 'commissioning', title: '7. Commissioning', color: 'border-orange-300 bg-orange-50/50' },
    { key: 'completed', title: '8. Completed', color: 'border-emerald-300 bg-emerald-50/50' }
  ];

  const filteredClients = clients.filter(
    (c) => segmentFilter === 'all' || c.clientSegment === segmentFilter
  );

  const getStageNext = (current: ProjectStage): ProjectStage | null => {
    const idx = stages.findIndex((s) => s.key === current);
    if (idx >= 0 && idx < stages.length - 1) {
      return stages[idx + 1].key;
    }
    return null;
  };

  const getStagePrev = (current: ProjectStage): ProjectStage | null => {
    const idx = stages.findIndex((s) => s.key === current);
    if (idx > 0) {
      return stages[idx - 1].key;
    }
    return null;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Kanban Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 font-serif">Solar Project Lifecycle Kanban (8 Stages)</h1>
          <p className="text-xs text-slate-500">Track and manage project stage transitions from lead generation to commissioning</p>
        </div>

        <div className="flex items-center gap-3">
          {/* Segment Filter */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={segmentFilter}
              onChange={(e) => setSegmentFilter(e.target.value)}
              className="bg-transparent font-medium text-slate-700 focus:outline-none"
            >
              <option value="all">All Segments ({clients.length})</option>
              <option value="gtuccu_member">GTUCCU Members</option>
              <option value="nagnmc_member">NAGNMC Healthcare</option>
              <option value="diaspora">Diaspora Clients</option>
              <option value="non_union_individual">Non-Union Individuals</option>
            </select>
          </div>

          <button
            onClick={onNewClient}
            className="flex items-center gap-1.5 bg-[#1B4D3E] hover:bg-[#143B2F] text-white font-semibold text-xs px-3.5 py-2 rounded-xl shadow-sm transition-all"
          >
            <Plus className="w-4 h-4 text-amber-300" />
            <span>Add Lead</span>
          </button>
        </div>
      </div>

      {/* 8-Stage Kanban Columns */}
      <div className="overflow-x-auto pb-6">
        <div className="flex gap-4 min-w-[1600px] items-start">
          {stages.map((col) => {
            const colClients = filteredClients.filter((c) => c.projectStage === col.key);

            return (
              <div
                key={col.key}
                className={`w-[230px] flex-shrink-0 rounded-2xl border p-3 min-h-[500px] flex flex-col ${col.color}`}
              >
                {/* Column Title Header */}
                <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-200/80">
                  <span className="font-bold text-xs text-slate-800">{col.title}</span>
                  <span className="bg-white text-slate-800 font-extrabold text-[11px] px-2 py-0.5 rounded-full border border-slate-200">
                    {colClients.length}
                  </span>
                </div>

                {/* Cards List */}
                <div className="space-y-3 flex-1">
                  {colClients.map((client) => {
                    const segBadge = getSegmentBadge(client.clientSegment);
                    const payBadge = getPaymentStatusBadge(client.paymentStatus);
                    const nextStage = getStageNext(client.projectStage);
                    const prevStage = getStagePrev(client.projectStage);

                    return (
                      <div
                        key={client.id}
                        className="bg-white rounded-xl p-3 border border-slate-200 shadow-sm hover:shadow-md transition-shadow space-y-2 text-xs"
                      >
                        <div className="flex justify-between items-start gap-1">
                          <button
                            onClick={() => onSelectClient(client)}
                            className="font-bold text-slate-900 hover:text-[#1B4D3E] text-left leading-snug"
                          >
                            {client.fullName}
                          </button>
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${segBadge.color}`}>
                            {segBadge.label.split(' ')[0]}
                          </span>
                        </div>

                        <div className="text-[10px] text-slate-500 font-medium capitalize">
                          {client.packageId.replace('_', ' ')}
                        </div>

                        <div className="text-[11px] font-bold text-slate-900">
                          {formatCurrency(client.totalQuotedGMD, currency)}
                        </div>

                        <div className="flex items-center justify-between text-[10px] pt-1 border-t border-slate-100">
                          <span className={`px-1.5 py-0.5 rounded font-bold ${payBadge.color}`}>
                            {payBadge.label.split(' ')[0]}
                          </span>
                          <button
                            onClick={() => onSelectClient(client)}
                            className="text-[#1B4D3E] font-semibold hover:underline text-[10px]"
                          >
                            View
                          </button>
                        </div>

                        {/* Stage Transition Quick Action */}
                        <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-[10px]">
                          {prevStage ? (
                            <button
                              onClick={() => onUpdateStage(client.id, prevStage)}
                              title={`Move back to ${getStageLabel(prevStage)}`}
                              className="p-1 text-slate-400 hover:text-slate-700 bg-slate-50 rounded"
                            >
                              <ArrowLeft className="w-3 h-3" />
                            </button>
                          ) : (
                            <div />
                          )}

                          {nextStage && (
                            <button
                              onClick={() => onUpdateStage(client.id, nextStage)}
                              className="flex items-center gap-1 text-[10px] font-bold text-emerald-700 hover:text-emerald-900 bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded transition-colors"
                            >
                              <span>Next Stage</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}

                  {colClients.length === 0 && (
                    <div className="text-center py-8 text-[11px] text-slate-400 border border-dashed border-slate-200 rounded-xl">
                      No clients in this stage
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
