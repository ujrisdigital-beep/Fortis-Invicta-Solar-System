import React, { useState, useEffect } from 'react';
import { FortisLogo } from './FortisLogo';
import { useAuth } from '../services/authContext';
import { AuthModal } from './Auth/AuthModal';
import { FORTIS_COMPANY_INFO } from '../data/companyConfig';
import { BackgroundSync, SyncState } from '../services/backgroundSync';
import {
  Sun,
  ShieldCheck,
  LayoutDashboard,
  Users,
  Kanban,
  CreditCard,
  Building2,
  ClipboardCheck,
  Wrench,
  BarChart3,
  UserCheck,
  UserPlus,
  Sparkles,
  CreditCard as BankIcon,
  ChevronDown,
  Calculator,
  Bot,
  TrendingUp,
  LogIn,
  LogOut,
  ShieldAlert,
  Phone,
  Mail,
  MapPin,
  X,
  Wifi,
  WifiOff,
  RefreshCw,
  CheckCircle2,
  Cloud
} from 'lucide-react';
import { Currency, UserRole } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  currentRole: UserRole;
  setCurrentRole: (r: UserRole) => void;
  onOpenAIAssistant: () => void;
  pendingPaymentCount: number;
  isGdprActive?: boolean;
  setIsGdprActive?: (active: boolean) => void;
  selectedUnionId?: string;
  setSelectedUnionId?: (unionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currency,
  setCurrency,
  currentRole,
  setCurrentRole,
  onOpenAIAssistant,
  pendingPaymentCount,
  isGdprActive = true,
  setIsGdprActive,
  selectedUnionId = 'GTUCCU',
  setSelectedUnionId
}) => {
  const { user, isAuthenticated, logout } = useAuth();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isManualSyncing, setIsManualSyncing] = useState(false);

  const [syncInfo, setSyncInfo] = useState<{
    isOnline: boolean;
    syncState: SyncState;
    unsyncedCount: number;
    lastSyncTime?: string;
  }>({
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    syncState: 'idle',
    unsyncedCount: 0
  });

  useEffect(() => {
    const unsubscribe = BackgroundSync.subscribe((state) => {
      setSyncInfo(state);
    });
    return () => unsubscribe();
  }, []);

  const handleTriggerManualSync = async () => {
    setIsManualSyncing(true);
    try {
      await BackgroundSync.syncPendingData();
    } catch (err) {
      console.warn('Manual sync error:', err);
    } finally {
      setIsManualSyncing(false);
    }
  };

  const roles: { value: UserRole; label: string }[] = [
    { value: 'super_admin', label: 'Super Admin' },
    { value: 'project_manager', label: 'Project Manager' },
    { value: 'finance_officer', label: 'Finance Officer' },
    { value: 'site_inspector', label: 'Site Inspector' },
    { value: 'installer', label: 'Field Installer' },
    { value: 'institutional_admin', label: 'Institutional Admin (GTUCCU/NAGNMC)' },
    { value: 'client', label: 'Client View' }
  ];

  // RBAC Tab Access Rules
  const isTabAllowedForRole = (tabId: string): boolean => {
    if (tabId === 'forex_settings') {
      return ['super_admin', 'project_manager', 'finance_officer'].includes(currentRole);
    }
    if (currentRole === 'super_admin' || currentRole === 'project_manager') return true;

    switch (currentRole) {
      case 'site_inspector':
        return ['dashboard', 'assessment', 'multimedia', 'clients', 'calculator'].includes(tabId);
      case 'installer':
        return ['dashboard', 'installation', 'multimedia', 'clients', 'calculator'].includes(tabId);
      case 'finance_officer':
        return ['dashboard', 'payments', 'calculator', 'clients', 'reports'].includes(tabId);
      case 'institutional_admin':
        return ['dashboard', 'institutional', 'clients', 'reports', 'calculator'].includes(tabId);
      case 'client':
        return ['client_portal', 'calculator', 'onboarding'].includes(tabId);
      default:
        return true;
    }
  };

  return (
    <header className="bg-[#12241D] text-white border-b border-[#1B4D3E] sticky top-0 z-40 shadow-lg">
      {/* Top Banner: Merchant Credentials, GDPR Shield & Union Scope */}
      <div className="bg-[#1B4D3E] px-4 py-1.5 text-xs text-emerald-100 flex flex-wrap justify-between items-center border-b border-emerald-900/50">
        <div className="flex items-center gap-4 flex-wrap">
          <span className="flex items-center gap-1.5 font-medium text-amber-300">
            <BankIcon className="w-3.5 h-3.5" />
            EcobankPay Active
          </span>
          <span className="hidden sm:inline-block text-emerald-300/80">•</span>
          <span>Merchant Code: <strong className="text-white font-mono">505825057</strong></span>
          
          {/* GDPR Privacy Mode Shield Toggle */}
          {setIsGdprActive && (
            <button
              onClick={() => setIsGdprActive(!isGdprActive)}
              title="Toggle GDPR Personal Identifiable Information (PII) Redaction"
              className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold border transition-all cursor-pointer ${
                isGdprActive
                  ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-sm'
                  : 'bg-slate-800 text-slate-300 border-slate-600'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-slate-950" />
              <span>GDPR Privacy Mode: {isGdprActive ? 'ON (PII Masked)' : 'OFF'}</span>
            </button>
          )}
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          {/* Designated Union Admin Scope Selector */}
          {currentRole === 'institutional_admin' && setSelectedUnionId && (
            <div className="flex items-center gap-1 bg-[#12241D] border border-amber-400/60 px-2 py-0.5 rounded text-[11px]">
              <span className="text-amber-300 font-bold uppercase">Designated Union:</span>
              <select
                value={selectedUnionId}
                onChange={(e) => setSelectedUnionId(e.target.value)}
                className="bg-transparent text-amber-200 font-bold focus:outline-none cursor-pointer"
              >
                <option value="GTUCCU" className="bg-[#12241D]">Gambia Teachers Union (GTUCCU)</option>
                <option value="NAGNMC" className="bg-[#12241D]">Nurses & Midwives Union (NAGNMC)</option>
                <option value="GAMPOST" className="bg-[#12241D]">Gambia Post Office Union (GAMPOST)</option>
                <option value="GAMTEL" className="bg-[#12241D]">Gamtel/Gamcel Union (GAMTEL)</option>
                <option value="NAWEC_STAFF" className="bg-[#12241D]">NAWEC Staff Credit Union</option>
              </select>
            </div>
          )}

          <span className="bg-emerald-900/80 text-emerald-300 px-2 py-0.5 rounded text-[11px] border border-emerald-700">
            RBAC Active: <strong className="uppercase text-amber-300">{currentRole.replace('_', ' ')}</strong>
          </span>
          <button
            onClick={() => setIsContactModalOpen(true)}
            title="View Official Fortis Invicta Command HQ Contact Info"
            className="flex items-center gap-1.5 text-amber-300 hover:text-amber-200 bg-amber-950/60 hover:bg-amber-900/80 border border-amber-500/50 px-2 py-0.5 rounded text-[11px] font-semibold transition-all cursor-pointer shadow-sm"
          >
            <MapPin className="w-3 h-3 text-amber-400" />
            <span>Command HQ Info</span>
          </button>
        </div>
      </div>

      {/* Main Navbar Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Brand Logo */}
        <div
          onClick={() => setActiveTab('dashboard')}
          className="cursor-pointer group hover:scale-[1.02] transition-transform"
        >
          <FortisLogo size="md" theme="dark" showText={true} />
        </div>

        {/* Action Controls: Role Switcher, Currency Toggle, AI Assistant */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Currency Switcher */}
          <div className="flex bg-[#1B4D3E]/80 rounded-lg p-0.5 border border-emerald-800 text-xs">
            {(['GMD', 'USD', 'GBP'] as Currency[]).map((curr) => (
              <button
                key={curr}
                onClick={() => setCurrency(curr)}
                className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                  currency === curr
                    ? 'bg-[#C9A84C] text-[#12241D] shadow-sm'
                    : 'text-emerald-200 hover:text-white'
                }`}
              >
                {curr}
              </button>
            ))}
          </div>

          {/* Role Switcher */}
          <div className="relative">
            <div className="flex items-center gap-1.5 bg-[#1B4D3E] hover:bg-[#236350] border border-emerald-700/60 rounded-lg px-2.5 py-1.5 text-xs text-emerald-100 cursor-pointer">
              <span className="text-emerald-400 text-[10px] uppercase font-bold tracking-wider">Role:</span>
              <select
                value={currentRole}
                onChange={(e) => setCurrentRole(e.target.value as UserRole)}
                className="bg-transparent text-white font-medium focus:outline-none cursor-pointer pr-1"
              >
                {roles.map((r) => (
                  <option key={r.value} value={r.value} className="bg-[#12241D] text-white">
                    {r.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Sync Status Indicator Pill */}
          <button
            onClick={() => setIsSyncModalOpen(true)}
            title="Click to view offline storage and sync status"
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer shadow-sm ${
              !syncInfo.isOnline
                ? 'bg-amber-950/80 text-amber-300 border-amber-500/60 animate-pulse'
                : syncInfo.syncState === 'syncing' || isManualSyncing
                ? 'bg-blue-950/80 text-blue-300 border-blue-500/60'
                : syncInfo.unsyncedCount > 0
                ? 'bg-amber-900/60 text-amber-200 border-amber-500/40'
                : 'bg-[#152B23] text-emerald-300 border-emerald-700/60 hover:bg-[#1B4D3E]'
            }`}
          >
            {!syncInfo.isOnline ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Offline</span>
                {syncInfo.unsyncedCount > 0 && (
                  <span className="bg-amber-500 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                    {syncInfo.unsyncedCount}
                  </span>
                )}
              </>
            ) : syncInfo.syncState === 'syncing' || isManualSyncing ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 text-blue-400 animate-spin" />
                <span className="hidden sm:inline">Syncing...</span>
              </>
            ) : (
              <>
                <Cloud className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Synced</span>
                {syncInfo.unsyncedCount > 0 && (
                  <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                    {syncInfo.unsyncedCount}
                  </span>
                )}
              </>
            )}
          </button>

          {/* Authentication Status / Login Button */}
          {isAuthenticated && user ? (
            <div className="flex items-center gap-2.5 bg-[#152B23] border border-amber-500/40 rounded-xl px-3 py-1.5 text-xs shadow-inner">
              <div className="text-right">
                <div className="flex items-center justify-end gap-1.5">
                  <p className="text-[11px] font-bold text-white leading-tight">{user.fullName}</p>
                  <span className="text-[9px] font-black text-amber-300 bg-amber-950/80 border border-amber-500/40 px-1.5 py-0.2 rounded uppercase">
                    {user.role.replace('_', ' ')}
                  </span>
                </div>
                <p className="text-[10px] font-mono text-emerald-300/90 leading-tight mt-0.5">{user.email}</p>
              </div>
              <button
                onClick={logout}
                title="Sign Out"
                className="p-1.5 text-slate-400 hover:text-rose-300 hover:bg-rose-950/50 rounded-lg transition cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="flex items-center gap-1.5 bg-[#1B4D3E] hover:bg-[#236350] text-amber-300 border border-amber-500/40 font-bold px-3 py-1.5 rounded-lg text-xs transition cursor-pointer shadow-sm"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Portal Login</span>
            </button>
          )}

          {/* FORTIS AI Assistant Button */}
          <button
            onClick={onOpenAIAssistant}
            className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold px-3 py-1.5 rounded-lg text-xs shadow-md transition-all transform active:scale-95 cursor-pointer"
          >
            <Bot className="w-3.5 h-3.5 fill-current" />
            <span>FORTIS AI Assistant</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <nav className="bg-[#0D1A15] border-t border-emerald-900/60 px-4">
        <div className="max-w-7xl mx-auto flex items-center gap-1 overflow-x-auto py-1 scrollbar-none text-xs">
          {isTabAllowedForRole('dashboard') && (
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 text-amber-400" />
              <span>Dashboard</span>
            </button>
          )}

          {isTabAllowedForRole('calculator') && (
            <button
              onClick={() => setActiveTab('calculator')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'calculator'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <Calculator className="w-4 h-4 text-amber-400" />
              <span>Price Calculator & Schedule</span>
            </button>
          )}

          {isTabAllowedForRole('clients') && (
            <button
              onClick={() => setActiveTab('clients')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'clients'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <Users className="w-4 h-4 text-emerald-400" />
              <span>Client Registry</span>
            </button>
          )}

          {isTabAllowedForRole('kanban') && (
            <button
              onClick={() => setActiveTab('kanban')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'kanban'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <Kanban className="w-4 h-4 text-cyan-400" />
              <span>Project Kanban (8 Stages)</span>
            </button>
          )}

          {isTabAllowedForRole('payments') && (
            <button
              onClick={() => setActiveTab('payments')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors relative cursor-pointer ${
                activeTab === 'payments'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <CreditCard className="w-4 h-4 text-amber-400" />
              <span>Ecobank Payments</span>
              {pendingPaymentCount > 0 && (
                <span className="bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full animate-pulse">
                  {pendingPaymentCount}
                </span>
              )}
            </button>
          )}

          {isTabAllowedForRole('institutional') && (
            <button
              onClick={() => setActiveTab('institutional')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'institutional'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <Building2 className="w-4 h-4 text-teal-400" />
              <span>Institutional Unions</span>
            </button>
          )}

          {isTabAllowedForRole('multimedia') && (
            <button
              onClick={() => setActiveTab('multimedia')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'multimedia'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Multimedia Vault</span>
            </button>
          )}

          {isTabAllowedForRole('assessment') && (
            <button
              onClick={() => setActiveTab('assessment')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'assessment'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <ClipboardCheck className="w-4 h-4 text-indigo-400" />
              <span>Site Inspector Hub</span>
            </button>
          )}

          {isTabAllowedForRole('installation') && (
            <button
              onClick={() => setActiveTab('installation')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'installation'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <Wrench className="w-4 h-4 text-purple-400" />
              <span>Installer Hub</span>
            </button>
          )}

          {isTabAllowedForRole('reports') && (
            <button
              onClick={() => setActiveTab('reports')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'reports'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-rose-400" />
              <span>Reports & Exports</span>
            </button>
          )}

          {isTabAllowedForRole('forex_settings') && (
            <button
              onClick={() => setActiveTab('forex_settings')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'forex_settings'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <TrendingUp className="w-4 h-4 text-amber-300" />
              <span>Forex & Inflation</span>
            </button>
          )}

          {isTabAllowedForRole('client_portal') && (
            <button
              onClick={() => setActiveTab('client_portal')}
              className={`flex items-center gap-2 px-3 py-2 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'client_portal'
                  ? 'bg-[#1B4D3E] text-amber-300 font-semibold border-b-2 border-[#C9A84C]'
                  : 'text-emerald-300/80 hover:text-white hover:bg-[#12241D]'
              }`}
            >
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <span>Client Tracker Portal</span>
            </button>
          )}

          {isTabAllowedForRole('onboarding') && (
            <button
              onClick={() => setActiveTab('onboarding')}
              className="flex items-center gap-1.5 ml-auto bg-[#C9A84C] hover:bg-amber-400 text-slate-950 font-bold px-3 py-1.5 rounded-md text-xs transition-colors shadow-sm whitespace-nowrap cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Public Onboarding Link</span>
            </button>
          )}
        </div>
      </nav>

      {/* Authentication & Access Modal */}
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />

      {/* Fortis Invicta Command HQ Contact Info Modal */}
      {isContactModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-800/80 rounded-2xl max-w-md w-full p-6 shadow-2xl relative text-left text-white animate-in fade-in zoom-in-95 duration-150">
            <button
              onClick={() => setIsContactModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-800 pb-4 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#1B4D3E] border border-amber-400/40 flex items-center justify-center font-bold text-amber-300 font-serif shadow-inner">
                FI
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-serif">{FORTIS_COMPANY_INFO.fullTitle}</h3>
                <p className="text-xs text-emerald-400 font-medium">Official Corporate & Field Operations Headquarters</p>
              </div>
            </div>

            <div className="space-y-3.5 text-xs">
              <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-200">Physical Address</div>
                  <div className="text-slate-300 font-medium">{FORTIS_COMPANY_INFO.address}</div>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-200">Phone / WhatsApp (Direct)</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <a
                      href={`https://wa.me/${FORTIS_COMPANY_INFO.whatsAppClean}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-400 hover:text-emerald-300 font-mono font-bold hover:underline"
                    >
                      {FORTIS_COMPANY_INFO.phoneWhatsApp}
                    </a>
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-700 font-semibold">
                      WhatsApp Live
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <Mail className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-200">Official Inquiries & Support Email</div>
                  <a
                    href={`mailto:${FORTIS_COMPANY_INFO.email}`}
                    className="text-amber-300 hover:text-amber-200 font-mono font-semibold hover:underline mt-0.5 block"
                  >
                    {FORTIS_COMPANY_INFO.email}
                  </a>
                </div>
              </div>

              <div className="bg-[#12241D] border border-emerald-800/80 p-3 rounded-xl text-[11px] text-slate-300 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Ecobank Merchant Code:</span>
                  <strong className="text-amber-300 font-mono">{FORTIS_COMPANY_INFO.merchantCode}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Terminal ID:</span>
                  <strong className="text-white font-mono">{FORTIS_COMPANY_INFO.terminalId}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Company Registration:</span>
                  <strong className="text-slate-200 font-mono">{FORTIS_COMPANY_INFO.registrationNumber}</strong>
                </div>
              </div>
            </div>

            <div className="mt-5 flex gap-2">
              <a
                href={`https://wa.me/${FORTIS_COMPANY_INFO.whatsAppClean}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-3 rounded-xl text-center text-xs transition-colors flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Chat on WhatsApp</span>
              </a>
              <button
                onClick={() => setIsContactModalOpen(false)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold py-2.5 px-4 rounded-xl text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sync Status & Offline Persistence Modal */}
      {isSyncModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-800/80 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-950 border border-emerald-700 text-emerald-400">
                  <Cloud className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">Local-First Sync Status</h3>
                  <p className="text-[11px] text-emerald-400">Rural Gambia Offline-First Engine</p>
                </div>
              </div>
              <button
                onClick={() => setIsSyncModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {/* Connection Status Card */}
              <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  {syncInfo.isOnline ? (
                    <Wifi className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <WifiOff className="w-4 h-4 text-amber-400" />
                  )}
                  <div>
                    <div className="font-bold text-slate-200">Network Connectivity</div>
                    <div className="text-[11px] text-slate-400">
                      {syncInfo.isOnline ? 'Online (GSM / Wi-Fi Active)' : 'Offline (No Connection)'}
                    </div>
                  </div>
                </div>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase border ${
                    syncInfo.isOnline
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-600'
                      : 'bg-amber-950 text-amber-300 border-amber-600'
                  }`}
                >
                  {syncInfo.isOnline ? 'ONLINE' : 'OFFLINE'}
                </span>
              </div>

              {/* IndexedDB Cache Card */}
              <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200">Offline Site Assessments Queue</span>
                  <span className="font-mono font-bold text-amber-300">
                    {syncInfo.unsyncedCount} Pending Sync
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Assessments taken in remote locations without cellular reception are safely stored in browser IndexedDB and automatically synchronized when connection is re-established.
                </p>
                {syncInfo.lastSyncTime && (
                  <div className="text-[10px] text-emerald-400/90 font-mono pt-1 border-t border-slate-700/60">
                    Last Successful Sync: {syncInfo.lastSyncTime}
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={handleTriggerManualSync}
                disabled={isManualSyncing || !syncInfo.isOnline}
                className="flex-1 bg-[#1B4D3E] hover:bg-[#236350] text-amber-300 font-bold py-2.5 px-4 rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isManualSyncing ? 'animate-spin' : ''}`} />
                <span>{isManualSyncing ? 'Synchronizing...' : 'Force Sync Now'}</span>
              </button>
              <button
                type="button"
                onClick={() => setIsSyncModalOpen(false)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold py-2.5 px-4 rounded-xl text-xs transition cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
