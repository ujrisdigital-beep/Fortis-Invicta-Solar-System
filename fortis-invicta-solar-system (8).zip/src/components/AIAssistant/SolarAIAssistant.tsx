import React, { useState } from 'react';
import { X, Sparkles, Send, Bot, User, Sun, ShieldCheck, Calculator, UserPlus, CreditCard, Kanban, BarChart3, ArrowRight } from 'lucide-react';
import { FortisLogo } from '../FortisLogo';

interface SolarAIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab?: (tab: string) => void;
}

export const SolarAIAssistant: React.FC<SolarAIAssistantProps> = ({ isOpen, onClose, onNavigateTab }) => {
  if (!isOpen) return null;

  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string }>>([
    {
      sender: 'ai',
      text: `Greetings! I am **FORTIS**, your Lead AI Platform Administrator & Solar Systems Consultant for **FORTIS INVICTA LTD**.

I am fully empowered to answer all questions, perform technical solar sizing, and help administer the platform:

• **Platform Administration**: Onboard clients, navigate pipeline stages, verify Ecobank transfers (Merchant **505825057**), and audit system activities.
• **Solar Technical Sizing**: Calculate inverter capacities, lithium/gel battery banks, and solar array specs for any compound or commercial building in The Gambia.
• **Qualifying Period Financing**: Model 24-month salary deduction schedules for **GTUCCU** Teachers and **NAGNMC** Medical Council members.

How may I administer the platform or calculate solar requirements for you today?`
    }
  ]);
  const [loading, setLoading] = useState(false);

  const adminShortcuts = [
    { label: 'Onboard New Client', tab: 'onboarding', icon: UserPlus, color: 'bg-emerald-700 text-white' },
    { label: 'Repayment Calculator', tab: 'calculator', icon: Calculator, color: 'bg-amber-600 text-white' },
    { label: 'Ecobank Payments', tab: 'payments', icon: CreditCard, color: 'bg-[#1B4D3E] text-white' },
    { label: 'Project Kanban', tab: 'kanban', icon: Kanban, color: 'bg-purple-700 text-white' },
    { label: 'Reports & Exports', tab: 'reports', icon: BarChart3, color: 'bg-slate-800 text-white' }
  ];

  const quickPrompts = [
    'Calculate 3.5KVA Lithium System for 4-bedroom compound in Brusubi',
    'How does GTUCCU 24-month salary deduction work?',
    'What are the Ecobank Merchant Code 505825057 payment instructions?',
    'Show me the qualifying monthly repayment formula with 5% union fee'
  ];

  const handleAdminNavigate = (tab: string, label: string) => {
    if (onNavigateTab) {
      onNavigateTab(tab);
      onClose();
    }
  };

  const handleSend = async (userText?: string) => {
    const textToSend = userText || prompt;
    if (!textToSend.trim() || loading) return;

    const newMessages = [...messages, { sender: 'user' as const, text: textToSend }];
    setMessages(newMessages);
    setPrompt('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: textToSend })
      });
      const data = await res.json();
      setMessages([...newMessages, { sender: 'ai', text: data.reply || 'FORTIS AI Assistant ready.' }]);
    } catch {
      setMessages([
        ...newMessages,
        {
          sender: 'ai',
          text: `[FORTIS AI Assistant]: Here is the recommended configuration based on your query:
• **Solar Package**: Hybrid Standard System (3.5KVA Pure Sine Inverter, 6 x 550W Tier-1 Panels, 4 x 200Ah Gel / 5kWh Lithium).
• **Estimated Price Range**: GMD 280,000 - GMD 360,000.
• **GTUCCU / NAGNMC Monthly Repayment**: ~GMD 12,600 / month over 24 Months.
• **Ecobank Direct Transfer**: Merchant Code **505825057**, Terminal ID **32680928**.`
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col h-[650px]">
        {/* Header */}
        <div className="bg-[#12241D] text-white p-4 border-b border-[#1B4D3E] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <FortisLogo size="sm" theme="dark" showText={false} />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold font-serif text-white">FORTIS AI ASSISTANT</h2>
                <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                  Lead Admin Bot
                </span>
              </div>
              <p className="text-[11px] text-emerald-300">
                Fortis Invicta Platform Administrator & Solar Technical Copilot
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#1B4D3E] text-white flex items-center justify-center hover:bg-[#236350] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Administrative Quick Command Bar */}
        <div className="bg-slate-900 text-slate-200 p-2.5 border-b border-slate-800 flex items-center gap-2 overflow-x-auto text-[11px] scrollbar-none">
          <span className="text-amber-400 font-bold uppercase text-[10px] tracking-wider shrink-0 px-1">
            Admin Actions:
          </span>
          {adminShortcuts.map((sc, idx) => {
            const Icon = sc.icon;
            return (
              <button
                key={idx}
                onClick={() => handleAdminNavigate(sc.tab, sc.label)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-bold shadow-sm whitespace-nowrap hover:opacity-90 transition-opacity ${sc.color}`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{sc.label}</span>
              </button>
            );
          })}
        </div>

        {/* Quick Question Chips */}
        <div className="bg-slate-50 p-2.5 border-b border-slate-200 flex items-center gap-2 overflow-x-auto text-[11px]">
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(qp)}
              className="bg-white hover:bg-slate-100 text-slate-700 font-medium px-2.5 py-1 rounded-lg border border-slate-200 whitespace-nowrap"
            >
              {qp}
            </button>
          ))}
        </div>

        {/* Messages Body */}
        <div className="p-4 flex-1 overflow-y-auto space-y-4 text-xs bg-slate-50/50">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'ai' && (
                <div className="w-8 h-8 rounded-xl bg-[#12241D] text-amber-300 border border-amber-500/40 flex items-center justify-center font-bold flex-shrink-0 mt-0.5 shadow-md">
                  <Bot className="w-4 h-4 text-amber-400" />
                </div>
              )}
              <div
                className={`p-4 rounded-2xl max-w-[82%] leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-[#1B4D3E] text-white font-medium shadow-md'
                    : 'bg-white text-slate-800 border border-slate-200/90 shadow-sm'
                }`}
              >
                <div className="whitespace-pre-wrap">{m.text}</div>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex items-center gap-2 text-xs text-emerald-800 italic font-medium p-2 bg-emerald-50 rounded-xl border border-emerald-200 w-fit">
              <Sparkles className="w-4 h-4 text-amber-500 animate-spin" />
              <span>FORTIS AI Assistant is processing administrative request...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
          <input
            type="text"
            placeholder="Ask FORTIS anything about solar load calculations, GTUCCU financing, or platform commands..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-[#1B4D3E]"
          />
          <button
            onClick={() => handleSend()}
            className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold px-4 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-1.5"
          >
            <span>Ask FORTIS</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

