import React, { useState } from 'react';
import { DollarSign, TrendingUp, RefreshCw, Save, Check, Sparkles, ShieldCheck, AlertCircle } from 'lucide-react';
import { ForexInflationConfig, Currency, Client } from '../../types';
import { StorageService } from '../../services/storage';
import { formatCurrency } from '../../utils/formatters';

interface InflationForexPanelProps {
  currency: Currency;
  onConfigUpdated?: () => void;
}

export const InflationForexPanel: React.FC<InflationForexPanelProps> = ({
  currency,
  onConfigUpdated
}) => {
  const [config, setConfig] = useState<ForexInflationConfig>(() => StorageService.getForexConfig());
  const [usdRate, setUsdRate] = useState<number>(config.usdToGmdRate || 68.5);
  const [gbpRate, setGbpRate] = useState<number>(config.gbpToGmdRate || 85.0);
  const [inflationPercent, setInflationPercent] = useState<number>(config.globalInflationPercent || 5.0);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [recalculatedCount, setRecalculatedCount] = useState<number | null>(null);

  const handleSaveAndRecalculate = (e: React.FormEvent) => {
    e.preventDefault();

    const updatedConfig: ForexInflationConfig = {
      usdToGmdRate: usdRate,
      gbpToGmdRate: gbpRate,
      globalInflationPercent: inflationPercent,
      lastUpdated: new Date().toISOString(),
      updatedBy: 'Central Finance Admin'
    };

    StorageService.saveForexConfig(updatedConfig, 'Central Finance Admin');
    setConfig(updatedConfig);

    // Recalculate Active Client Quotes & Payment Schedules in Storage
    const allClients = StorageService.getClients();
    let updatedClientsCount = 0;

    allClients.forEach((client) => {
      // Apply inflation adjustment to active leads and pending payments
      if (client.projectStage === 'lead' || client.projectStage === 'assessment_scheduled' || client.paymentStatus === 'pending') {
        const baseQuote = client.customPackagePriceGMD || client.totalQuotedGMD;
        const newInflationAdjustment = Math.round(baseQuote * (inflationPercent / 100));
        const newTotalQuote = baseQuote + newInflationAdjustment;
        const newOutstanding = Math.max(0, newTotalQuote - client.totalPaidGMD);

        const updatedClient: Client = {
          ...client,
          totalQuotedGMD: newTotalQuote,
          outstandingBalanceGMD: newOutstanding,
          appliedInflationRate: inflationPercent,
          appliedForexRateUSD: usdRate,
          priceLockedAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };

        StorageService.saveClient(updatedClient);
        updatedClientsCount++;
      }
    });

    setRecalculatedCount(updatedClientsCount);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 4000);

    if (onConfigUpdated) onConfigUpdated();
  };

  return (
    <div className="bg-[#0F1E18] text-white rounded-3xl p-6 sm:p-8 border border-amber-500/30 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-800 pb-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              Financial Controls
            </span>
            <h2 className="text-xl sm:text-2xl font-bold font-serif text-amber-300">
              Inflation & Forex Index Adjustment Panel
            </h2>
          </div>
          <p className="text-xs text-emerald-200/90 max-w-2xl">
            Configure monthly foreign exchange conversion rates (USD/GBP to GMD) and inflation buffer multipliers. Automatically updates proposal quotes and active payment schedules.
          </p>
        </div>

        <div className="text-right text-xs text-emerald-200/80 font-mono bg-[#0A1612] p-3 rounded-2xl border border-emerald-800">
          <div>Last Index Lock: <strong>{new Date(config.lastUpdated).toLocaleDateString()}</strong></div>
          <div>Updated By: <strong>{config.updatedBy}</strong></div>
        </div>
      </div>

      {/* Form Controls */}
      <form onSubmit={handleSaveAndRecalculate} className="space-y-6 text-xs">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* USD Rate Input */}
          <div className="p-4 bg-[#12241D] rounded-2xl border border-emerald-800 space-y-2">
            <label className="block font-bold text-amber-300 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-amber-400" />
              1 USD to Dalasi (GMD) Rate
            </label>
            <input
              type="number"
              step="0.1"
              required
              value={usdRate}
              onChange={(e) => setUsdRate(Number(e.target.value))}
              className="w-full bg-[#0A1612] border border-emerald-700 p-3 rounded-xl font-mono text-base font-bold text-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <span className="text-[10px] text-emerald-300/70 block">Central Bank / Commercial FX Benchmark</span>
          </div>

          {/* GBP Rate Input */}
          <div className="p-4 bg-[#12241D] rounded-2xl border border-emerald-800 space-y-2">
            <label className="block font-bold text-amber-300 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-amber-400" />
              1 GBP to Dalasi (GMD) Rate
            </label>
            <input
              type="number"
              step="0.1"
              required
              value={gbpRate}
              onChange={(e) => setGbpRate(Number(e.target.value))}
              className="w-full bg-[#0A1612] border border-emerald-700 p-3 rounded-xl font-mono text-base font-bold text-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <span className="text-[10px] text-emerald-300/70 block">UK Diaspora Transfer Index Benchmark</span>
          </div>

          {/* Global Inflation Multiplier */}
          <div className="p-4 bg-[#12241D] rounded-2xl border border-emerald-800 space-y-2">
            <label className="block font-bold text-amber-300 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              Global Inflation Multiplier (%)
            </label>
            <input
              type="number"
              step="0.5"
              required
              value={inflationPercent}
              onChange={(e) => setInflationPercent(Number(e.target.value))}
              className="w-full bg-[#0A1612] border border-emerald-700 p-3 rounded-xl font-mono text-base font-bold text-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <span className="text-[10px] text-emerald-300/70 block">Component Import Buffer Multiplier</span>
          </div>
        </div>

        {/* Audit Notification Banner */}
        {recalculatedCount !== null && isSaved && (
          <div className="p-4 bg-emerald-950/90 border border-emerald-500/50 rounded-2xl text-emerald-200 flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <p className="font-bold text-amber-300 text-xs">Rates Saved & Schedules Recalculated!</p>
              <p className="text-[11px] text-emerald-200/90">
                Successfully updated proposal quotes & active payment schedules for <strong>{recalculatedCount} active client projects</strong>.
              </p>
            </div>
          </div>
        )}

        {/* Submit Actions */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <div className="flex items-center gap-2 text-emerald-200/80 text-[11px]">
            <AlertCircle className="w-4 h-4 text-amber-400" />
            <span>Updates active proposals without altering confirmed historical payments</span>
          </div>

          <button
            type="submit"
            className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-extrabold px-6 py-3 rounded-2xl shadow-xl flex items-center gap-2 text-xs transition-all cursor-pointer transform active:scale-95"
          >
            {isSaved ? <Check className="w-4 h-4 text-slate-950" /> : <RefreshCw className="w-4 h-4" />}
            <span>{isSaved ? 'Rates Applied' : 'Update Rates & Recalculate Active Schedules'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
