import React, { useState, useMemo } from 'react';
import {
  Zap,
  Cpu,
  Sun,
  Battery,
  ShieldAlert,
  Plus,
  Trash2,
  Sparkles,
  Bot,
  CheckCircle2,
  RotateCcw,
  ArrowRight,
  TrendingUp,
  Sliders,
  FileText
} from 'lucide-react';
import {
  LoadItem,
  PRESET_APPLIANCES,
  calculateSolarLoadRequirements,
  formatSolarEngineeringReport,
  SolarLoadAnalysisResult
} from '../../utils/solarCalculations';
import { Currency } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface SolarLoadCalculatorProps {
  currency: Currency;
  onApplyPlan?: (packageId: string, estimatedCost: number) => void;
}

export const SolarLoadCalculator: React.FC<SolarLoadCalculatorProps> = ({ currency, onApplyPlan }) => {
  const [loads, setLoads] = useState<LoadItem[]>(() =>
    PRESET_APPLIANCES.map((p, idx) => ({
      ...p,
      id: `load-${idx + 1}`
    }))
  );

  // Sizing parameters
  const [autonomyDays, setAutonomyDays] = useState<number>(1.0);
  const [batteryType, setBatteryType] = useState<'lifepo4' | 'gel_agm'>('lifepo4');
  const [powerFactor, setPowerFactor] = useState<number>(0.85);

  // Gemini AI narrative state
  const [aiNarrative, setAiNarrative] = useState<string | null>(null);
  const [isAiGenerating, setIsAiGenerating] = useState<boolean>(false);

  // New appliance input state
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState<LoadItem['category']>('custom');
  const [newWatts, setNewWatts] = useState(500);
  const [newQty, setNewQty] = useState(1);
  const [newSurge, setNewSurge] = useState(3.0);
  const [newHours, setNewHours] = useState(4);
  const [showAddForm, setShowAddForm] = useState(false);

  // Deterministic calculation result
  const analysisResult = useMemo<SolarLoadAnalysisResult>(() => {
    return calculateSolarLoadRequirements(loads, {
      autonomyDays,
      batteryType,
      powerFactor
    });
  }, [loads, autonomyDays, batteryType, powerFactor]);

  // Update item
  const updateLoadItem = (id: string, field: keyof LoadItem, value: any) => {
    setLoads((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return { ...item, [field]: value };
        }
        return item;
      })
    );
  };

  // Remove item
  const removeLoadItem = (id: string) => {
    setLoads((prev) => prev.filter((item) => item.id !== id));
  };

  // Add custom appliance
  const handleAddAppliance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const newItem: LoadItem = {
      id: `load-${Date.now()}`,
      name: newName.trim(),
      category: newCategory,
      nominalWatts: Number(newWatts),
      quantity: Number(newQty),
      surgeMultiplier: Number(newSurge),
      operatingHoursPerDay: Number(newHours),
      daytimeUsagePercent: 50
    };

    setLoads((prev) => [...prev, newItem]);
    setNewName('');
    setShowAddForm(false);
  };

  // Reset to default presets
  const handleResetPresets = () => {
    setLoads(
      PRESET_APPLIANCES.map((p, idx) => ({
        ...p,
        id: `load-${idx + 1}`
      }))
    );
    setAiNarrative(null);
  };

  // Request optional Gemini AI natural language client summary
  const handleGenerateAiSummary = async () => {
    setIsAiGenerating(true);
    const reportText = formatSolarEngineeringReport(analysisResult);

    try {
      const response = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Generate a concise executive engineering client consultation summary based on the following deterministic solar calculation data:\n\n${reportText}\n\nPlease highlight NAWEC grid backup reliability, inductive motor surge handling for pumps/machinery, and recommended Fortis Invicta package selection.`,
          context: analysisResult
        })
      });

      const data = await response.json();
      setAiNarrative(data.reply || reportText);
    } catch {
      setAiNarrative(reportText);
    } finally {
      setIsAiGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#12241D] via-[#1B4D3E] to-[#2A6E59] text-white rounded-3xl p-6 shadow-xl border border-emerald-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-amber-400 text-slate-950 text-[10px] font-black uppercase px-2.5 py-0.5 rounded tracking-wide">
              Deterministic Solar Sizing Engine
            </span>
            <span className="text-emerald-300 text-xs">IEEE / IEC Standard Compliance</span>
          </div>
          <h2 className="text-2xl font-bold font-serif">Solar Load & Inductive Motor Surge Sizer</h2>
          <p className="text-xs text-emerald-100/90 mt-1 max-w-2xl">
            Calculates continuous electrical demand, inductive startup surge peaks ($I_{'{surge}'} = 3\times - 6\times I_{'{nom}'}$ for pumps and biochar equipment), LiFePO4 battery banks, and solar array specs for Gambian solar insolation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleResetPresets}
            className="inline-flex items-center gap-1.5 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-200 text-xs font-semibold py-2 px-3.5 rounded-xl transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Standard Loads</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Loads Table & Live Engineering Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Appliance Inventory (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-900 font-serif flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-500" />
                  <span>Connected Electrical Load Inventory</span>
                </h3>
                <p className="text-xs text-slate-500">Configure appliances and motor surge multipliers</p>
              </div>

              <button
                onClick={() => setShowAddForm(!showAddForm)}
                className="inline-flex items-center gap-1.5 bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 text-xs font-bold py-1.5 px-3 rounded-xl transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Appliance</span>
              </button>
            </div>

            {/* Add Appliance Inline Form */}
            {showAddForm && (
              <form onSubmit={handleAddAppliance} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3 text-xs">
                <div className="font-bold text-slate-800">Add Equipment / Appliance</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-slate-600 font-medium mb-1">Equipment Name</label>
                    <input
                      type="text"
                      placeholder="e.g., 2HP Submersible Pump or Wood Chipper"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-medium mb-1">Category</label>
                    <select
                      value={newCategory}
                      onChange={(e) => {
                        const cat = e.target.value as LoadItem['category'];
                        setNewCategory(cat);
                        if (cat === 'agricultural_pump') setNewSurge(5.5);
                        else if (cat === 'biochar_processing') setNewSurge(6.0);
                        else if (cat === 'cooling_aircon') setNewSurge(4.0);
                        else if (cat === 'refrigeration') setNewSurge(3.2);
                        else setNewSurge(1.0);
                      }}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs font-medium"
                    >
                      <option value="lighting_electronic">Lighting / Electronics (1.0x)</option>
                      <option value="refrigeration">Refrigeration (3.0x - 3.5x)</option>
                      <option value="cooling_aircon">Air Conditioning (4.0x - 5.0x)</option>
                      <option value="agricultural_pump">Borehole Water Pump (5.0x - 6.0x)</option>
                      <option value="biochar_processing">Biochar / Heavy Motor (5.5x - 6.5x)</option>
                      <option value="custom">Custom Machinery</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-600 font-medium mb-1">Nominal Power (W)</label>
                    <input
                      type="number"
                      value={newWatts}
                      onChange={(e) => setNewWatts(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs"
                      min={1}
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-medium mb-1">Quantity</label>
                    <input
                      type="number"
                      value={newQty}
                      onChange={(e) => setNewQty(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs"
                      min={1}
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-medium mb-1">Startup Surge Multiplier</label>
                    <input
                      type="number"
                      step="0.1"
                      value={newSurge}
                      onChange={(e) => setNewSurge(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs"
                      min={1}
                      max={10}
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-medium mb-1">Hours / Day</label>
                    <input
                      type="number"
                      value={newHours}
                      onChange={(e) => setNewHours(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs"
                      min={1}
                      max={24}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-[#1B4D3E] text-amber-300 font-bold"
                  >
                    Add to Load Table
                  </button>
                </div>
              </form>
            )}

            {/* Loads Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100/80 text-slate-700 border-b border-slate-200">
                    <th className="p-2.5 font-bold">Appliance / Equipment</th>
                    <th className="p-2.5 font-bold">Nominal (W)</th>
                    <th className="p-2.5 font-bold">Qty</th>
                    <th className="p-2.5 font-bold">Surge Multiplier</th>
                    <th className="p-2.5 font-bold">Peak Surge (W)</th>
                    <th className="p-2.5 font-bold">Hours/Day</th>
                    <th className="p-2.5 font-bold text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {loads.map((item) => {
                    const peakWatts = Math.round(item.nominalWatts * item.surgeMultiplier);
                    const isHighSurge = item.surgeMultiplier >= 4.0;

                    return (
                      <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-2.5 font-medium text-slate-900">
                          <div className="flex items-center gap-1.5">
                            <span>{item.name}</span>
                            {isHighSurge && (
                              <span className="bg-rose-100 text-rose-800 text-[10px] font-black px-1.5 py-0.2 rounded">
                                Motor Surge
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            value={item.nominalWatts}
                            onChange={(e) => updateLoadItem(item.id, 'nominalWatts', Number(e.target.value))}
                            className="w-16 bg-slate-50 border border-slate-200 rounded p-1 text-xs"
                          />
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateLoadItem(item.id, 'quantity', Number(e.target.value))}
                            className="w-12 bg-slate-50 border border-slate-200 rounded p-1 text-xs"
                            min={1}
                          />
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            step="0.1"
                            value={item.surgeMultiplier}
                            onChange={(e) => updateLoadItem(item.id, 'surgeMultiplier', Number(e.target.value))}
                            className="w-14 bg-slate-50 border border-slate-200 rounded p-1 text-xs font-mono font-bold text-amber-700"
                            min={1}
                            max={10}
                          />
                        </td>
                        <td className="p-2.5 font-mono font-bold text-slate-800">
                          {peakWatts.toLocaleString()} W
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            value={item.operatingHoursPerDay}
                            onChange={(e) => updateLoadItem(item.id, 'operatingHoursPerDay', Number(e.target.value))}
                            className="w-12 bg-slate-50 border border-slate-200 rounded p-1 text-xs"
                            min={1}
                            max={24}
                          />
                        </td>
                        <td className="p-2.5 text-center">
                          <button
                            onClick={() => removeLoadItem(item.id)}
                            className="text-slate-400 hover:text-rose-600 p-1 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Environmental & Battery Sliders */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Night Autonomy Days</label>
                <select
                  value={autonomyDays}
                  onChange={(e) => setAutonomyDays(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs font-semibold"
                >
                  <option value={1.0}>1.0 Day (Standard NAWEC Backup)</option>
                  <option value={1.5}>1.5 Days (Heavy Outage Buffer)</option>
                  <option value={2.0}>2.0 Days (Off-Grid Rural Island)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Battery Technology</label>
                <select
                  value={batteryType}
                  onChange={(e) => setBatteryType(e.target.value as any)}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs font-semibold"
                >
                  <option value="lifepo4">Lithium LiFePO4 (85% Usable DoD)</option>
                  <option value="gel_agm">Deep Cycle GEL/AGM (50% Usable DoD)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">System Power Factor (cos φ)</label>
                <select
                  value={powerFactor}
                  onChange={(e) => setPowerFactor(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs font-semibold"
                >
                  <option value={0.85}>0.85 (Standard Mixed Inductive)</option>
                  <option value={0.80}>0.80 (Heavy Industrial Motors)</option>
                  <option value={0.95}>0.95 (Pure Resistive/Inverter ACs)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Deterministic Engineering Results & Gemini AI Consultation (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Sizing Card */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900 font-serif flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-emerald-700" />
                <span>Deterministic Sizing Results</span>
              </span>
              <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2 py-0.5 rounded-full">
                {analysisResult.recommendedPackageId.toUpperCase()}
              </span>
            </h3>

            {/* Motor Surge Warning Alert if detected */}
            {analysisResult.motorSurgeWarning && (
              <div className="bg-rose-50 border border-rose-200 text-rose-800 rounded-xl p-3 text-xs flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block font-bold">Inductive Motor Surge Alert</strong>
                  <span>{analysisResult.motorSurgeWarning}</span>
                </div>
              </div>
            )}

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-slate-500 block">Continuous Demand</span>
                <div className="text-lg font-bold text-slate-900 font-mono">
                  {analysisResult.continuousPowerKW} kW
                </div>
                <span className="text-[10px] text-slate-500 font-medium font-mono">
                  {analysisResult.continuousInverterKVA} kVA Inverter Rating
                </span>
              </div>

              <div className="bg-amber-50 p-3 rounded-xl border border-amber-100">
                <span className="text-amber-700 block font-semibold">Peak Inverter Surge</span>
                <div className="text-lg font-bold text-amber-950 font-mono">
                  {analysisResult.totalSurgePeakKW} kW
                </div>
                <span className="text-[10px] text-amber-700 font-medium font-mono">
                  {analysisResult.recommendedInverterSurgeKVA} kVA Surge Peak (3-6x)
                </span>
              </div>

              <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-100">
                <span className="text-emerald-700 block font-semibold">Daily Energy</span>
                <div className="text-lg font-bold text-emerald-950 font-mono">
                  {analysisResult.dailyEnergyConsumptionKWh} kWh/d
                </div>
                <span className="text-[10px] text-emerald-600 font-medium">
                  Night: {analysisResult.nighttimeEnergyKWh} kWh
                </span>
              </div>

              <div className="bg-indigo-50 p-3 rounded-xl border border-indigo-100">
                <span className="text-indigo-700 block font-semibold">Battery Storage</span>
                <div className="text-lg font-bold text-indigo-950 font-mono">
                  {analysisResult.recommendedBatteryKWh} kWh
                </div>
                <span className="text-[10px] text-indigo-600 font-medium">
                  ~{analysisResult.recommendedBatteryAh48V} Ah @ 48V LiFePO4
                </span>
              </div>
            </div>

            {/* Solar PV Specs */}
            <div className="bg-slate-900 text-white rounded-xl p-3.5 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-amber-300 font-bold">
                  <Sun className="w-3.5 h-3.5" />
                  Recommended Solar PV Array
                </span>
                <span className="font-mono text-xs font-bold text-white">
                  {analysisResult.recommendedPVArrayKWp} kWp Array
                </span>
              </div>
              <div className="text-slate-300 text-[11px]">
                Requires <strong className="text-amber-300">{analysisResult.recommendedPanels550W} x 550W Tier-1 Monocrystalline Panels</strong> based on Gambian 5.4 PSH solar constant.
              </div>
            </div>

            {/* Matched Canonical Package */}
            <div className="border border-emerald-600/50 bg-emerald-950/20 rounded-xl p-3 text-xs space-y-1.5">
              <div className="text-slate-500 font-medium">Matched Fortis Invicta Package:</div>
              <div className="font-bold text-slate-900 font-serif text-sm">
                {analysisResult.recommendedPackageName}
              </div>
              <div className="text-emerald-700 font-bold font-mono">
                GMD {analysisResult.estimatedPriceMinGMD.toLocaleString()} – GMD {analysisResult.estimatedPriceMaxGMD.toLocaleString()}
              </div>

              {onApplyPlan && (
                <button
                  onClick={() => onApplyPlan(analysisResult.recommendedPackageId, analysisResult.estimatedPriceMinGMD)}
                  className="w-full mt-2 inline-flex items-center justify-center gap-2 bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 font-bold py-2 px-3 rounded-lg text-xs transition cursor-pointer"
                >
                  <span>Apply Load Sizing to Repayment Plan</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Optional Gemini AI Consultation Summary Layer */}
            <div className="border-t border-slate-100 pt-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>AI Client Narrative Consultation</span>
                </span>
                <button
                  onClick={handleGenerateAiSummary}
                  disabled={isAiGenerating}
                  className="text-xs text-[#1B4D3E] hover:text-emerald-700 font-bold inline-flex items-center gap-1 cursor-pointer"
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>{isAiGenerating ? 'Synthesizing...' : 'Generate AI Summary'}</span>
                </button>
              </div>

              {aiNarrative && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-700 leading-relaxed font-sans max-h-48 overflow-y-auto whitespace-pre-wrap">
                  {aiNarrative}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
