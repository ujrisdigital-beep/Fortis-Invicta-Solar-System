import React, { useState, useMemo } from 'react';
import {
  Calculator,
  Calendar,
  Percent,
  DollarSign,
  Building2,
  ShieldCheck,
  Globe,
  UserCheck,
  Printer,
  Download,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  HelpCircle,
  Clock,
  FileSpreadsheet,
  Zap,
  Sliders
} from 'lucide-react';
import { Currency, ClientSegment, PackageId, UnionConfig } from '../../types';
import { SOLAR_PACKAGES } from '../../data/mockData';
import { StorageService } from '../../services/storage';
import { formatCurrency } from '../../utils/formatters';
import { SolarLoadCalculator } from './SolarLoadCalculator';

interface RepaymentCalculatorProps {
  currency: Currency;
  onApplyWithPlan?: (packageId: PackageId, segment: ClientSegment, durationMonths: number, downPaymentGMD: number) => void;
}

export const RepaymentCalculator: React.FC<RepaymentCalculatorProps> = ({
  currency,
  onApplyWithPlan
}) => {
  const [activeTab, setActiveTab] = useState<'load_sizer' | 'amortization'>('amortization');
  const [unionsList] = useState<UnionConfig[]>(() => StorageService.getUnions());

  // Input States
  const [selectedPackageId, setSelectedPackageId] = useState<string>('hybrid_standard');
  const [customPriceGMD, setCustomPriceGMD] = useState<number>(320000);
  const [useCustomPrice, setUseCustomPrice] = useState<boolean>(false);
  
  const [selectedSegment, setSelectedSegment] = useState<string>('GTUCCU');
  const [qualifyingMonths, setQualifyingMonths] = useState<number>(24);
  const [downPaymentPercent, setDownPaymentPercent] = useState<number>(10);
  const [adminFeePercent, setAdminFeePercent] = useState<number>(5.0);

  // Selected package reference
  const currentPackage = SOLAR_PACKAGES.find((p) => p.id === selectedPackageId) || SOLAR_PACKAGES[1];

  // Base price calculation
  const baseSystemCostGMD = useCustomPrice
    ? customPriceGMD
    : Math.round((currentPackage.priceMinGMD + currentPackage.priceMaxGMD) / 2);

  // Math calculations
  const downPaymentGMD = Math.round((baseSystemCostGMD * downPaymentPercent) / 100);
  const financedPrincipalGMD = baseSystemCostGMD - downPaymentGMD;
  const totalAdminFeeGMD = Math.round((financedPrincipalGMD * adminFeePercent) / 100);
  const totalPayableFinancedGMD = financedPrincipalGMD + totalAdminFeeGMD;
  const totalNetCostGMD = downPaymentGMD + totalPayableFinancedGMD;
  const monthlyInstallmentGMD = Math.round(totalPayableFinancedGMD / (qualifyingMonths || 1));

  // Generate Spreadsheet Amortization Schedule
  const amortizationSchedule = useMemo(() => {
    const rows = [];
    let currentBalance = financedPrincipalGMD;
    const monthlyPrincipal = financedPrincipalGMD / qualifyingMonths;
    const monthlyFee = totalAdminFeeGMD / qualifyingMonths;
    const monthlyTotal = monthlyInstallmentGMD;
    let cumulativePaid = downPaymentGMD;

    const startDate = new Date();

    for (let month = 1; month <= qualifyingMonths; month++) {
      const monthDate = new Date(startDate.getFullYear(), startDate.getMonth() + month, 1);
      const dateString = monthDate.toLocaleDateString('en-GB', { month: 'short', year: 'numeric' });

      const startBal = currentBalance;
      const endBal = Math.max(0, startBal - monthlyPrincipal);
      currentBalance = endBal;
      cumulativePaid += monthlyTotal;

      rows.push({
        monthNumber: month,
        periodName: `Month ${month} (${dateString})`,
        openingBalanceGMD: Math.round(startBal),
        principalGMD: Math.round(monthlyPrincipal),
        adminFeeGMD: Math.round(monthlyFee),
        totalInstallmentGMD: Math.round(monthlyTotal),
        cumulativePaidGMD: Math.round(cumulativePaid),
        endingBalanceGMD: Math.round(endBal)
      });
    }

    return rows;
  }, [financedPrincipalGMD, totalAdminFeeGMD, monthlyInstallmentGMD, qualifyingMonths, downPaymentGMD]);

  // Handle Preset Segment / Union selection
  const handleSegmentChange = (segmentId: string) => {
    setSelectedSegment(segmentId);
    const matchedUnion = unionsList.find((u) => u.id === segmentId || u.shortCode === segmentId);
    if (matchedUnion) {
      setQualifyingMonths(matchedUnion.defaultQualifyingMonths);
      setAdminFeePercent(matchedUnion.adminFeePercent);
      setDownPaymentPercent(matchedUnion.defaultDownPaymentPercent);
    } else if (segmentId === 'diaspora') {
      setQualifyingMonths(12);
      setAdminFeePercent(3.0);
      setDownPaymentPercent(20);
    } else {
      setQualifyingMonths(12);
      setAdminFeePercent(5.0);
      setDownPaymentPercent(25);
    }
  };

  const handleExportCSV = () => {
    const headers = ['Month', 'Period', 'Opening Balance (GMD)', 'Principal (GMD)', 'Admin Fee (GMD)', 'Monthly Payment (GMD)', 'Ending Balance (GMD)'];
    const csvRows = [
      headers.join(','),
      ...amortizationSchedule.map((row) =>
        [
          row.monthNumber,
          `"${row.periodName}"`,
          row.openingBalanceGMD,
          row.principalGMD,
          row.adminFeeGMD,
          row.totalInstallmentGMD,
          row.endingBalanceGMD
        ].join(',')
      )
    ];

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Fortis_Invicta_Solar_Repayment_Schedule_${selectedSegment}_${qualifyingMonths}M.csv`;
    a.click();
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#12241D] via-[#1B4D3E] to-[#235847] rounded-3xl p-6 sm:p-8 text-white border border-[#2A6E59] shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 z-10 relative">
          <div>
            <div className="inline-flex items-center gap-2 bg-amber-500/20 text-amber-300 border border-amber-500/40 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3">
              <FileSpreadsheet className="w-4 h-4 text-amber-400" />
              Fortis Invicta Financial & Sizing Engine
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold font-serif text-white tracking-wide">
              Solar Engineering Sizer & Repayment Calculator
            </h1>
            <p className="text-sm text-emerald-100/90 max-w-2xl mt-1.5 leading-relaxed">
              Deterministic load and motor surge calculations paired with transparent 24-month salary deduction schedules for Gambia Teachers Union Credit Union (GTUCCU), NAGNMC Healthcare, and Diaspora clients.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-2 bg-emerald-900/80 hover:bg-emerald-800 text-amber-300 border border-emerald-700 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV Schedule</span>
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-2 bg-[#C9A84C] hover:bg-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Schedule</span>
            </button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-3 mt-6 pt-4 border-t border-emerald-800/80">
          <button
            onClick={() => setActiveTab('load_sizer')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'load_sizer'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'bg-emerald-950/60 text-emerald-200 hover:bg-emerald-900/80'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>1. Deterministic Solar & Motor Sizer</span>
          </button>

          <button
            onClick={() => setActiveTab('amortization')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'amortization'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'bg-emerald-950/60 text-emerald-200 hover:bg-emerald-900/80'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>2. Institutional Salary Amortizer</span>
          </button>
        </div>
      </div>

      {activeTab === 'load_sizer' ? (
        <SolarLoadCalculator
          currency={currency}
          onApplyPlan={(pkgId, cost) => {
            setSelectedPackageId(pkgId);
            setCustomPriceGMD(cost);
            setUseCustomPrice(true);
            setActiveTab('amortization');
          }}
        />
      ) : (
        <>
          {/* Calculator Controls & Output Summary Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Inputs Panel */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-bold text-slate-900 font-serif flex items-center gap-2">
              <Calculator className="w-5 h-5 text-[#1B4D3E]" />
              <span>1. System & Financing Parameters</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Customize system size, union deduction, down payment, and months</p>
          </div>

          {/* Client Segment Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Client Category / Institutional Union
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              {unionsList.filter((u) => u.isActive).map((u) => (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => handleSegmentChange(u.id)}
                  className={`p-2.5 rounded-xl border font-semibold flex items-center gap-2 transition-all text-left cursor-pointer ${
                    selectedSegment === u.id || selectedSegment === u.shortCode
                      ? 'border-[#1B4D3E] bg-emerald-50 text-emerald-950 ring-2 ring-[#1B4D3E]'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Building2 className="w-4 h-4 text-emerald-800 shrink-0" />
                  <div className="truncate">
                    <span className="block font-extrabold truncate">{u.shortCode}</span>
                    <span className="text-[10px] text-slate-500 font-normal">{u.defaultQualifyingMonths}-Mo Scheme</span>
                  </div>
                </button>
              ))}

              <button
                type="button"
                onClick={() => handleSegmentChange('diaspora')}
                className={`p-2.5 rounded-xl border font-semibold flex items-center gap-2 transition-all text-left cursor-pointer ${
                  selectedSegment === 'diaspora'
                    ? 'border-[#1B4D3E] bg-amber-50 text-amber-950 ring-2 ring-[#1B4D3E]'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Globe className="w-4 h-4 text-amber-700 shrink-0" />
                <div>
                  <span className="block font-bold">Diaspora</span>
                  <span className="text-[10px] text-slate-500 font-normal">Foreign Transfer</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleSegmentChange('non_union_individual')}
                className={`p-2.5 rounded-xl border font-semibold flex items-center gap-2 transition-all text-left cursor-pointer ${
                  selectedSegment === 'non_union_individual'
                    ? 'border-[#1B4D3E] bg-slate-100 text-slate-950 ring-2 ring-[#1B4D3E]'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <UserCheck className="w-4 h-4 text-slate-700 shrink-0" />
                <div>
                  <span className="block font-bold">Private Client</span>
                  <span className="text-[10px] text-slate-500 font-normal">Direct Cash / Bank</span>
                </div>
              </button>
            </div>
          </div>

          {/* Package Selection */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <label className="font-bold text-slate-700 uppercase tracking-wider">
                Select Fortis Solar System Package
              </label>
              <button
                onClick={() => setUseCustomPrice(!useCustomPrice)}
                className="text-emerald-700 font-semibold hover:underline text-[11px]"
              >
                {useCustomPrice ? 'Use Package Presets' : 'Set Custom Price'}
              </button>
            </div>

            {!useCustomPrice ? (
              <select
                value={selectedPackageId}
                onChange={(e) => setSelectedPackageId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-[#1B4D3E]"
              >
                {SOLAR_PACKAGES.map((pkg) => (
                  <option key={pkg.id} value={pkg.id}>
                    {pkg.name} ({pkg.inverterCapacity}) — Approx {formatCurrency(Math.round((pkg.priceMinGMD + pkg.priceMaxGMD) / 2), currency)}
                  </option>
                ))}
              </select>
            ) : (
              <div className="space-y-1">
                <input
                  type="number"
                  value={customPriceGMD}
                  onChange={(e) => setCustomPriceGMD(Number(e.target.value))}
                  placeholder="Enter total system cost in GMD"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-[#1B4D3E]"
                />
                <span className="text-[10px] text-slate-500 block">System Cost (GMD)</span>
              </div>
            )}
          </div>

          {/* Qualifying Period Duration */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Qualifying Repayment Period (Months)
            </label>
            <div className="grid grid-cols-6 gap-1.5 text-xs">
              {[3, 6, 12, 18, 24, 36].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setQualifyingMonths(m)}
                  className={`py-2 rounded-xl font-bold transition-all ${
                    qualifyingMonths === m
                      ? 'bg-[#1B4D3E] text-amber-300 shadow-sm'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {m}M
                </button>
              ))}
            </div>
          </div>

          {/* Down Payment Percentage Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="font-bold text-slate-700 uppercase tracking-wider">
                Initial Down Payment ({downPaymentPercent}%)
              </span>
              <span className="font-bold text-emerald-800 font-mono">
                {formatCurrency(downPaymentGMD, currency)}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="5"
              value={downPaymentPercent}
              onChange={(e) => setDownPaymentPercent(Number(e.target.value))}
              className="w-full accent-[#1B4D3E] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>0% (No Downpayment)</span>
              <span>10% Standard</span>
              <span>25%</span>
              <span>50% Max</span>
            </div>
          </div>

          {/* Union Admin / Interest Fee Rate */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="font-bold text-slate-700 uppercase tracking-wider">
                Union Admin / Interest Rate ({adminFeePercent}%)
              </span>
              <span className="font-bold text-amber-800 font-mono">
                +{formatCurrency(totalAdminFeeGMD, currency)}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="15"
              step="0.5"
              value={adminFeePercent}
              onChange={(e) => setAdminFeePercent(Number(e.target.value))}
              className="w-full accent-amber-600 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500 leading-tight">
              Gambia Teachers Union (GTUCCU) & NAGNMC standard administrative processing charge is capped at 5.0% over the qualifying period.
            </p>
          </div>
        </div>

        {/* Right Output Key Cards Panel */}
        <div className="lg:col-span-7 space-y-6">
          {/* Big Monthly Salary Deduction Hero Card */}
          <div className="bg-gradient-to-br from-[#12241D] via-[#1B4D3E] to-[#235847] text-white rounded-3xl p-6 sm:p-8 border border-[#2A6E59] shadow-xl relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-emerald-800/80 pb-4 mb-6">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-300 block">
                  Qualifying Period Salary Deduction
                </span>
                <h3 className="text-xl font-extrabold font-serif text-white mt-0.5">
                  Fixed Monthly Installment
                </h3>
              </div>
              <div className="bg-amber-400 text-slate-950 font-black text-xs px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
                {qualifyingMonths} Months Qualifying Period
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
              <div>
                <div className="text-3xl sm:text-4xl font-black font-serif text-amber-300 tracking-tight">
                  {formatCurrency(monthlyInstallmentGMD, currency)}
                  <span className="text-xs font-sans text-emerald-200 block font-normal mt-1">
                    per month for {qualifyingMonths} months
                  </span>
                </div>

                <div className="mt-4 space-y-1.5 text-xs text-emerald-100/90">
                  <div className="flex justify-between">
                    <span>Base System Package Cost:</span>
                    <strong className="text-white font-mono">{formatCurrency(baseSystemCostGMD, currency)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Initial Down Payment ({downPaymentPercent}%):</span>
                    <strong className="text-amber-300 font-mono">-{formatCurrency(downPaymentGMD, currency)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Financed Principal Balance:</span>
                    <strong className="text-white font-mono">{formatCurrency(financedPrincipalGMD, currency)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Union Admin Fee ({adminFeePercent}%):</span>
                    <strong className="text-amber-300 font-mono">+{formatCurrency(totalAdminFeeGMD, currency)}</strong>
                  </div>
                </div>
              </div>

              {/* Total Summary Stat Card */}
              <div className="bg-[#0A1612]/90 p-5 rounded-2xl border border-emerald-700/60 space-y-3">
                <div>
                  <span className="text-[10px] text-emerald-300 uppercase tracking-wider font-bold block">
                    Total Net Cost Over {qualifyingMonths} Months
                  </span>
                  <div className="text-xl font-bold text-white font-serif mt-0.5">
                    {formatCurrency(totalNetCostGMD, currency)}
                  </div>
                </div>

                <div className="pt-2 border-t border-emerald-800/80 text-[11px] text-emerald-200/90 space-y-1">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Includes 6 Months Free Maintenance</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Tier-1 Monocrystalline Solar Warranty</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Automatic Bank Deduction Authorization</span>
                  </div>
                </div>

                {onApplyWithPlan && (
                  <button
                    onClick={() => onApplyWithPlan(currentPackage.id, selectedSegment as ClientSegment, qualifyingMonths, downPaymentGMD)}
                    className="w-full bg-[#C9A84C] hover:bg-amber-400 text-slate-950 font-bold py-2.5 px-4 rounded-xl text-xs transition-colors flex items-center justify-center gap-2 shadow-md mt-2"
                  >
                    <span>Apply With This Repayment Plan</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Quick Segment Disclaimer */}
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-xs text-amber-900 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold block mb-0.5">GTUCCU & NAGNMC Member Qualification Note:</strong>
              <span>
                To complete your solar installation application, upload your latest payslip and Union Membership ID card in the portal. Deduction instructions are dispatched directly to the Accountant General’s Department upon site assessment approval.
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Full Monthly Repayment Schedule Spreadsheet Table */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#1B4D3E] uppercase tracking-wider mb-1">
              <Calendar className="w-4 h-4" />
              Month-by-Month Amortization Schedule
            </div>
            <h2 className="text-lg font-bold text-slate-900 font-serif">
              Qualifying Period Monthly Spreadsheet Breakdown
            </h2>
            <p className="text-xs text-slate-500">
              Detailed breakdown of principal, admin fees, and remaining balance over {qualifyingMonths} months
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="bg-emerald-50 text-emerald-900 border border-emerald-200 px-3 py-1 rounded-lg font-bold">
              {qualifyingMonths} Monthly Rows Generated
            </span>
          </div>
        </div>

        {/* Scrollable Table */}
        <div className="overflow-x-auto border border-slate-200 rounded-2xl">
          <table className="w-full text-left text-xs text-slate-700 border-collapse">
            <thead>
              <tr className="bg-slate-900 text-amber-300 font-serif uppercase text-[10px] tracking-wider border-b border-slate-800">
                <th className="p-3 text-center w-12">#</th>
                <th className="p-3">Payment Period</th>
                <th className="p-3 text-right">Opening Balance</th>
                <th className="p-3 text-right">Principal Repayment</th>
                <th className="p-3 text-right">Admin Fee ({adminFeePercent}%)</th>
                <th className="p-3 text-right text-amber-300 font-bold">Total Monthly Payment</th>
                <th className="p-3 text-right">Cumulative Paid</th>
                <th className="p-3 text-right">Ending Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {/* Downpayment Row 0 */}
              <tr className="bg-emerald-50/60 font-sans font-semibold text-emerald-950">
                <td className="p-3 text-center text-emerald-700 font-bold">0</td>
                <td className="p-3 font-bold">Initial Down Payment (Upfront)</td>
                <td className="p-3 text-right">{formatCurrency(baseSystemCostGMD, currency)}</td>
                <td className="p-3 text-right">{formatCurrency(downPaymentGMD, currency)}</td>
                <td className="p-3 text-right">GMD 0</td>
                <td className="p-3 text-right font-bold text-emerald-800">{formatCurrency(downPaymentGMD, currency)}</td>
                <td className="p-3 text-right">{formatCurrency(downPaymentGMD, currency)}</td>
                <td className="p-3 text-right font-bold">{formatCurrency(financedPrincipalGMD, currency)}</td>
              </tr>

              {/* Monthly Repayment Rows */}
              {amortizationSchedule.map((row) => (
                <tr key={row.monthNumber} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 text-center font-bold text-slate-500 font-sans">{row.monthNumber}</td>
                  <td className="p-3 font-sans font-medium text-slate-900">{row.periodName}</td>
                  <td className="p-3 text-right text-slate-600">{formatCurrency(row.openingBalanceGMD, currency)}</td>
                  <td className="p-3 text-right text-slate-800">{formatCurrency(row.principalGMD, currency)}</td>
                  <td className="p-3 text-right text-amber-700">{formatCurrency(row.adminFeeGMD, currency)}</td>
                  <td className="p-3 text-right font-bold text-[#1B4D3E] bg-emerald-50/30">
                    {formatCurrency(row.totalInstallmentGMD, currency)}
                  </td>
                  <td className="p-3 text-right text-slate-600">{formatCurrency(row.cumulativePaidGMD, currency)}</td>
                  <td className="p-3 text-right font-bold text-slate-900">{formatCurrency(row.endingBalanceGMD, currency)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-900 text-white font-bold text-xs border-t-2 border-slate-700">
                <td colSpan={2} className="p-3.5 font-serif uppercase tracking-wider text-amber-300">
                  Total Schedule Sum
                </td>
                <td className="p-3.5 text-right font-mono">{formatCurrency(baseSystemCostGMD, currency)}</td>
                <td className="p-3.5 text-right font-mono">{formatCurrency(financedPrincipalGMD + downPaymentGMD, currency)}</td>
                <td className="p-3.5 text-right font-mono text-amber-300">+{formatCurrency(totalAdminFeeGMD, currency)}</td>
                <td className="p-3.5 text-right font-mono text-amber-300 font-black text-sm">
                  {formatCurrency(totalNetCostGMD, currency)}
                </td>
                <td className="p-3.5 text-right font-mono">{formatCurrency(totalNetCostGMD, currency)}</td>
                <td className="p-3.5 text-right font-mono text-emerald-400">GMD 0 (Fully Paid)</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      </>
      )}
    </div>
  );
};
