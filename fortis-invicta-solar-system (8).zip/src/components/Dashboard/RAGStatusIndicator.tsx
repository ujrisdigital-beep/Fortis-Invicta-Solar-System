import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle2, MessageSquare, ArrowRight, FileCheck, DollarSign, Clock, Sparkles } from 'lucide-react';
import { Client, Currency, PaymentRecord } from '../../types';
import { formatCurrency, getStageLabel } from '../../utils/formatters';
import { dispatchNotification } from '../../utils/messaging';

export interface RAGHealthItem {
  client: Client;
  status: 'red' | 'amber' | 'green';
  score: number; // 0 - 100
  reasons: string[];
  recommendedAction: string;
}

interface RAGStatusIndicatorProps {
  clients: Client[];
  payments: PaymentRecord[];
  currency: Currency;
  onSelectClient: (client: Client) => void;
}

export const RAGStatusIndicator: React.FC<RAGStatusIndicatorProps> = ({
  clients,
  payments,
  currency,
  onSelectClient
}) => {
  const [filterRag, setFilterRag] = useState<'all' | 'red' | 'amber' | 'green'>('all');

  // Compute RAG Status for each client dynamically
  const healthItems: RAGHealthItem[] = clients.map((client) => {
    const reasons: string[] = [];
    let score = 100;

    // 1. Check Payment Health
    const clientPayments = payments.filter((p) => p.clientId === client.id);
    const hasOverdue = clientPayments.some((p) => p.status === 'overdue') || client.paymentStatus === 'overdue';
    const hasPendingConfirmation = clientPayments.some((p) => p.status === 'confirmation_required');

    if (hasOverdue) {
      score -= 40;
      reasons.push(`Overdue balance of ${formatCurrency(client.outstandingBalanceGMD, currency)}`);
    } else if (hasPendingConfirmation) {
      score -= 15;
      reasons.push('Bank deposit teller receipt awaiting finance confirmation');
    }

    if (client.outstandingBalanceGMD > 0 && (client.projectStage === 'installation_in_progress' || client.projectStage === 'commissioning')) {
      score -= 20;
      reasons.push('Outstanding balance remaining during active installation phase');
    }

    // 2. Check Document Completion
    const docs = client.documents || [];
    const hasProofOfAddress = docs.some((d) => d.type === 'proof_of_address');
    const hasId = docs.some((d) => d.type === 'national_id');

    if (client.clientSegment !== 'diaspora' && !hasProofOfAddress && client.projectStage !== 'lead') {
      score -= 20;
      reasons.push('Missing Proof of Address / Title Deed verification');
    }
    if (!hasId) {
      score -= 15;
      reasons.push('Missing national ID / Passport copy');
    }

    // 3. Check Stage Progress / Delays
    const createdDate = new Date(client.createdAt).getTime();
    const daysSinceCreation = Math.floor((Date.now() - createdDate) / (1000 * 60 * 60 * 24));

    if (client.projectStage === 'assessment_scheduled' && daysSinceCreation > 3) {
      score -= 15;
      reasons.push(`Site assessment pending for ${daysSinceCreation} days`);
    }

    // Determine Final RAG Band
    let status: 'red' | 'amber' | 'green' = 'green';
    let recommendedAction = 'Maintain standard installation schedule';

    if (score < 60 || hasOverdue) {
      status = 'red';
      recommendedAction = 'Send immediate payment notice or pause inverter dispatch';
    } else if (score < 85 || hasPendingConfirmation) {
      status = 'amber';
      recommendedAction = 'Request missing documents or confirm bank teller slip';
    }

    if (reasons.length === 0) {
      reasons.push('100% On-Track: All payments confirmed & documents complete');
    }

    return {
      client,
      status,
      score,
      reasons,
      recommendedAction
    };
  });

  const redCount = healthItems.filter((i) => i.status === 'red').length;
  const amberCount = healthItems.filter((i) => i.status === 'amber').length;
  const greenCount = healthItems.filter((i) => i.status === 'green').length;

  const filteredItems = healthItems.filter((item) => {
    if (filterRag === 'all') return true;
    return item.status === filterRag;
  });

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm space-y-6">
      {/* Header & Overall Summary */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-amber-100 text-amber-900 font-black text-xs uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              Dynamic Project Health
            </span>
            <h2 className="text-xl font-bold font-serif text-slate-900">
              RAG (Red-Amber-Green) Status Matrix
            </h2>
          </div>
          <p className="text-xs text-slate-500">
            Real-time automated evaluation based on payment delays, installation progress, and document completeness.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-2xl text-xs font-bold shrink-0">
          <button
            onClick={() => setFilterRag('all')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
              filterRag === 'all'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Projects ({clients.length})
          </button>

          <button
            onClick={() => setFilterRag('red')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
              filterRag === 'red'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'text-rose-700 hover:bg-rose-50'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Critical ({redCount})</span>
          </button>

          <button
            onClick={() => setFilterRag('amber')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
              filterRag === 'amber'
                ? 'bg-amber-500 text-slate-950 shadow-sm font-extrabold'
                : 'text-amber-800 hover:bg-amber-50'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Watchlist ({amberCount})</span>
          </button>

          <button
            onClick={() => setFilterRag('green')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
              filterRag === 'green'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-emerald-800 hover:bg-emerald-50'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>On-Track ({greenCount})</span>
          </button>
        </div>
      </div>

      {/* RAG Matrix Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.slice(0, 6).map(({ client, status, score, reasons, recommendedAction }, idx) => {
          return (
            <div
              key={`${client.id}-${idx}`}
              className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 ${
                status === 'red'
                  ? 'bg-rose-50/70 border-rose-300 ring-1 ring-rose-200'
                  : status === 'amber'
                  ? 'bg-amber-50/80 border-amber-300 ring-1 ring-amber-200'
                  : 'bg-emerald-50/50 border-emerald-200'
              }`}
            >
              <div className="space-y-2">
                {/* Header info */}
                <div className="flex items-center justify-between">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider flex items-center gap-1 ${
                      status === 'red'
                        ? 'bg-rose-600 text-white'
                        : status === 'amber'
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-emerald-700 text-white'
                    }`}
                  >
                    {status === 'red' && <ShieldAlert className="w-3 h-3" />}
                    {status === 'amber' && <AlertTriangle className="w-3 h-3" />}
                    {status === 'green' && <CheckCircle2 className="w-3 h-3" />}
                    <span>RAG: {status.toUpperCase()} ({score}/100)</span>
                  </span>

                  <span className="text-[10px] font-mono text-slate-500">
                    {getStageLabel(client.projectStage)}
                  </span>
                </div>

                {/* Client Name & Phone */}
                <div>
                  <h4 className="font-bold text-slate-900 text-sm font-serif">{client.fullName}</h4>
                  <p className="text-[11px] text-slate-500">
                    {client.phone} • {client.packageId.replace('_', ' ').toUpperCase()}
                  </p>
                </div>

                {/* Specific Reasons */}
                <div className="space-y-1 bg-white/80 p-2.5 rounded-xl border border-slate-200 text-[11px]">
                  <span className="font-bold text-slate-700 text-[10px] uppercase block">Health Drivers:</span>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-600 font-medium">
                    {reasons.map((r, idx) => (
                      <li key={idx} className="truncate">{r}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action Bar */}
              <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => dispatchNotification('whatsapp', status === 'red' ? 'payment_reminder' : 'stage_update', client)}
                  className="bg-emerald-700 hover:bg-emerald-800 text-amber-300 px-2.5 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp Alert</span>
                </button>

                <button
                  onClick={() => onSelectClient(client)}
                  className="bg-[#1B4D3E] hover:bg-[#143B2F] text-white px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                >
                  <span>Review Project</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
