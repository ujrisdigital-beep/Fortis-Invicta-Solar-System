import React, { useState } from 'react';
import { FortisLogo } from '../FortisLogo';
import { SolarPackageSection } from '../Packages/SolarPackageSection';
import { RAGStatusIndicator } from './RAGStatusIndicator';
import { SolarTelemetryWidget } from './SolarTelemetryWidget';
import { StaffRosterWidget } from './StaffRosterWidget';
import { DeploymentReadinessWidget } from './DeploymentReadinessWidget';
import { InflationForexPanel } from '../Settings/InflationForexPanel';
import { useAuth } from '../../services/authContext';
import {
  Users,
  Wrench,
  CheckCircle2,
  DollarSign,
  AlertTriangle,
  Clock,
  ArrowUpRight,
  TrendingUp,
  Building2,
  Globe,
  UserCheck,
  ShieldCheck,
  ChevronRight,
  Plus,
  Calculator,
  FileSpreadsheet,
  Sparkles,
  Bot,
  UserPlus,
  CreditCard,
  Activity,
  ClipboardCheck,
  Printer,
  ShieldAlert,
  BarChart3,
  Target,
  Layers,
  AlertOctagon,
  TrendingDown,
  Compass,
  FileCheck,
  AlertCircle,
  Zap,
  ArrowRight,
  Mail,
  LogOut,
  Key
} from 'lucide-react';
import { Client, Currency, PaymentRecord, AuditLogItem, UserRole } from '../../types';
import { formatCurrency, getStageLabel, getStageColor } from '../../utils/formatters';
import { PDFDocumentGenerator } from '../../utils/pdfGenerator';

interface DashboardViewProps {
  metrics: any;
  clients: Client[];
  payments: PaymentRecord[];
  auditLogs: AuditLogItem[];
  currency: Currency;
  currentRole?: UserRole;
  isGdprActive?: boolean;
  selectedUnionId?: string;
  onNavigateTab: (tab: string) => void;
  onSelectClient: (client: Client) => void;
  onNewClient: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  metrics,
  clients,
  payments,
  auditLogs,
  currency,
  currentRole = 'super_admin',
  isGdprActive = true,
  selectedUnionId = 'GTUCCU',
  onNavigateTab,
  onSelectClient,
  onNewClient
}) => {
  const { user, logout } = useAuth();
  const [activityFilter, setActivityFilter] = useState<'all' | 'lead' | 'payment' | 'installation' | 'assessment'>('all');
  const isUnionAdmin = currentRole === 'institutional_admin';

  // Active email to display
  const displayEmail = user?.email || (currentRole === 'super_admin' ? 'admin@fortisinvicta.gm' : `${currentRole}@fortisinvicta.gm`);
  const displayName = user?.fullName || (currentRole === 'super_admin' ? 'Amadou Jallow (Super Admin)' : currentRole.replace('_', ' ').toUpperCase());
  const effectiveRole = user?.role || currentRole;

  // 1. Calculate Real-Time RAG Status (Red-Amber-Green Health Check)
  const overduePayments = payments.filter((p) => p.status === 'overdue' || p.status === 'confirmation_required').length;
  const pendingAssessments = clients.filter((c) => c.projectStage === 'assessment_scheduled').length;
  const activeInstallationsCount = metrics.activeInstallations || 0;

  let ragStatus: 'on-track' | 'at-risk' | 'critical' = 'on-track';
  const ragWarnings: string[] = [];

  if (overduePayments > 10 || metrics.conversionRate < 50) {
    ragStatus = 'critical';
    ragWarnings.push(`${overduePayments} payments overdue/pending confirmation`);
    ragWarnings.push('Conversion rate below critical 50% threshold');
  } else if (overduePayments > 2 || pendingAssessments > 3) {
    ragStatus = 'at-risk';
    if (overduePayments > 2) ragWarnings.push(`${overduePayments} overdue or pending teller confirmations`);
    if (pendingAssessments > 3) ragWarnings.push(`${pendingAssessments} site assessments awaiting crew assignment`);
  }

  // 2. Attention Items Data
  const attentionItems = [
    {
      id: 'att-1',
      type: 'payment',
      urgency: 'high',
      title: 'Mariama Fofana — Payment 4 Days Overdue',
      description: 'Package 3 (Premium Executive) GMD 45,000 deposit required before inverter dispatch.',
      actionLabel: 'Contact Client',
      onClick: () => {
        const client = clients.find((c) => c.fullName.includes('Mariama')) || clients[0];
        if (client) onSelectClient(client);
      }
    },
    {
      id: 'att-2',
      type: 'assessment',
      urgency: 'medium',
      title: 'Lamin Bojang — Site Assessment Delayed',
      description: 'Site inspection in West Coast Kombo scheduled 3 days ago. Field inspector report pending.',
      actionLabel: 'Assign Inspector',
      onClick: () => onNavigateTab('inspection')
    },
    {
      id: 'att-3',
      type: 'document',
      urgency: 'medium',
      title: 'Amara Jobe — Land Ownership Certificate Missing',
      description: 'GTUCCU salary deduction approved, but roof structural photos & land title need uploading.',
      actionLabel: 'Request Documents',
      onClick: () => {
        const client = clients.find((c) => c.fullName.includes('Amara')) || clients[0];
        if (client) onSelectClient(client);
      }
    }
  ];

  // 3. Risk Log Data
  const openRisks = [
    {
      id: 'R001',
      title: 'GTUCCU Monthly Payroll Cutoff Alignment',
      severity: 'high',
      probability: '65%',
      impact: 'HIGH',
      mitigation: 'Submit batch salary deduction file before 18th of current month.',
      daysOpen: 4,
      status: 'IN PROGRESS'
    },
    {
      id: 'R002',
      title: 'North Bank Rainy Season Logistics & Access',
      severity: 'medium',
      probability: '40%',
      impact: 'MEDIUM',
      mitigation: 'Pre-stage battery banks and mounting hardware at Barra regional hub.',
      daysOpen: 7,
      status: 'MONITORING'
    },
    {
      id: 'R003',
      title: 'Forex Volatility on Monocrystalline Imports',
      severity: 'low',
      probability: '25%',
      impact: 'LOW',
      mitigation: 'Lock in supplier pricing using USD Diaspora direct transfer reserves.',
      daysOpen: 2,
      status: 'MONITORING'
    }
  ];

  // 4. Team Workload Data
  const teamWorkloads = [
    { name: 'Team Alpha (Greater Banjul)', active: 4, capacity: 5, pct: 80, status: 'balanced' },
    { name: 'Team Beta (West Coast / Brikama)', active: 3, capacity: 4, pct: 75, status: 'balanced' },
    { name: 'Team Gamma (North Bank / Barra)', active: 6, capacity: 5, pct: 120, status: 'overloaded' },
    { name: 'Team Delta (Lower River / Soma)', active: 1, capacity: 4, pct: 25, status: 'underutilized' }
  ];

  const getActivityBadge = (action: string, details: string) => {
    const act = action.toUpperCase();
    const det = details.toLowerCase();

    if (act.includes('CLIENT_CREATED') || det.includes('onboarded') || det.includes('registered') || det.includes('lead')) {
      return {
        label: 'New Lead Registered',
        color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
        icon: UserPlus,
        category: 'lead'
      };
    }
    if (act.includes('PAYMENT') || det.includes('payment') || det.includes('confirmed') || det.includes('teller')) {
      return {
        label: 'Payment Confirmed',
        color: 'bg-amber-100 text-amber-900 border-amber-300',
        icon: CreditCard,
        category: 'payment'
      };
    }
    if (act.includes('INSTALLATION') || det.includes('installed') || det.includes('commissioned')) {
      return {
        label: 'Installation Completed',
        color: 'bg-purple-100 text-purple-900 border-purple-300',
        icon: Wrench,
        category: 'installation'
      };
    }
    if (act.includes('ASSESSMENT') || det.includes('assessment') || det.includes('inspector')) {
      return {
        label: 'Assessment Scheduled',
        color: 'bg-blue-100 text-blue-900 border-blue-300',
        icon: ClipboardCheck,
        category: 'assessment'
      };
    }

    return {
      label: 'Stage Updated',
      color: 'bg-teal-100 text-teal-900 border-teal-300',
      icon: Activity,
      category: 'other'
    };
  };

  const filteredLogs = auditLogs.filter((log) => {
    if (activityFilter === 'all') return true;
    const badge = getActivityBadge(log.action, log.details);
    return badge.category === activityFilter;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* 0. CURRENT SIGNED-IN USER & SECURITY CLEARANCE BAR */}
      <div className="bg-[#0B1A14] border border-emerald-800/90 rounded-2xl p-3.5 sm:p-4 text-white shadow-md flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-sm shrink-0">
            <Mail className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-400">
                Current Signed-In User:
              </span>
              <span className="font-mono font-bold text-amber-300 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-500/40 truncate">
                {displayEmail}
              </span>
              <span className="bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/40 text-[10px] uppercase">
                {effectiveRole.replace('_', ' ')}
              </span>
            </div>
            <p className="text-[11px] text-slate-300 mt-0.5">
              Authenticated Operator: <strong className="text-white">{displayName}</strong>
              {user?.institutionId && (
                <span className="text-teal-300 font-semibold ml-1.5">• Institution: {user.institutionId}</span>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
          <span className="flex items-center gap-1.5 bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 text-[10px] font-bold px-2.5 py-1 rounded-lg">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Active Verified Session</span>
          </span>
          {user && (
            <button
              onClick={() => logout()}
              title="Sign Out"
              className="flex items-center gap-1 bg-slate-800/80 hover:bg-rose-950/80 text-slate-300 hover:text-rose-300 border border-slate-700 hover:border-rose-500/50 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer"
            >
              <LogOut className="w-3 h-3" />
              <span>Sign Out</span>
            </button>
          )}
        </div>
      </div>

      {/* 1. REAL-TIME RAG STATUS INDICATOR BANNER */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border shadow-lg flex flex-col md:flex-row items-center justify-between gap-4 transition-all ${
          ragStatus === 'on-track'
            ? 'bg-gradient-to-r from-[#0F291E] via-[#1B4D3E] to-[#12382B] text-white border-emerald-600/60'
            : ragStatus === 'at-risk'
            ? 'bg-gradient-to-r from-amber-950 via-amber-900 to-amber-950 text-white border-amber-500/80'
            : 'bg-gradient-to-r from-rose-950 via-rose-900 to-rose-950 text-white border-rose-500/80'
        }`}
      >
        <div className="flex items-center gap-4 text-center md:text-left">
          <div
            className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold shrink-0 shadow-inner ${
              ragStatus === 'on-track'
                ? 'bg-emerald-500 text-slate-950'
                : ragStatus === 'at-risk'
                ? 'bg-amber-400 text-slate-950'
                : 'bg-rose-500 text-white'
            }`}
          >
            {ragStatus === 'on-track' ? (
              <CheckCircle2 className="w-7 h-7" />
            ) : ragStatus === 'at-risk' ? (
              <AlertTriangle className="w-7 h-7" />
            ) : (
              <AlertOctagon className="w-7 h-7" />
            )}
          </div>

          <div>
            <div className="flex items-center justify-center md:justify-start gap-2">
              <span className="text-xs font-bold uppercase tracking-widest text-amber-300 font-mono">
                Real-Time Project Health Status
              </span>
              <span
                className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full ${
                  ragStatus === 'on-track'
                    ? 'bg-emerald-400 text-slate-950'
                    : ragStatus === 'at-risk'
                    ? 'bg-amber-400 text-slate-950 animate-pulse'
                    : 'bg-rose-500 text-white animate-bounce'
                }`}
              >
                {ragStatus === 'on-track' ? '🟢 ON TRACK' : ragStatus === 'at-risk' ? '🟡 AT RISK' : '🔴 CRITICAL'}
              </span>
            </div>

            <h2 className="text-lg sm:text-xl font-bold font-serif mt-0.5">
              {ragStatus === 'on-track'
                ? 'Fortis Invicta Solar Program is On Track & Operating at Peak Health'
                : ragStatus === 'at-risk'
                ? 'Attention Required — 2 Operational Warnings Identified'
                : 'Critical Action Needed — Overdue Payments & Delay Bottleneck'}
            </h2>

            <p className="text-xs text-emerald-100/90 mt-1 max-w-2xl">
              {ragWarnings.length === 0
                ? 'All GTUCCU & NAGNMC salary deduction milestone schedules are running strictly on time with active field crew coverage.'
                : ragWarnings.join(' • ')}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => PDFDocumentGenerator.generateExecutiveSummaryPDF(metrics, ragStatus, currency)}
            className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold px-4 py-2.5 rounded-2xl text-xs flex items-center gap-2 shadow-xl transition-all cursor-pointer transform hover:scale-105 active:scale-95"
          >
            <Printer className="w-4 h-4 text-slate-950" />
            <span>One-Click Executive PDF</span>
          </button>
        </div>
      </div>

      {/* 2. DYNAMIC RAG STATUS MATRIX COMPONENT */}
      <RAGStatusIndicator
        clients={clients}
        payments={payments}
        currency={currency}
        onSelectClient={onSelectClient}
      />

      {/* Hero Banner with Official Fortis Invicta Logo */}
      <div className="bg-gradient-to-r from-[#12241D] via-[#1B4D3E] to-[#235847] rounded-3xl p-6 sm:p-8 text-white border border-[#2A6E59] shadow-xl flex flex-col lg:flex-row items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 z-10 text-center sm:text-left">
          <div className="bg-[#0A1612]/80 p-4 rounded-2xl border border-amber-500/30 shadow-2xl backdrop-blur-md shrink-0">
            <FortisLogo size="lg" theme="dark" showText={false} />
          </div>

          <div>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-2">
              <span className="font-extrabold text-2xl sm:text-3xl font-serif text-white tracking-wide">
                FORTIS INVICTA LTD
              </span>
              <span className="bg-amber-400 text-slate-950 font-black text-xs px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                Solar OS
              </span>
            </div>

            <p className="text-sm sm:text-base text-emerald-100 font-medium max-w-xl leading-relaxed">
              The Gambia’s Premier Solar Installation & Project Financing Platform
            </p>

            <div className="mt-3 flex flex-wrap items-center justify-center sm:justify-start gap-3 text-xs text-emerald-200/90">
              <span className="bg-emerald-900/80 text-emerald-200 px-3 py-1 rounded-lg border border-emerald-700/60 font-medium flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                Ecobank Merchant Code: <strong className="text-white font-mono">505825057</strong>
              </span>
              <span className="bg-emerald-900/80 text-emerald-200 px-3 py-1 rounded-lg border border-emerald-700/60 font-medium">
                Terminal ID: <strong className="text-white font-mono">32680928</strong>
              </span>
              <span className="bg-amber-500/20 text-amber-300 px-3 py-1 rounded-lg border border-amber-500/40 font-semibold">
                OpenSolar Direct Payments Enabled
              </span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 z-10 shrink-0">
          <button
            onClick={() => onNavigateTab('calculator')}
            className="flex items-center gap-2 bg-emerald-900/90 hover:bg-emerald-800 text-amber-300 border border-emerald-600 font-bold px-4 py-3 rounded-2xl text-xs shadow-lg transition-all"
          >
            <FileSpreadsheet className="w-4 h-4 text-amber-400" />
            <span>Repayment Spreadsheet</span>
          </button>
          <button
            onClick={onNewClient}
            className="flex items-center gap-2 bg-[#C9A84C] hover:bg-amber-400 text-slate-950 font-bold px-5 py-3 rounded-2xl text-sm shadow-xl transition-all transform hover:scale-105 active:scale-95"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>Onboard New Client</span>
          </button>
        </div>
      </div>

      {/* 2. ATTENTION PANEL & RISK LOG GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ATTENTION PANEL */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 font-serif">What Needs Your Attention Right Now</h3>
                <p className="text-[11px] text-slate-500">Prioritized operational items requiring immediate action</p>
              </div>
            </div>
            <span className="bg-rose-100 text-rose-800 font-bold px-2.5 py-0.5 rounded-full text-xs">
              {attentionItems.length} Urgent Items
            </span>
          </div>

          <div className="space-y-3">
            {attentionItems.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200 hover:border-amber-300 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        item.urgency === 'high'
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : 'bg-amber-100 text-amber-900 border border-amber-300'
                      }`}
                    >
                      {item.urgency} Priority
                    </span>
                    <h4 className="text-xs font-bold text-slate-900">{item.title}</h4>
                  </div>
                  <p className="text-[11px] text-slate-600">{item.description}</p>
                </div>

                <button
                  onClick={item.onClick}
                  className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold px-3 py-1.5 rounded-xl text-xs whitespace-nowrap cursor-pointer transition-colors shrink-0 shadow-sm flex items-center gap-1"
                >
                  <span>{item.actionLabel}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* RISK & ISSUE LOG */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 font-serif">Open Risk & Issue Log</h3>
                <p className="text-[11px] text-slate-500">Active risk mitigations and governance controls</p>
              </div>
            </div>
            <button
              onClick={() => onNavigateTab('reports')}
              className="text-xs font-bold text-[#1B4D3E] hover:underline"
            >
              Full Risk Audit
            </button>
          </div>

          <div className="space-y-3">
            {openRisks.map((risk) => (
              <div key={risk.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        risk.severity === 'high'
                          ? 'bg-rose-100 text-rose-800'
                          : risk.severity === 'medium'
                          ? 'bg-amber-100 text-amber-900'
                          : 'bg-emerald-100 text-emerald-900'
                      }`}
                    >
                      {risk.severity} SEVERITY
                    </span>
                    <h4 className="font-bold text-slate-900 text-xs">{risk.title}</h4>
                  </div>
                  <span className="font-mono text-[10px] text-slate-400">{risk.daysOpen} days open</span>
                </div>

                <p className="text-slate-600 text-[11px]"><strong className="text-slate-800">Mitigation:</strong> {risk.mitigation}</p>

                <div className="flex justify-between items-center text-[10px] pt-1.5 border-t border-slate-200/60 text-slate-500">
                  <span>Probability: <strong>{risk.probability}</strong> • Impact: <strong>{risk.impact}</strong></span>
                  <span className="bg-emerald-100 text-emerald-900 font-bold px-2 py-0.5 rounded">{risk.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 3. RESOURCE CAPACITY & BUDGET BURNDOWN GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* RESOURCE & WORKLOAD CAPACITY */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center font-bold">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 font-serif">Field Crew Capacity & Workload</h3>
                <p className="text-[11px] text-slate-500">Regional installer team allocations & bandwidth</p>
              </div>
            </div>
            <button
              onClick={() => onNavigateTab('kanban')}
              className="text-xs font-bold text-purple-800 hover:underline"
            >
              Manage Crews
            </button>
          </div>

          <div className="space-y-3">
            {teamWorkloads.map((team) => (
              <div key={team.name} className="space-y-1 text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-800">{team.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-slate-500">{team.active}/{team.capacity} Sites ({team.pct}%)</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        team.status === 'overloaded'
                          ? 'bg-rose-100 text-rose-800'
                          : team.status === 'underutilized'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {team.status.toUpperCase()}
                    </span>
                  </div>
                </div>

                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      team.status === 'overloaded' ? 'bg-rose-500' : team.status === 'underutilized' ? 'bg-blue-500' : 'bg-emerald-600'
                    }`}
                    style={{ width: `${Math.min(team.pct, 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* BUDGET BURNDOWN & FINANCIALS */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                <BarChart3 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 font-serif">Budget Health & Capital Burndown</h3>
                <p className="text-[11px] text-slate-500">Planned allocation vs actual Ecobank revenue collection</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-800">
              Target: GMD 25,000,000
            </span>
          </div>

          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-center">
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Program Budget</span>
                <strong className="text-slate-900 text-sm">
                  {isUnionAdmin ? '[Restricted]' : formatCurrency(25000000, currency)}
                </strong>
              </div>
              <div className="bg-emerald-50 p-3 rounded-2xl border border-emerald-200">
                <span className="text-[10px] uppercase font-bold text-emerald-800 block">Verified Collected</span>
                <strong className="text-emerald-900 text-sm">
                  {isUnionAdmin ? '[Restricted]' : formatCurrency(metrics.totalCollectedGMD, currency)}
                </strong>
              </div>
              <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 col-span-2 sm:col-span-1">
                <span className="text-[10px] uppercase font-bold text-amber-800 block">Quoted Contract Value</span>
                <strong className="text-amber-900 text-sm">
                  {isUnionAdmin ? '[Restricted]' : formatCurrency(metrics.totalQuotedGMD, currency)}
                </strong>
              </div>
            </div>

            {/* Burndown Bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-[11px] font-semibold text-slate-600">
                <span>Program Revenue Secured ({Math.round((metrics.totalCollectedGMD / 25000000) * 100)}%)</span>
                <span>GMD 25.0M Target</span>
              </div>
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden p-0.5 border border-slate-200">
                <div
                  className="bg-gradient-to-r from-emerald-600 to-amber-500 h-full rounded-full transition-all"
                  style={{ width: `${Math.min((metrics.totalCollectedGMD / 25000000) * 100, 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* LIVE ECOSYSTEM FEEDS: THINGSBOARD IOT TELEMETRY & ERPNEXT HR ROSTER */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SolarTelemetryWidget />
        <StaffRosterWidget />
      </div>

      {/* ENTERPRISE DEPLOYMENT READINESS & DIAGNOSTICS */}
      <DeploymentReadinessWidget />

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Leads / Clients */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between text-slate-500 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Clients / Leads</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-slate-900">{metrics.totalLeads}</div>
          <div className="mt-2 text-xs text-slate-500 flex items-center gap-1.5">
            <span className="text-emerald-600 font-semibold flex items-center">
              <TrendingUp className="w-3.5 h-3.5" /> +12% MoM
            </span>
            <span>GTUCCU, NAGNMC & Diaspora</span>
          </div>
        </div>

        {/* Active Installations */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between text-slate-500 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Active Field Projects</span>
            <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
              <Wrench className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-slate-900">{metrics.activeInstallations}</div>
          <div className="mt-2 text-xs text-slate-500 flex items-center justify-between">
            <span>In progress or scheduled crew</span>
            <button
              onClick={() => onNavigateTab('kanban')}
              className="text-purple-700 font-semibold hover:underline flex items-center text-[11px]"
            >
              View Kanban <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Revenue Collected */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between text-slate-500 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Ecobank Revenue Collected</span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-emerald-800">
            {isUnionAdmin ? (
              <span className="text-slate-400 text-sm font-mono bg-slate-100 px-2 py-1 rounded">
                [Restricted - Union View]
              </span>
            ) : (
              formatCurrency(metrics.totalCollectedGMD, currency)
            )}
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center gap-1">
            <span>
              Quoted: {isUnionAdmin ? '[Restricted]' : formatCurrency(metrics.totalQuotedGMD, currency)}
            </span>
          </div>
        </div>

        {/* Pending Teller Confirmations */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between text-slate-500 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Awaiting Finance Verification</span>
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-amber-700">
            {metrics.pendingConfirmationPayments}
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center justify-between">
            <span>Teller & Bank Transfers</span>
            <button
              onClick={() => onNavigateTab('payments')}
              className="text-amber-700 font-semibold hover:underline flex items-center text-[11px]"
            >
              Confirm Now <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Segment Breakdown & Quick Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Client Segment Cards */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 font-serif">Client Segment Performance</h2>
              <p className="text-xs text-slate-500">Distribution across institutional unions and individual clients</p>
            </div>
            <button
              onClick={() => onNavigateTab('clients')}
              className="text-xs font-semibold text-[#1B4D3E] hover:underline flex items-center gap-1"
            >
              View All Clients <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            {/* GTUCCU */}
            <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Building2 className="w-4 h-4 text-emerald-700" />
                  <span className="font-bold text-sm text-emerald-950">GTUCCU Members</span>
                </div>
                <p className="text-xs text-emerald-800">Teachers Credit Union Salary Deduction</p>
                <div className="mt-3 text-2xl font-extrabold text-emerald-900">
                  {metrics.segmentCounts.gtuccu_member} <span className="text-xs font-normal text-slate-600">clients (+2.1% MoM)</span>
                </div>
              </div>
              <span className="bg-emerald-200 text-emerald-900 text-[10px] font-bold px-2 py-0.5 rounded-full">
                Credit Approved
              </span>
            </div>

            {/* NAGNMC */}
            <div className="p-4 rounded-xl bg-teal-50/70 border border-teal-200 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <ShieldCheck className="w-4 h-4 text-teal-700" />
                  <span className="font-bold text-sm text-teal-950">NAGNMC Healthcare</span>
                </div>
                <p className="text-xs text-teal-800">Nurses & Midwives Council Scheme</p>
                <div className="mt-3 text-2xl font-extrabold text-teal-900">
                  {metrics.segmentCounts.nagnmc_member} <span className="text-xs font-normal text-slate-600">clients (+12.0% MoM)</span>
                </div>
              </div>
              <span className="bg-teal-200 text-teal-900 text-[10px] font-bold px-2 py-0.5 rounded-full">
                Fastest Growing
              </span>
            </div>

            {/* Diaspora */}
            <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Globe className="w-4 h-4 text-amber-700" />
                  <span className="font-bold text-sm text-amber-950">Diaspora Clients</span>
                </div>
                <p className="text-xs text-amber-800">UK, US & Europe Foreign Transfers</p>
                <div className="mt-3 text-2xl font-extrabold text-amber-900">
                  {metrics.segmentCounts.diaspora} <span className="text-xs font-normal text-slate-600">clients (+5.3% MoM)</span>
                </div>
              </div>
              <span className="bg-amber-200 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-full">
                High Margin
              </span>
            </div>

            {/* Non-Union Individuals */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <UserCheck className="w-4 h-4 text-slate-700" />
                  <span className="font-bold text-sm text-slate-900">Non-Union Individuals</span>
                </div>
                <p className="text-xs text-slate-600">Direct Bank & Teller Cash Payments</p>
                <div className="mt-3 text-2xl font-extrabold text-slate-900">
                  {metrics.segmentCounts.non_union_individual} <span className="text-xs font-normal text-slate-600">clients (+1.8% MoM)</span>
                </div>
              </div>
              <span className="bg-slate-200 text-slate-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                Direct
              </span>
            </div>
          </div>

          {/* Project Stage Progress Bar */}
          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase text-slate-500 mb-3">8-Stage Installation Pipeline Summary</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-center">
                <span className="text-slate-500 block text-[10px]">1. Leads & Assessment</span>
                <strong className="text-slate-900 text-base">{metrics.stageCounts.lead + metrics.stageCounts.assessment_scheduled + metrics.stageCounts.assessment_complete}</strong>
              </div>
              <div className="bg-amber-50 p-2.5 rounded-lg border border-amber-200 text-center">
                <span className="text-amber-800 block text-[10px]">2. Payment Pending</span>
                <strong className="text-amber-900 text-base">{metrics.stageCounts.payment_pending}</strong>
              </div>
              <div className="bg-purple-50 p-2.5 rounded-lg border border-purple-200 text-center">
                <span className="text-purple-800 block text-[10px]">3. Active Field Crews</span>
                <strong className="text-purple-900 text-base">{metrics.stageCounts.installation_scheduled + metrics.stageCounts.installation_in_progress}</strong>
              </div>
              <div className="bg-emerald-50 p-2.5 rounded-lg border border-emerald-200 text-center">
                <span className="text-emerald-800 block text-[10px]">4. Commissioned</span>
                <strong className="text-emerald-900 text-base">{metrics.stageCounts.commissioning + metrics.stageCounts.completed}</strong>
              </div>
            </div>
          </div>
        </div>

        {/* Scrollable Recent System Activity Log */}
        <div className="lg:col-span-1 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div>
                <h2 className="text-base font-bold text-slate-900 font-serif flex items-center gap-2">
                  <Activity className="w-4 h-4 text-[#1B4D3E]" />
                  <span>System Activity Stream</span>
                </h2>
                <p className="text-[11px] text-slate-500">Live events & audit log</p>
              </div>
              <span className="flex items-center gap-1 text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-ping"></span>
                Live
              </span>
            </div>

            {/* Filter Chips */}
            <div className="flex items-center gap-1 text-[10px] overflow-x-auto pb-2 border-b border-slate-100 scrollbar-none">
              {(['all', 'lead', 'payment', 'installation', 'assessment'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setActivityFilter(f)}
                  className={`px-2.5 py-1 rounded-md font-bold uppercase transition-colors whitespace-nowrap cursor-pointer ${
                    activityFilter === f
                      ? 'bg-[#1B4D3E] text-amber-300 shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {f === 'all' ? 'All' : f}
                </button>
              ))}
            </div>

            {/* Scrollable Log Stream */}
            <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1 text-xs mt-3">
              {filteredLogs.length === 0 ? (
                <p className="text-slate-400 italic text-center py-8">No log events recorded for this category.</p>
              ) : (
                filteredLogs.map((log, idx) => {
                  const badge = getActivityBadge(log.action, log.details);
                  const Icon = badge.icon;

                  return (
                    <div
                      key={`${log.id}-${idx}`}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 hover:border-slate-300 transition-all space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${badge.color}`}>
                          <Icon className="w-3 h-3 shrink-0" />
                          <span>{badge.label}</span>
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <p className="text-slate-800 font-medium leading-snug">{log.details}</p>

                      <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-200/50">
                        <span className="font-bold text-slate-700">{log.actorName}</span>
                        <span className="capitalize font-mono text-emerald-800">{log.actorRole.replace('_', ' ')}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Showing {filteredLogs.length} events</span>
            <button
              onClick={() => onNavigateTab('reports')}
              className="text-[#1B4D3E] font-bold hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              Export Audit Log <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Solar Asset & Appliance Capability Matrix */}
      <SolarPackageSection
        currency={currency}
        onOpenAIAssistant={() => onNavigateTab('ai_copilot')}
        onSelectPackage={() => onNewClient()}
      />

      {/* Recent Clients Table Preview */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900 font-serif">Recent Client Onboardings</h2>
            <p className="text-xs text-slate-500">Quick action pipeline overview</p>
          </div>
          <button
            onClick={() => onNavigateTab('clients')}
            className="text-xs font-semibold text-[#1B4D3E] hover:underline flex items-center gap-1"
          >
            Manage All Clients <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 uppercase font-semibold text-[10px] tracking-wider">
                <th className="p-3">Client Name</th>
                <th className="p-3">Segment</th>
                <th className="p-3">Package</th>
                <th className="p-3">Stage</th>
                <th className="p-3">Financing</th>
                <th className="p-3">Quoted GMD</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {clients.slice(0, 5).map((client) => (
                <tr key={client.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="p-3 font-bold text-slate-900">
                    <div>{client.fullName}</div>
                    <div className="text-[11px] font-normal text-slate-500">{client.email}</div>
                  </td>
                  <td className="p-3">
                    <span className="bg-slate-100 text-slate-800 border border-slate-200 px-2 py-0.5 rounded text-[11px] font-medium">
                      {client.clientSegment.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="p-3 font-medium text-slate-800">
                    {client.packageId.replace('_', ' ').toUpperCase()}
                  </td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${getStageColor(client.projectStage)}`}>
                      {getStageLabel(client.projectStage)}
                    </span>
                  </td>
                  <td className="p-3 capitalize font-medium text-slate-600">
                    {client.financingType.replace('_', ' ')}
                  </td>
                  <td className="p-3 font-bold text-slate-900">
                    {formatCurrency(client.totalQuotedGMD, currency)}
                  </td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => onSelectClient(client)}
                      className="bg-[#1B4D3E] hover:bg-[#143B2F] text-white px-3 py-1 rounded-lg font-semibold text-xs transition-colors cursor-pointer"
                    >
                      View Profile
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
