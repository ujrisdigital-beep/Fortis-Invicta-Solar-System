import React, { useState, useEffect } from 'react';
import { ApiOrchestrator, ThingsBoardLiveTelemetry, ORCHESTRATOR_ENV } from '../../services/api/orchestrator';
import { Activity, Zap, Battery, AlertTriangle, RefreshCw, Radio, CheckCircle, WifiOff } from 'lucide-react';

interface SolarTelemetryWidgetProps {
  deviceId?: string;
}

export const SolarTelemetryWidget: React.FC<SolarTelemetryWidgetProps> = ({
  deviceId = ORCHESTRATOR_ENV.SOLAR_DEVICE_ID
}) => {
  const [telemetry, setTelemetry] = useState<ThingsBoardLiveTelemetry | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorState, setErrorState] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  const fetchLiveTelemetry = async () => {
    try {
      setLoading(true);
      const result = await ApiOrchestrator.fetchTelemetry(deviceId);
      if (result && result.success && result.data) {
        setTelemetry(result.data);
        setErrorState(null);
        setLastUpdated(new Date().toLocaleTimeString());
      } else {
        setErrorState(result?.error || `Service Offline: ThingsBoard on ${ORCHESTRATOR_ENV.THINGSBOARD_URL}`);
        setTelemetry(null);
      }
    } catch {
      setErrorState(`Service Offline: ThingsBoard on ${ORCHESTRATOR_ENV.THINGSBOARD_URL}`);
      setTelemetry(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      try {
        setLoading(true);
        const result = await ApiOrchestrator.fetchTelemetry(deviceId);
        if (!isMounted) return;
        if (result && result.success && result.data) {
          setTelemetry(result.data);
          setErrorState(null);
          setLastUpdated(new Date().toLocaleTimeString());
        } else {
          setErrorState(result?.error || `Service Offline: ThingsBoard on ${ORCHESTRATOR_ENV.THINGSBOARD_URL}`);
          setTelemetry(null);
        }
      } catch {
        if (!isMounted) return;
        setErrorState(`Service Offline: ThingsBoard on ${ORCHESTRATOR_ENV.THINGSBOARD_URL}`);
        setTelemetry(null);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    load();
    const interval = setInterval(load, 10000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [deviceId]);

  return (
    <div id="solar-telemetry-widget" className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-emerald-50 text-[#1B4D3E] rounded-xl">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 font-serif">ThingsBoard IoT Telemetry Hub</h3>
            <p className="text-xs text-slate-500 flex items-center gap-1.5">
              <Radio className="w-3 h-3 text-emerald-600 animate-pulse" />
              Live Inverter Gateway ({deviceId.substring(0, 12)}...)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchLiveTelemetry}
            disabled={loading}
            className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors"
            title="Refresh Telemetry"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Explicit Error State Banner if Offline */}
      {errorState ? (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200/80 space-y-2">
          <div className="flex items-center gap-2 text-amber-800 text-xs font-semibold">
            <WifiOff className="w-4 h-4 text-amber-600 shrink-0" />
            <span>{errorState}</span>
          </div>
          <p className="text-[11px] text-amber-700">
            Ensure local ThingsBoard container is active: <code className="bg-amber-100/80 px-1.5 py-0.5 rounded font-mono">docker-compose up -d thingsboard</code>.
          </p>
        </div>
      ) : telemetry ? (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
          {/* PV Generation */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
              <span>Solar PV</span>
              <Zap className="w-3.5 h-3.5 text-amber-500" />
            </div>
            <p className="text-lg font-bold text-slate-900">{telemetry.pvPowerWatts} W</p>
            <p className="text-[10px] text-slate-400">Peak Array</p>
          </div>

          {/* Battery State of Charge */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
              <span>Battery SoC</span>
              <Battery className="w-3.5 h-3.5 text-emerald-600" />
            </div>
            <p className="text-lg font-bold text-slate-900">{telemetry.batterySocPercent}%</p>
            <p className="text-[10px] text-slate-400">{telemetry.batteryVoltageVolts}V DC</p>
          </div>

          {/* AC Load */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
              <span>AC Load</span>
              <Zap className="w-3.5 h-3.5 text-blue-500" />
            </div>
            <p className="text-lg font-bold text-slate-900">{telemetry.loadPowerWatts} W</p>
            <p className="text-[10px] text-slate-400">{telemetry.gridVoltageVolts}V AC</p>
          </div>

          {/* Daily Yield */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
              <span>Daily Yield</span>
              <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
            </div>
            <p className="text-lg font-bold text-slate-900">{telemetry.dailyYieldKWh} kWh</p>
            <p className="text-[10px] text-slate-400">Status: {telemetry.inverterStatus}</p>
          </div>
        </div>
      ) : (
        <div className="p-6 text-center text-slate-400 text-xs">
          Loading live telemetry...
        </div>
      )}

      {lastUpdated && !errorState && (
        <div className="text-right text-[10px] text-slate-400">
          Last polled: {lastUpdated}
        </div>
      )}
    </div>
  );
};
