import React, { useState, useEffect } from 'react';
import { ApiOrchestrator, EmployeeRosterItem, ORCHESTRATOR_ENV } from '../../services/api/orchestrator';
import { Users, Building, Mail, Phone, RefreshCw, AlertCircle, ShieldCheck } from 'lucide-react';

export const StaffRosterWidget: React.FC = () => {
  const [employees, setEmployees] = useState<EmployeeRosterItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorState, setErrorState] = useState<string | null>(null);

  const fetchRoster = async () => {
    try {
      setLoading(true);
      const result = await ApiOrchestrator.fetchStaffRoster();
      if (result && result.success && result.data && result.data.length > 0) {
        setEmployees(result.data);
        setErrorState(null);
      } else {
        setErrorState(result?.error || `Service Offline: ERPNext on ${ORCHESTRATOR_ENV.ERPNEXT_URL}`);
        setEmployees([]);
      }
    } catch {
      setErrorState(`Service Offline: ERPNext on ${ORCHESTRATOR_ENV.ERPNEXT_URL}`);
      setEmployees([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      try {
        setLoading(true);
        const result = await ApiOrchestrator.fetchStaffRoster();
        if (!isMounted) return;
        if (result && result.success && result.data && result.data.length > 0) {
          setEmployees(result.data);
          setErrorState(null);
        } else {
          setErrorState(result?.error || `Service Offline: ERPNext on ${ORCHESTRATOR_ENV.ERPNEXT_URL}`);
          setEmployees([]);
        }
      } catch {
        if (!isMounted) return;
        setErrorState(`Service Offline: ERPNext on ${ORCHESTRATOR_ENV.ERPNEXT_URL}`);
        setEmployees([]);
      } finally {
        if (isMounted) setLoading(false);
      }
    };
    load();
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div id="staff-roster-widget" className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-purple-50 text-purple-800 rounded-xl">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 font-serif">ERPNext HR & Engineering Roster</h3>
            <p className="text-xs text-slate-500">Live directory queried from ERPNext</p>
          </div>
        </div>

        <button
          onClick={fetchRoster}
          disabled={loading}
          className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors"
          title="Refresh Roster"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {errorState ? (
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
          <div className="flex items-center gap-2 text-slate-700 text-xs font-semibold">
            <AlertCircle className="w-4 h-4 text-amber-500 shrink-0" />
            <span>{errorState}</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Ensure local ERPNext container is listening on <code className="bg-slate-200/80 px-1 py-0.5 rounded font-mono">{ORCHESTRATOR_ENV.ERPNEXT_URL}</code>.
          </p>
        </div>
      ) : employees.length > 0 ? (
        <div className="divide-y divide-slate-100 max-h-60 overflow-y-auto">
          {employees.map((emp, idx) => (
            <div key={emp.name || idx} className="py-2.5 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-900">{emp.employee_name || emp.name}</p>
                <p className="text-[11px] text-slate-500">{emp.designation} • {emp.department}</p>
              </div>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-[#1B4D3E] border border-emerald-200">
                {emp.status || 'Active'}
              </span>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-4 text-center text-slate-400 text-xs">
          No employee records returned from ERPNext.
        </div>
      )}
    </div>
  );
};
