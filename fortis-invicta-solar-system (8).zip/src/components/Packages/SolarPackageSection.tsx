import React, { useState } from 'react';
import {
  Sun,
  Zap,
  Battery,
  ShieldCheck,
  Tv,
  Fan,
  Snowflake,
  Droplets,
  Lightbulb,
  Laptop,
  Flame,
  CheckCircle2,
  Info,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  Sparkles,
  Wrench,
  Building2,
  Edit3,
  Save,
  RotateCcw,
  DollarSign,
  TrendingUp,
  X
} from 'lucide-react';
import { Currency, SolarPackage, SupportedApplianceItem, ForexInflationConfig, UserRole } from '../../types';
import { StorageService } from '../../services/storage';
import { formatPriceRange, formatCurrency } from '../../utils/formatters';

interface SolarPackageSectionProps {
  currency: Currency;
  userRole?: UserRole;
  onSelectPackage?: (pkg: SolarPackage) => void;
  onOpenAIAssistant?: () => void;
}

export const SolarPackageSection: React.FC<SolarPackageSectionProps> = ({
  currency,
  userRole = 'super_admin',
  onSelectPackage,
  onOpenAIAssistant
}) => {
  const canEditMasterPricing = userRole === 'super_admin' || userRole === 'project_manager' || userRole === 'finance_officer';
  const [packagesList, setPackagesList] = useState<SolarPackage[]>(() => StorageService.getPackages());
  const [forexConfig, setForexConfig] = useState<ForexInflationConfig>(() => StorageService.getForexConfig());
  const [expandedPackageId, setExpandedPackageId] = useState<string>('hybrid_standard');

  // Interactive Forex & Inflation Live Simulation Buffer
  const [simulatedInflationPercent, setSimulatedInflationPercent] = useState<number>(0);

  // Master Price & Forex Editing Modal
  const [isEditingPricesModal, setIsEditingPricesModal] = useState(false);
  const [editingUsdRate, setEditingUsdRate] = useState<number>(forexConfig.usdToGmdRate);
  const [editingGbpRate, setEditingGbpRate] = useState<number>(forexConfig.gbpToGmdRate);
  const [editingGlobalInflation, setEditingGlobalInflation] = useState<number>(forexConfig.globalInflationPercent);
  const [editingPackageId, setEditingPackageId] = useState<string>('hybrid_standard');
  const [editingMinGMD, setEditingMinGMD] = useState<number>(320000);
  const [editingMaxGMD, setEditingMaxGMD] = useState<number>(380000);

  const getCategoryIcon = (category: SupportedApplianceItem['category']) => {
    switch (category) {
      case 'lighting':
        return <Lightbulb className="w-4 h-4 text-amber-500" />;
      case 'cooling':
        return <Fan className="w-4 h-4 text-cyan-500" />;
      case 'refrigeration':
        return <Snowflake className="w-4 h-4 text-blue-500" />;
      case 'pumping':
        return <Droplets className="w-4 h-4 text-[#1B4D3E]" />;
      case 'appliances':
        return <Tv className="w-4 h-4 text-purple-500" />;
      case 'medical_heavy':
        return <Building2 className="w-4 h-4 text-rose-500" />;
      default:
        return <Zap className="w-4 h-4 text-amber-500" />;
    }
  };

  const handleOpenEditModal = (pkgId?: string) => {
    const targetId = pkgId || 'hybrid_standard';
    const targetPkg = packagesList.find((p) => p.id === targetId) || packagesList[0];
    setEditingPackageId(targetPkg.id);
    setEditingMinGMD(targetPkg.priceMinGMD);
    setEditingMaxGMD(targetPkg.priceMaxGMD);
    setEditingUsdRate(forexConfig.usdToGmdRate);
    setEditingGbpRate(forexConfig.gbpToGmdRate);
    setEditingGlobalInflation(forexConfig.globalInflationPercent);
    setIsEditingPricesModal(true);
  };

  const handleSaveMasterConfig = (e: React.FormEvent) => {
    e.preventDefault();
    // 1. Save Forex Config
    const updatedForex = StorageService.saveForexConfig(
      {
        usdToGmdRate: editingUsdRate,
        gbpToGmdRate: editingGbpRate,
        globalInflationPercent: editingGlobalInflation,
        lastUpdated: new Date().toISOString(),
        updatedBy: 'Finance / Admin Officer'
      },
      'Finance / Admin Officer'
    );
    setForexConfig(updatedForex);

    // 2. Save Selected Package Price
    const pkgToUpdate = packagesList.find((p) => p.id === editingPackageId);
    if (pkgToUpdate) {
      const updatedPkg: SolarPackage = {
        ...pkgToUpdate,
        priceMinGMD: editingMinGMD,
        priceMaxGMD: editingMaxGMD
      };
      StorageService.savePackage(updatedPkg, 'Finance / Admin Officer');
      setPackagesList(StorageService.getPackages());
    }

    setIsEditingPricesModal(false);
  };

  return (
    <div className="bg-gradient-to-b from-[#0F1E18] to-[#162D24] rounded-3xl p-6 sm:p-8 text-white border border-[#235847] shadow-xl space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-b border-emerald-800/60 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-amber-500/20 text-amber-300 border border-amber-500/40 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3">
            <Sun className="w-3.5 h-3.5 fill-current" />
            Fortis Invicta Solar Asset Matrix
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-white tracking-wide">
            Solar Packages, Asset Specifications & Dynamic Application Pricing
          </h2>
          <p className="text-sm text-emerald-200/90 max-w-2xl mt-1.5 leading-relaxed">
            Transparent pricing ranges tailored for Gambian homes, business compounds, and institutional members. Prices fluctuate dynamically with global forex rates & inflation buffers at time of application.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => handleOpenEditModal()}
            className="flex items-center gap-2 bg-emerald-900/80 hover:bg-emerald-800 text-amber-300 border border-amber-500/40 px-4 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer"
          >
            <Edit3 className="w-4 h-4 text-amber-400" />
            <span>Update Master Base Prices & Forex Index</span>
          </button>

          {onOpenAIAssistant && (
            <button
              onClick={onOpenAIAssistant}
              className="shrink-0 flex items-center gap-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-lg transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 fill-current" />
              <span>Calculate Custom Load with AI</span>
            </button>
          )}
        </div>
      </div>

      {/* Dynamic Forex & Inflation Price Adjustment Control Bar */}
      <div className="bg-[#12241D] p-4 rounded-2xl border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <span className="font-extrabold text-xs text-amber-300 uppercase tracking-wider">
              Application-Time Inflation & Forex Buffer Simulation
            </span>
          </div>
          <p className="text-[11px] text-emerald-200/80">
            Current Forex Index: <strong>1 USD = {forexConfig.usdToGmdRate} GMD</strong> | Base Inflation Index: <strong>{forexConfig.globalInflationPercent}%</strong>. Adjust buffer to project live application prices.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0 bg-[#0A1612] p-1.5 rounded-xl border border-emerald-800">
          <span className="text-[11px] font-bold text-slate-300 px-2">Inflation Adjustment:</span>
          {[0, 5, 10, 15, 20].map((percent) => (
            <button
              key={percent}
              onClick={() => setSimulatedInflationPercent(percent)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                simulatedInflationPercent === percent
                  ? 'bg-amber-400 text-slate-950 shadow-md'
                  : 'bg-emerald-900/50 text-emerald-200 hover:bg-emerald-800/80'
              }`}
            >
              +{percent}%
            </button>
          ))}
        </div>
      </div>

      {/* Package Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {packagesList.map((pkg) => {
          const isExpanded = expandedPackageId === pkg.id;

          // Calculate live simulated dynamic price with inflation & forex buffer
          const displayMinGMD = Math.round(pkg.priceMinGMD * (1 + simulatedInflationPercent / 100));
          const displayMaxGMD = Math.round(pkg.priceMaxGMD * (1 + simulatedInflationPercent / 100));

          return (
            <div
              key={pkg.id}
              data-testid={pkg.id === 'hybrid_standard' ? 'tier-2-hybrid' : `tier-${pkg.id}`}
              className={`rounded-2xl transition-all duration-300 flex flex-col justify-between overflow-hidden border ${
                isExpanded
                  ? 'bg-[#152B23] border-[#C9A84C] ring-2 ring-[#C9A84C]/30 shadow-2xl scale-[1.01]'
                  : 'bg-[#12241D]/90 border-emerald-800/80 hover:border-emerald-600'
              }`}
            >
              <div>
                {/* Image Header with Price Tag Overlay */}
                <div className="relative h-44 overflow-hidden group">
                  <img
                    src={pkg.image}
                    alt={pkg.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#12241D] via-transparent to-black/30" />

                  <div className="absolute top-3 left-3 bg-[#12241D]/90 backdrop-blur-md px-2.5 py-1 rounded-lg border border-amber-500/40 text-[11px] font-semibold text-amber-300 flex items-center gap-1.5">
                    <Zap className="w-3 h-3 text-amber-400 fill-amber-400" />
                    <span>{pkg.inverterCapacity}</span>
                  </div>

                  {canEditMasterPricing && (
                    <button
                      onClick={() => handleOpenEditModal(pkg.id)}
                      title="Edit Master Package Base Rate"
                      className="absolute top-3 right-3 bg-[#0A1612]/90 hover:bg-amber-500 hover:text-slate-950 text-amber-300 border border-amber-500/40 p-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Edit3 className="w-3 h-3" />
                    </button>
                  )}

                  {/* Price Range Badge */}
                  <div className="absolute bottom-3 left-3 right-3 bg-[#0D1A15]/95 backdrop-blur-md p-2.5 rounded-xl border border-emerald-600/60 shadow-lg">
                    <div className="flex justify-between items-center text-[10px] uppercase tracking-wider text-emerald-300 font-bold">
                      <span>Application Price Range</span>
                      {simulatedInflationPercent > 0 && (
                        <span className="text-amber-400 font-mono">+{simulatedInflationPercent}% Buffer</span>
                      )}
                    </div>
                    <div className="text-base sm:text-lg font-black text-amber-300 font-serif mt-0.5">
                      {formatPriceRange(displayMinGMD, displayMaxGMD, currency)}
                    </div>
                  </div>
                </div>

                {/* Card Content Body */}
                <div className="p-5 space-y-4">
                  <div>
                    {pkg.tier && (
                      <span className="inline-block px-2.5 py-0.5 mb-2 rounded-md text-[10px] font-extrabold uppercase tracking-wider bg-amber-400/20 text-amber-300 border border-amber-500/40">
                        {pkg.tier}
                      </span>
                    )}
                    <h3 className="text-lg font-bold text-white font-serif">{pkg.name}</h3>
                    <p className="text-xs text-amber-300/90 font-medium mt-0.5">{pkg.tagline}</p>
                    <p className="text-xs text-emerald-100/80 mt-2 leading-relaxed">
                      {pkg.description}
                    </p>
                  </div>

                  {/* Solar Asset Summary Pills */}
                  <div className="bg-[#0A1612] rounded-xl p-3 border border-emerald-900/80 space-y-2 text-xs">
                    <div className="flex items-center gap-2 text-emerald-200">
                      <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span className="font-semibold text-white">Panels:</span>
                      <span className="text-emerald-300 truncate">{pkg.solarPanels}</span>
                    </div>

                    <div className="flex items-center gap-2 text-emerald-200">
                      <Battery className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="font-semibold text-white">Battery:</span>
                      <span className="text-emerald-300 truncate">{pkg.batteryBank}</span>
                    </div>

                    <div className="flex items-center gap-2 text-emerald-200">
                      <Wrench className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="font-semibold text-white">Inverter:</span>
                      <span className="text-emerald-300 truncate">{pkg.inverterCapacity}</span>
                    </div>
                  </div>

                  {/* Supported Appliances Quick Preview */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-amber-300 uppercase tracking-wider">
                      <span>Supported Appliances</span>
                      <span className="text-[10px] text-emerald-400 font-normal">
                        ({pkg.supportedAppliances.length} Items)
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs">
                      {pkg.supportedAppliances.slice(0, isExpanded ? 10 : 3).map((app, idx) => (
                        <div
                          key={idx}
                          className="flex items-start gap-2 bg-[#12241D] p-2 rounded-lg border border-emerald-800/50 hover:border-emerald-700 transition-colors"
                        >
                          <div className="mt-0.5 shrink-0">{getCategoryIcon(app.category)}</div>
                          <div className="min-w-0">
                            <span className="font-bold text-white block truncate">{app.name}</span>
                            <span className="text-[10px] text-emerald-300/80 block">{app.countOrCapacity}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Full Assets Spec (Visible when expanded) */}
                  {isExpanded && (
                    <div className="pt-3 border-t border-emerald-800/80 space-y-3 animate-fadeIn">
                      <div className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                        <span>Included Solar Assets</span>
                      </div>

                      <div className="space-y-2 text-[11px] text-emerald-100/90">
                        <div className="bg-[#0A1612] p-2 rounded-lg border border-emerald-900">
                          <strong className="text-amber-300 block">Racking & Mounting:</strong>
                          <span>{pkg.solarAssets.mountingRacking}</span>
                        </div>

                        <div className="bg-[#0A1612] p-2 rounded-lg border border-emerald-900">
                          <strong className="text-amber-300 block">Switchgear & Protection:</strong>
                          <span>{pkg.solarAssets.protectionSwitchgear}</span>
                        </div>

                        <div className="bg-[#0A1612] p-2 rounded-lg border border-emerald-900">
                          <strong className="text-amber-300 block">Cabling & Accessories:</strong>
                          <span>{pkg.solarAssets.cablingAccessories}</span>
                        </div>
                      </div>

                      <div className="bg-emerald-900/40 p-2.5 rounded-xl border border-emerald-700/60 text-[11px] text-emerald-200">
                        <strong className="text-white block mb-0.5">Recommended Application:</strong>
                        {pkg.recommendedFor}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Footer Actions */}
              <div className="p-5 pt-0 space-y-2">
                <button
                  onClick={() => setExpandedPackageId(isExpanded ? '' : pkg.id)}
                  className="w-full py-2 px-3 rounded-xl text-xs font-semibold text-emerald-200 hover:text-white bg-emerald-900/50 hover:bg-emerald-800/80 border border-emerald-700/60 flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>{isExpanded ? 'Hide Specs' : 'View Assets & Specs'}</span>
                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>

                {onSelectPackage && (
                  <button
                    onClick={() => onSelectPackage(pkg)}
                    className="w-full bg-[#C9A84C] hover:bg-amber-400 text-slate-950 font-bold py-2.5 px-4 rounded-xl text-xs transition-colors flex items-center justify-center gap-2 shadow-md cursor-pointer"
                  >
                    <span>Proceed to Payment</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
                <div className="text-[10px] text-center text-emerald-300/80 pt-0.5">
                  80% Required Deposit: <span className="deposit-amount font-mono font-bold text-amber-300">{formatCurrency(Math.round(displayMinGMD * 0.8), currency)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Master Price & Forex Editing Modal */}
      {isEditingPricesModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12241D] text-white border border-amber-500/40 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-emerald-800 pb-3">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-amber-400" />
                <h3 className="text-lg font-bold font-serif text-amber-300">
                  Update Master Pricing & Forex Exchange Index
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsEditingPricesModal(false)}
                className="w-8 h-8 rounded-full bg-emerald-900 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveMasterConfig} className="space-y-4 text-xs">
              {/* Forex Exchange Rates */}
              <div className="p-4 bg-[#0A1612] rounded-2xl border border-emerald-800 space-y-3">
                <h4 className="font-bold text-amber-300 flex items-center gap-1.5 uppercase text-[11px] tracking-wider">
                  <DollarSign className="w-4 h-4 text-amber-400" />
                  1. Central Foreign Exchange Rates
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-emerald-200 mb-1">USD to GMD Rate</label>
                    <input
                      type="number"
                      step="0.1"
                      required
                      value={editingUsdRate}
                      onChange={(e) => setEditingUsdRate(Number(e.target.value))}
                      className="w-full bg-[#12241D] border border-emerald-700 p-2 rounded-xl font-mono font-bold text-amber-300"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-emerald-200 mb-1">GBP to GMD Rate</label>
                    <input
                      type="number"
                      step="0.1"
                      required
                      value={editingGbpRate}
                      onChange={(e) => setEditingGbpRate(Number(e.target.value))}
                      className="w-full bg-[#12241D] border border-emerald-700 p-2 rounded-xl font-mono font-bold text-amber-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-emerald-200 mb-1">
                    System Global Inflation Buffer (%)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={editingGlobalInflation}
                    onChange={(e) => setEditingGlobalInflation(Number(e.target.value))}
                    className="w-full bg-[#12241D] border border-emerald-700 p-2 rounded-xl font-mono font-bold text-amber-300"
                  />
                  <span className="text-[10px] text-emerald-400 mt-1 block">
                    Automatically added to newly initiated client application quotes.
                  </span>
                </div>
              </div>

              {/* Solar Package Base Price Override */}
              <div className="p-4 bg-[#0A1612] rounded-2xl border border-emerald-800 space-y-3">
                <h4 className="font-bold text-amber-300 flex items-center gap-1.5 uppercase text-[11px] tracking-wider">
                  <Wrench className="w-4 h-4 text-amber-400" />
                  2. Select Package to Modify Base Price
                </h4>

                <select
                  value={editingPackageId}
                  onChange={(e) => {
                    const id = e.target.value;
                    setEditingPackageId(id);
                    const target = packagesList.find((p) => p.id === id);
                    if (target) {
                      setEditingMinGMD(target.priceMinGMD);
                      setEditingMaxGMD(target.priceMaxGMD);
                    }
                  }}
                  className="w-full bg-[#12241D] border border-emerald-700 p-2.5 rounded-xl font-bold text-white"
                >
                  {packagesList.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Current: GMD {p.priceMinGMD.toLocaleString()} - {p.priceMaxGMD.toLocaleString()})
                    </option>
                  ))}
                </select>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-emerald-200 mb-1">Base Price Min (GMD)</label>
                    <input
                      type="number"
                      required
                      value={editingMinGMD}
                      onChange={(e) => setEditingMinGMD(Number(e.target.value))}
                      className="w-full bg-[#12241D] border border-emerald-700 p-2 rounded-xl font-mono font-bold text-amber-300"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-emerald-200 mb-1">Base Price Max (GMD)</label>
                    <input
                      type="number"
                      required
                      value={editingMaxGMD}
                      onChange={(e) => setEditingMaxGMD(Number(e.target.value))}
                      className="w-full bg-[#12241D] border border-emerald-700 p-2 rounded-xl font-mono font-bold text-amber-300"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditingPricesModal(false)}
                  className="bg-emerald-950 text-emerald-200 hover:text-white px-4 py-2.5 rounded-xl font-bold border border-emerald-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-extrabold px-6 py-2.5 rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Save Master Base Rates
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
