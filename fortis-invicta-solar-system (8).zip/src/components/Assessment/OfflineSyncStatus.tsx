import React, { useEffect, useState } from 'react';
import { Wifi, WifiOff, RefreshCw, CheckCircle2, AlertTriangle, Database } from 'lucide-react';
import { BackgroundSync, SyncState } from '../../services/backgroundSync';

export const OfflineSyncStatus: React.FC = () => {
  const [status, setStatus] = useState<{
    isOnline: boolean;
    syncState: SyncState;
    unsyncedCount: number;
    lastSyncTime?: string;
  }>({
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    syncState: 'idle',
    unsyncedCount: 0
  });

  const [isManualSyncing, setIsManualSyncing] = useState(false);

  useEffect(() => {
    const unsubscribe = BackgroundSync.subscribe((newStatus) => {
      setStatus(newStatus);
    });
    return () => unsubscribe();
  }, []);

  const handleManualSync = async () => {
    setIsManualSyncing(true);
    try {
      await BackgroundSync.syncPendingData();
    } catch (err) {
      console.warn('[OfflineSyncStatus] Manual sync error:', err);
    } finally {
      setIsManualSyncing(false);
    }
  };

  return (
    <div className="bg-slate-900 text-white rounded-2xl p-4 border border-slate-800 shadow-md flex flex-wrap items-center justify-between gap-4 text-xs">
      <div className="flex items-center gap-3">
        {status.isOnline ? (
          <div className="flex items-center gap-1.5 bg-emerald-950/80 border border-emerald-700/60 text-emerald-400 px-3 py-1.5 rounded-full font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <Wifi className="w-3.5 h-3.5" />
            <span>Cellular Online (Gambia Telecom / Wi-Fi)</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 bg-amber-950/80 border border-amber-700/60 text-amber-300 px-3 py-1.5 rounded-full font-bold">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <WifiOff className="w-3.5 h-3.5" />
            <span>Offline Field Mode (IndexedDB Active)</span>
          </div>
        )}

        <div className="flex items-center gap-2 text-slate-300">
          <Database className="w-3.5 h-3.5 text-slate-400" />
          <span>
            {status.unsyncedCount === 0 ? (
              <span className="text-emerald-300 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> All local assessments synced
              </span>
            ) : (
              <span className="text-amber-300 font-bold">
                {status.unsyncedCount} assessment{status.unsyncedCount > 1 ? 's' : ''} queued locally
              </span>
            )}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {status.lastSyncTime && (
          <span className="text-slate-400 text-[11px]">Last sync: {status.lastSyncTime}</span>
        )}

        <button
          onClick={handleManualSync}
          disabled={!status.isOnline || isManualSyncing || status.syncState === 'syncing'}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-all text-xs cursor-pointer ${
            !status.isOnline
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
              : 'bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 shadow'
          }`}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isManualSyncing || status.syncState === 'syncing' ? 'animate-spin' : ''}`} />
          <span>{isManualSyncing || status.syncState === 'syncing' ? 'Syncing...' : 'Sync Cloud Now'}</span>
        </button>
      </div>
    </div>
  );
};
