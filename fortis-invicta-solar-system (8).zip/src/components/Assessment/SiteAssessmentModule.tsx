import React, { useState } from 'react';
import {
  ClipboardCheck,
  MapPin,
  CheckCircle2,
  FileText,
  Camera,
  Upload,
  Navigation
} from 'lucide-react';
import { AssessmentReport, Client, Currency } from '../../types';
import { OfflineSyncStatus } from './OfflineSyncStatus';
import { OfflineStorage, OfflineAssessmentRecord } from '../../services/offlineStorage';
import { BackgroundSync } from '../../services/backgroundSync';

interface SiteAssessmentModuleProps {
  assessments: AssessmentReport[];
  clients: Client[];
  currency: Currency;
  onSaveAssessment: (assessment: AssessmentReport) => void;
}

export const SiteAssessmentModule: React.FC<SiteAssessmentModuleProps> = ({
  assessments,
  clients,
  onSaveAssessment
}) => {
  const [selectedClientId, setSelectedClientId] = useState<string>(clients[0]?.id || '');
  const [roofType, setRoofType] = useState<AssessmentReport['roofType']>('corrugated_iron');
  const [roofCondition, setRoofCondition] = useState<AssessmentReport['roofCondition']>('good');
  const [sunExposureHours, setSunExposureHours] = useState<number>(8.0);
  const [shadingLevel, setShadingLevel] = useState<AssessmentReport['shadingLevel']>('minimal');
  const [outcome, setOutcome] = useState<AssessmentReport['outcome']>('approved');
  const [notes, setNotes] = useState<string>('Roof is structurally sound for monocrystalline solar mounting.');

  // GPS State
  const [gpsCoordinates, setGpsCoordinates] = useState<{ latitude: number; longitude: number } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  // Photos State
  const [capturedPhotos, setCapturedPhotos] = useState<Array<{ id: string; caption: string; dataUrl: string }>>([]);
  const [photoCaption, setPhotoCaption] = useState('Roof Structural Surface');

  // Submit Feedback
  const [submissionFeedback, setSubmissionFeedback] = useState<string | null>(null);

  const selectedClient = clients.find((c) => c.id === selectedClientId);

  // Acquire GPS Coordinates
  const handleAcquireGPS = () => {
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by this browser/device.');
      return;
    }

    setIsLocating(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setGpsCoordinates({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
        setIsLocating(false);
      },
      (error) => {
        setIsLocating(false);
        setGpsError(error.message || 'Unable to retrieve GPS coordinates.');
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  };

  // Handle Photo File Select
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const newPhoto = {
        id: `photo-${Date.now()}`,
        caption: photoCaption,
        dataUrl
      };
      setCapturedPhotos((prev) => [...prev, newPhoto]);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClient) return;

    const reportId = 'ass-' + Date.now();
    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;

    const offlineRecord: OfflineAssessmentRecord = {
      id: reportId,
      clientId: selectedClient.id,
      clientName: selectedClient.fullName,
      inspectorName: 'Sainey Jawara (Senior Inspector)',
      scheduledDate: new Date().toISOString(),
      completedDate: new Date().toISOString(),
      roofType,
      roofCondition,
      sunExposureHours,
      shadingLevel,
      electricalCompatibility: 'compatible',
      recommendedPanelCapacityKW: 3.3,
      recommendedInverterKVA: 3.5,
      recommendedBatteryKWH: 9.6,
      outcome,
      notes,
      photosCount: capturedPhotos.length,
      gpsTagged: !!gpsCoordinates,
      syncStatus: isOnline ? 'synced' : 'pending_sync',
      offlineCreatedAt: new Date().toISOString(),
      gpsCoordinates: gpsCoordinates || undefined,
      photos: capturedPhotos.map((p) => ({
        id: p.id,
        caption: p.caption,
        dataUrl: p.dataUrl,
        timestamp: new Date().toISOString()
      }))
    };

    // Save to IndexedDB
    await OfflineStorage.saveAssessment(offlineRecord);

    // If online, also trigger sync runner
    if (isOnline) {
      BackgroundSync.syncPendingData().catch(() => {});
    }

    onSaveAssessment(offlineRecord);
    setSubmissionFeedback(
      `Assessment recorded for ${selectedClient.fullName}. Status: ${outcome.toUpperCase()} (${isOnline ? 'Synced to Cloud' : 'Stored in IndexedDB'})`
    );

    // Clear feedback after 5 seconds
    setTimeout(() => setSubmissionFeedback(null), 5000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Offline Connectivity & Sync Bar */}
      <OfflineSyncStatus />

      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 font-serif">Site Inspector Hub & Offline Assessment Generator</h1>
          <p className="text-xs text-slate-500">
            Conduct structural roof evaluations, shading analysis, motor load audits, and GPS tagging (Offline IndexedDB Enabled).
          </p>
        </div>
      </div>

      {submissionFeedback && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-2xl p-4 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{submissionFeedback}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Assessment Checklist Form */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-slate-900 font-serif uppercase tracking-wider flex items-center gap-2">
            <ClipboardCheck className="w-4 h-4 text-[#1B4D3E]" />
            <span>Field Assessment Checklist</span>
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-700 font-bold mb-1">Target Client / Project</label>
              <select
                value={selectedClientId}
                onChange={(e) => setSelectedClientId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-medium text-slate-800"
              >
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.fullName} — {c.address} ({c.clientSegment.toUpperCase()})
                  </option>
                ))}
              </select>
            </div>

            {/* GPS Tagging Box */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-rose-500" />
                  GPS Tagging (Greater Banjul / CRR)
                </span>
                <button
                  type="button"
                  onClick={handleAcquireGPS}
                  disabled={isLocating}
                  className="inline-flex items-center gap-1 bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition"
                >
                  <Navigation className={`w-3 h-3 ${isLocating ? 'animate-spin' : ''}`} />
                  <span>{isLocating ? 'Acquiring...' : 'Capture GPS'}</span>
                </button>
              </div>

              {gpsCoordinates ? (
                <div className="text-[11px] text-emerald-800 font-mono bg-emerald-50 p-2 rounded border border-emerald-200">
                  Lat: {gpsCoordinates.latitude.toFixed(6)}, Long: {gpsCoordinates.longitude.toFixed(6)} (Tag Attached)
                </div>
              ) : (
                <div className="text-[11px] text-slate-500">
                  {gpsError ? <span className="text-rose-600">{gpsError}</span> : 'No GPS tag recorded yet.'}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Roof Type</label>
                <select
                  value={roofType}
                  onChange={(e) => setRoofType(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800"
                >
                  <option value="corrugated_iron">Corrugated Iron (Standard)</option>
                  <option value="concrete">Flat Concrete Slab</option>
                  <option value="tiled">Clay Tile Pitch</option>
                  <option value="flat">Flat Surface</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Roof Condition</label>
                <select
                  value={roofCondition}
                  onChange={(e) => setRoofCondition(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800"
                >
                  <option value="good">Good (Structurally Sound)</option>
                  <option value="fair">Fair (Minor Reinforcement Needed)</option>
                  <option value="poor">Poor (Requires Timber Replacement)</option>
                  <option value="needs_repair">Needs Urgent Structural Repair</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Peak Sun Exposure (Hours)</label>
                <input
                  type="number"
                  step="0.5"
                  value={sunExposureHours}
                  onChange={(e) => setSunExposureHours(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800"
                  min={1}
                  max={12}
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Shading Obstructions</label>
                <select
                  value={shadingLevel}
                  onChange={(e) => setShadingLevel(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800"
                >
                  <option value="none">None (Full Horizon Access)</option>
                  <option value="minimal">Minimal (&lt;10% in late afternoon)</option>
                  <option value="moderate">Moderate (Mango tree branches near eaves)</option>
                  <option value="heavy">Heavy (Tall adjacent multistory block)</option>
                </select>
              </div>
            </div>

            {/* Photo Capture Section */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
              <div className="font-bold text-slate-800 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Camera className="w-3.5 h-3.5 text-[#1B4D3E]" />
                  Field Photo Attachments ({capturedPhotos.length})
                </span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={photoCaption}
                  onChange={(e) => setPhotoCaption(e.target.value)}
                  placeholder="Photo label (e.g., Roof East Pitch)"
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs"
                />
                <label className="bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 font-bold px-3 py-2 rounded-lg text-xs cursor-pointer shrink-0 transition flex items-center gap-1">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Attach</span>
                  <input type="file" accept="image/*" capture="environment" onChange={handlePhotoUpload} className="hidden" />
                </label>
              </div>

              {capturedPhotos.length > 0 && (
                <div className="flex flex-wrap gap-2 pt-2">
                  {capturedPhotos.map((photo) => (
                    <div key={photo.id} className="relative w-16 h-16 rounded-lg overflow-hidden border border-slate-300">
                      <img src={photo.dataUrl} alt={photo.caption} className="w-full h-full object-cover" />
                      <span className="absolute bottom-0 inset-x-0 bg-black/60 text-white text-[8px] truncate px-1 text-center">
                        {photo.caption}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Inspector Notes & Structural Remarks</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Technical Assessment Outcome</label>
              <select
                value={outcome}
                onChange={(e) => setOutcome(e.target.value as any)}
                className={`w-full border rounded-xl p-2.5 text-xs font-bold ${
                  outcome === 'approved'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                    : outcome === 'approved_with_modifications'
                    ? 'bg-amber-50 border-amber-300 text-amber-800'
                    : 'bg-rose-50 border-rose-300 text-rose-800'
                }`}
              >
                <option value="approved">APPROVED — Site Ready for Solar Mounting</option>
                <option value="approved_with_modifications">APPROVED WITH MODIFICATIONS — Timber / Tree Trimming Needed</option>
                <option value="rejected">REJECTED — Structurally Unsafe Roof</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full bg-[#1B4D3E] hover:bg-[#246652] text-amber-300 font-bold py-3 rounded-xl shadow-lg transition cursor-pointer text-xs uppercase tracking-wider"
            >
              Submit & Cache Assessment Report
            </button>
          </form>
        </div>

        {/* Existing Assessment Records History */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-4">
            <h2 className="text-sm font-bold text-slate-900 font-serif uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#1B4D3E]" />
              <span>Assessment Dossiers & Audits ({assessments.length})</span>
            </h2>

            <div className="space-y-3">
              {assessments.map((a) => (
                <div key={a.id} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-sm">{a.clientName}</span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                        a.outcome === 'approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : a.outcome === 'approved_with_modifications'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {a.outcome.replace(/_/g, ' ')}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-slate-600 text-[11px]">
                    <div>Roof: <strong className="text-slate-800">{a.roofType} ({a.roofCondition})</strong></div>
                    <div>Sun: <strong className="text-slate-800">{a.sunExposureHours} hrs/day</strong></div>
                    <div>Shading: <strong className="text-slate-800">{a.shadingLevel}</strong></div>
                    <div>Inspector: <strong className="text-slate-800">{a.inspectorName}</strong></div>
                  </div>

                  <p className="text-slate-600 bg-white p-2 rounded border border-slate-100 text-[11px]">
                    {a.notes}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
