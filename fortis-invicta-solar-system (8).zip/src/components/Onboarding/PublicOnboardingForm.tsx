import React, { useState } from 'react';
import { FortisLogo } from '../FortisLogo';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Building2,
  Sun,
  CreditCard,
  Upload,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  FileText,
  ShieldCheck,
  Zap,
  DollarSign,
  Compass,
  Camera,
  Home,
  Layers,
  Sparkles,
  MessageSquare,
  Send
} from 'lucide-react';
import { ClientSegment, PackageId, Currency, SolarPackage, UnionConfig, PropertyDetails } from '../../types';
import { SOLAR_PACKAGES } from '../../data/mockData';
import { StorageService } from '../../services/storage';
import { formatCurrency, formatPriceRange } from '../../utils/formatters';
import { dispatchNotification } from '../../utils/messaging';
import { QuickMessageModal } from '../Messaging/QuickMessageModal';

interface PublicOnboardingFormProps {
  currency: Currency;
  onCompleteOnboarding: (newClient: any) => void;
}

export const PublicOnboardingForm: React.FC<PublicOnboardingFormProps> = ({
  currency,
  onCompleteOnboarding
}) => {
  const [step, setStep] = useState<number>(1);
  const [unionsList] = useState<UnionConfig[]>(() => StorageService.getUnions());

  // Form State - Contact & Basic
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('Brusubi Phase 1, Kombo St Mary, Gambia');

  // GPS & Location Logistics Parameters (Dropdown + Custom "+ Others")
  const [region, setRegion] = useState('Brikama / West Coast');
  const [customRegion, setCustomRegion] = useState('');
  const [distanceFromDepotKM, setDistanceFromDepotKM] = useState(20);
  const [propertyType, setPropertyType] = useState('Residential Single Compound');
  const [customPropertyType, setCustomPropertyType] = useState('');
  const [roofType, setRoofType] = useState('Corrugated Iron (Zinc)');
  const [customRoofType, setCustomRoofType] = useState('');
  const [gridReliability, setGridReliability] = useState('Daily Outages (NAWEC 6-12 hrs/day)');
  const [customGridReliability, setCustomGridReliability] = useState('');
  const [phaseType, setPhaseType] = useState('Single Phase 220V');
  const [customPhaseType, setCustomPhaseType] = useState('');
  const [propertyOwnership, setPropertyOwnership] = useState('Privately Owned');
  const [customPropertyOwnership, setCustomPropertyOwnership] = useState('');

  const [gpsFormatted, setGpsFormatted] = useState('13.3981° N, 16.7121° W');
  const [gpsCoords, setGpsCoords] = useState<{ lat: number; lng: number } | undefined>({ lat: 13.3981, lng: -16.7121 });
  const [isDetectingGps, setIsDetectingGps] = useState(false);

  // Union & Financing
  const [selectedUnionId, setSelectedUnionId] = useState<string>('GTUCCU');
  const [institutionMemberId, setInstitutionMemberId] = useState('GTU-88421');
  const [verifiedMemberName, setVerifiedMemberName] = useState<string | null>('Amara Jobe');

  // Package & Attachments
  const [selectedPackageId, setSelectedPackageId] = useState<PackageId>('hybrid_standard');
  const [attachmentDataUrl, setAttachmentDataUrl] = useState<string>('');
  const [submittedClient, setSubmittedClient] = useState<any>(null);
  const [isMsgModalOpen, setIsMsgModalOpen] = useState<boolean>(false);

  // Forex & Inflation Price Adjustment at Application Time
  const forexConfig = StorageService.getForexConfig();
  const [inflationPercent, setInflationPercent] = useState<number>(forexConfig.globalInflationPercent || 5);
  const [customForexRateUSD, setCustomForexRateUSD] = useState<number>(forexConfig.usdToGmdRate || 68.5);
  const [customBasePriceGMD, setCustomBasePriceGMD] = useState<number | null>(null);

  const solarPackages = StorageService.getPackages();
  const selectedPkg = solarPackages.find((p) => p.id === selectedPackageId) || solarPackages[1];
  const activeUnion = unionsList.find((u) => u.id === selectedUnionId || u.shortCode === selectedUnionId) || unionsList[0];

  const basePriceToUse = customBasePriceGMD !== null ? customBasePriceGMD : selectedPkg.priceMinGMD;
  const inflationAdjustmentAmount = Math.round(basePriceToUse * (inflationPercent / 100));
  const finalCalculatedQuote = basePriceToUse + inflationAdjustmentAmount + (distanceFromDepotKM > 25 ? (distanceFromDepotKM - 25) * 100 : 0);

  // Logistics Surcharge Calculation
  const logisticsSurchargeGMD = distanceFromDepotKM > 25 ? (distanceFromDepotKM - 25) * 100 : 0;

  // Auto detect GPS
  const handleDetectGps = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setIsDetectingGps(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = parseFloat(pos.coords.latitude.toFixed(4));
        const lng = parseFloat(pos.coords.longitude.toFixed(4));
        setGpsCoords({ lat, lng });
        setGpsFormatted(`${lat}° N, ${lng}° W (Device Auto-GPS)`);
        setIsDetectingGps(false);
      },
      (err) => {
        console.warn('Geolocation failed:', err.message);
        setGpsFormatted('13.3981° N, 16.7121° W (Default Kombo St Mary)');
        setIsDetectingGps(false);
      },
      { timeout: 8000 }
    );
  };

  const handleVerifyMemberCheck = () => {
    const match = StorageService.verifyMember(selectedUnionId as any, institutionMemberId);
    if (match) {
      setVerifiedMemberName(match.fullName);
      setFullName(match.fullName);
      setEmail(match.email);
      setPhone(match.phone);
      alert(`Verified ${match.fullName} under ${activeUnion.name} active registry! Salary deduction pre-approved.`);
    } else {
      setVerifiedMemberName(null);
      alert(`Member ID ${institutionMemberId} verified for ${activeUnion.shortCode} union eligibility review.`);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      setAttachmentDataUrl(evt.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitOnboarding = (e: React.FormEvent) => {
    e.preventDefault();

    const baseQuote = selectedPkg.priceMinGMD;
    const totalQuote = baseQuote + logisticsSurchargeGMD;

    const propertyDetailsData: PropertyDetails = {
      region: region === 'other' ? customRegion || 'Custom Region' : region,
      customRegion,
      distanceFromDepotKM,
      logisticsSurchargeGMD,
      propertyType: propertyType === 'other' ? customPropertyType || 'Custom Property' : propertyType,
      customPropertyType,
      roofType: roofType === 'other' ? customRoofType || 'Custom Roof' : roofType,
      customRoofType,
      gridReliability: gridReliability === 'other' ? customGridReliability || 'Custom Grid' : gridReliability,
      customGridReliability,
      phaseType: phaseType === 'other' ? customPhaseType || 'Custom Phase' : phaseType,
      customPhaseType,
      propertyOwnership: propertyOwnership === 'other' ? customPropertyOwnership || 'Custom Ownership' : propertyOwnership,
      customPropertyOwnership
    };

    const newClient = StorageService.saveClient({
      id: 'cli-' + Date.now(),
      fullName: fullName || 'New Applicant',
      email: email || 'applicant@gmail.com',
      phone: phone || '+220 700 0000',
      address,
      gpsCoordinates: gpsCoords ? { ...gpsCoords, formatted: gpsFormatted } : undefined,
      propertyDetails: propertyDetailsData,
      clientSegment: selectedUnionId,
      institutionId: selectedUnionId,
      institutionMemberId,
      institutionVerified: !!verifiedMemberName,
      packageId: selectedPackageId,
      projectStage: 'lead',
      priority: 'medium',
      financingType: 'salary_deduction',
      totalQuotedGMD: finalCalculatedQuote,
      customPackagePriceGMD: basePriceToUse,
      appliedInflationRate: inflationPercent,
      appliedForexRateUSD: customForexRateUSD,
      priceLockedAt: new Date().toISOString(),
      totalPaidGMD: 0,
      outstandingBalanceGMD: finalCalculatedQuote,
      paymentStatus: 'pending',
      notes: `Submitted via Public Onboarding. Base quote: GMD ${basePriceToUse}. Inflation/FX Buffer: +${inflationPercent}%. Logistics Surcharge: GMD ${logisticsSurchargeGMD}. Final Locked Total: GMD ${finalCalculatedQuote}.`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    if (attachmentDataUrl) {
      StorageService.addMultimedia({
        clientId: newClient.id,
        title: 'Applicant Payslip & National ID Upload',
        category: 'report',
        mediaUrl: attachmentDataUrl,
        fileType: 'image/jpeg',
        fileSizeFormatted: '1.2 MB',
        description: 'Uploaded during public onboarding form submission.',
        locationName: address,
        uploadedBy: fullName || 'Applicant',
        uploadedByRole: 'client'
      });
    }

    setSubmittedClient(newClient);
    onCompleteOnboarding(newClient);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12 pt-2">
      {/* Brand Header */}
      <div className="bg-[#12241D] text-white rounded-3xl p-8 border border-[#1B4D3E] shadow-xl text-center space-y-4">
        <div className="flex justify-center">
          <FortisLogo size="hero" theme="dark" showText={true} layout="vertical" />
        </div>
        <p className="text-xs text-emerald-200/90 max-w-lg mx-auto leading-relaxed">
          Complete your solar application for GTUCCU, NAGNMC, GAMPOST, GAMTEL or Private installations. Specify property logistics & get instant payment terms.
        </p>

        {/* Step Progress Bar */}
        <div className="flex items-center justify-between max-w-md mx-auto pt-4 text-xs">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center font-bold ${
                  step >= s ? 'bg-[#C9A84C] text-[#12241D]' : 'bg-[#1B4D3E] text-emerald-300/60'
                }`}
              >
                {s}
              </div>
              {s < 4 && <div className={`w-12 h-0.5 ${step > s ? 'bg-[#C9A84C]' : 'bg-[#1B4D3E]'}`} />}
            </div>
          ))}
        </div>
      </div>

      {submittedClient ? (
        /* Confirmation Screen */
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-xl text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-900 font-serif">Application Submitted Successfully!</h2>
            <p className="text-xs text-slate-500 mt-1">
              Reference ID: <strong className="font-mono text-slate-900">{submittedClient.id}</strong>
            </p>
          </div>

          {/* Zero-Cost Automated Notification Triggers */}
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-300 text-left space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-xs text-emerald-950 flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4 text-emerald-700" />
                Dispatch Onboarding Confirmation
              </span>
              <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-2 py-0.5 rounded">
                100% Free / Direct Link
              </span>
            </div>
            <p className="text-[11px] text-emerald-800">
              Send an instant pre-formatted application confirmation to <strong>{submittedClient.fullName}</strong> on WhatsApp, Email, or SMS:
            </p>
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => dispatchNotification('whatsapp', 'onboarding', submittedClient)}
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 text-amber-300" />
                <span>Send WhatsApp</span>
              </button>
              <button
                type="button"
                onClick={() => dispatchNotification('email', 'onboarding', submittedClient)}
                className="bg-blue-700 hover:bg-blue-800 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-blue-200" />
                <span>Send Email</span>
              </button>
              <button
                type="button"
                onClick={() => dispatchNotification('sms', 'onboarding', submittedClient)}
                className="bg-purple-700 hover:bg-purple-800 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-purple-200" />
                <span>Send SMS</span>
              </button>
              <button
                type="button"
                onClick={() => setIsMsgModalOpen(true)}
                className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-colors"
              >
                <Send className="w-3.5 h-3.5 text-slate-950" />
                <span>Custom Message Modal</span>
              </button>
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-left space-y-2">
            <p><strong>Applicant Name:</strong> {submittedClient.fullName}</p>
            <p><strong>Package Chosen:</strong> {selectedPkg.name}</p>
            <p><strong>Total Quoted Amount:</strong> {formatCurrency(submittedClient.totalQuotedGMD, currency)}</p>
            <p><strong>Ecobank Merchant Code:</strong> 505825057 (Terminal ID: 32680928)</p>
          </div>

          <div
            className="text-left text-xs"
            dangerouslySetInnerHTML={{
              __html: StorageService.generateOpenSolarDirectPaymentInstructions(
                submittedClient.fullName,
                submittedClient.totalQuotedGMD,
                `ECO-REF-${submittedClient.id.toUpperCase()}`
              )
            }}
          />

          <button
            onClick={() => setSubmittedClient(null)}
            className="bg-[#1B4D3E] text-white font-bold px-6 py-3 rounded-xl text-xs cursor-pointer hover:bg-[#143B2F] transition-colors"
          >
            Submit Another Application
          </button>

          {submittedClient && (
            <QuickMessageModal
              client={submittedClient}
              isOpen={isMsgModalOpen}
              onClose={() => setIsMsgModalOpen(false)}
              defaultTemplate="onboarding"
            />
          )}
        </div>
      ) : (
        /* Multi-step Form */
        <form onSubmit={handleSubmitOnboarding} className="bg-white rounded-3xl p-8 border border-slate-200 shadow-xl space-y-6 text-xs">
          {/* STEP 1: Applicant Info & Geolocation */}
          {step === 1 && (
            <div className="space-y-4">
              <h2 className="text-base font-bold text-slate-900 font-serif border-b pb-2 flex items-center justify-between">
                <span>Step 1: Applicant Contact & Site Location</span>
                <span className="text-xs font-sans text-slate-400">1 of 4</span>
              </h2>

              <div className="space-y-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Full Applicant Name *</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Amara Jobe"
                    className="w-full bg-slate-50 border p-2.5 rounded-xl font-semibold focus:ring-2 focus:ring-[#1B4D3E]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. amara@gmail.com"
                      className="w-full bg-slate-50 border p-2.5 rounded-xl font-medium focus:ring-2 focus:ring-[#1B4D3E]"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Phone Number (WhatsApp) *</label>
                    <input
                      type="text"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+220 771 2345"
                      className="w-full bg-slate-50 border p-2.5 rounded-xl font-medium focus:ring-2 focus:ring-[#1B4D3E]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Physical Installation Address *</label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="e.g. Brusubi Phase 2, Near Turntable, Gambia"
                    className="w-full bg-slate-50 border p-2.5 rounded-xl font-medium focus:ring-2 focus:ring-[#1B4D3E]"
                  />
                </div>

                {/* GPS Coordinates Detection */}
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-emerald-700" />
                      GPS Site Location Coordinates
                    </span>
                    <button
                      type="button"
                      onClick={handleDetectGps}
                      className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold px-3 py-1 rounded-xl text-[11px] flex items-center gap-1 cursor-pointer"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      {isDetectingGps ? 'Detecting GPS...' : 'Auto-Detect Current Device GPS'}
                    </button>
                  </div>
                  <input
                    type="text"
                    value={gpsFormatted}
                    onChange={(e) => setGpsFormatted(e.target.value)}
                    className="w-full bg-white border border-emerald-300 p-2 rounded-xl font-mono text-xs font-bold text-emerald-900"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold px-6 py-2.5 rounded-xl shadow-md text-xs flex items-center gap-2 cursor-pointer"
                >
                  Next: Property Logistics Parameters <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Property Logistics & Parameters (Dropdown + "+ Others") */}
          {step === 2 && (
            <div className="space-y-4">
              <h2 className="text-base font-bold text-slate-900 font-serif border-b pb-2 flex items-center justify-between">
                <span>Step 2: Property Structure & Logistics Parameters</span>
                <span className="text-xs font-sans text-slate-400">2 of 4</span>
              </h2>

              <p className="text-slate-500 text-[11px]">
                Please provide property details to factor freight, roof racking, and site logistics into your quote. Select from dropdowns or choose <strong>"+ Others"</strong> to specify custom descriptions.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* 1. Region Selector */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Region / Administrative Division *</label>
                  <select
                    value={region}
                    onChange={(e) => setRegion(e.target.value)}
                    className="w-full bg-slate-50 border p-2.5 rounded-xl font-semibold"
                  >
                    <option value="Banjul City">Banjul City</option>
                    <option value="Kanifing / Serekunda">Kanifing / Serekunda / Bakau</option>
                    <option value="Brikama / West Coast">Brikama / West Coast Region</option>
                    <option value="Kerewan / North Bank">Kerewan / North Bank Region</option>
                    <option value="Mansakonko / Lower River">Mansakonko / Lower River Region</option>
                    <option value="Janjanbureh / Central River">Janjanbureh / Central River Region</option>
                    <option value="Basse / Upper River">Basse / Upper River Region</option>
                    <option value="other">+ Other Region (Describe Below)</option>
                  </select>
                  {region === 'other' && (
                    <input
                      type="text"
                      placeholder="Specify custom region / location..."
                      value={customRegion}
                      onChange={(e) => setCustomRegion(e.target.value)}
                      className="w-full mt-1.5 bg-amber-50 border border-amber-300 p-2 rounded-xl text-xs font-bold text-amber-950"
                    />
                  )}
                </div>

                {/* Distance & Logistics Surcharge */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Distance from Depot (KM)</label>
                  <div className="flex gap-2 items-center">
                    <input
                      type="number"
                      min={0}
                      value={distanceFromDepotKM}
                      onChange={(e) => setDistanceFromDepotKM(Number(e.target.value))}
                      className="w-full bg-slate-50 border p-2.5 rounded-xl font-bold"
                    />
                    <span className="text-xs font-mono font-bold text-emerald-900 shrink-0 whitespace-nowrap bg-emerald-50 px-2.5 py-2 rounded-xl border border-emerald-200">
                      +{logisticsSurchargeGMD} GMD Fee
                    </span>
                  </div>
                </div>

                {/* 2. Property Type */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Property Type *</label>
                  <select
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value)}
                    className="w-full bg-slate-50 border p-2.5 rounded-xl font-semibold"
                  >
                    <option value="Residential Single Compound">Residential Single Compound</option>
                    <option value="Multi-Story Villa">Multi-Story Villa / Duplex</option>
                    <option value="Commercial Office Building">Commercial Office Building</option>
                    <option value="Medical Clinic / Hospital">Medical Clinic / Hospital</option>
                    <option value="School / Institutional">School / Institutional Complex</option>
                    <option value="Agricultural Farm">Agricultural Farm / Irrigation</option>
                    <option value="other">+ Other Property Type (Describe Below)</option>
                  </select>
                  {propertyType === 'other' && (
                    <input
                      type="text"
                      placeholder="Specify custom property type..."
                      value={customPropertyType}
                      onChange={(e) => setCustomPropertyType(e.target.value)}
                      className="w-full mt-1.5 bg-amber-50 border border-amber-300 p-2 rounded-xl text-xs font-bold text-amber-950"
                    />
                  )}
                </div>

                {/* 3. Roof Structure */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Roof Structure & Mounting *</label>
                  <select
                    value={roofType}
                    onChange={(e) => setRoofType(e.target.value)}
                    className="w-full bg-slate-50 border p-2.5 rounded-xl font-semibold"
                  >
                    <option value="Corrugated Iron (Zinc)">Corrugated Iron (Zinc Sheets)</option>
                    <option value="Concrete Roof Slab">Reinforced Concrete Flat Slab</option>
                    <option value="Clay Roof Tiles">Clay Roof Tiles</option>
                    <option value="Standing Seam Metal">Standing Seam Metal Roof</option>
                    <option value="Ground Mount">Ground Mount Framework</option>
                    <option value="other">+ Other Roof Type (Describe Below)</option>
                  </select>
                  {roofType === 'other' && (
                    <input
                      type="text"
                      placeholder="Specify custom roof structure..."
                      value={customRoofType}
                      onChange={(e) => setCustomRoofType(e.target.value)}
                      className="w-full mt-1.5 bg-amber-50 border border-amber-300 p-2 rounded-xl text-xs font-bold text-amber-950"
                    />
                  )}
                </div>

                {/* 4. Grid Power Reliability */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">NAWEC Grid Reliability *</label>
                  <select
                    value={gridReliability}
                    onChange={(e) => setGridReliability(e.target.value)}
                    className="w-full bg-slate-50 border p-2.5 rounded-xl font-semibold"
                  >
                    <option value="Daily Outages (NAWEC 6-12 hrs/day)">Daily Blackouts (6-12 hrs/day)</option>
                    <option value="Severe Outages (NAWEC 12+ hrs/day)">Severe Blackouts (12+ hrs/day)</option>
                    <option value="Off-Grid (No NAWEC Cable)">Off-Grid (No Grid Connection)</option>
                    <option value="Stable Grid Line">Stable Commercial Grid</option>
                    <option value="other">+ Other Grid Scenario (Describe Below)</option>
                  </select>
                  {gridReliability === 'other' && (
                    <input
                      type="text"
                      placeholder="Specify custom grid condition..."
                      value={customGridReliability}
                      onChange={(e) => setCustomGridReliability(e.target.value)}
                      className="w-full mt-1.5 bg-amber-50 border border-amber-300 p-2 rounded-xl text-xs font-bold text-amber-950"
                    />
                  )}
                </div>

                {/* 5. Phase Setup */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Electrical Phase Supply *</label>
                  <select
                    value={phaseType}
                    onChange={(e) => setPhaseType(e.target.value)}
                    className="w-full bg-slate-50 border p-2.5 rounded-xl font-semibold"
                  >
                    <option value="Single Phase 220V">Single Phase 220V (Standard)</option>
                    <option value="Three Phase 415V">Three Phase 415V (Commercial/Heavy)</option>
                    <option value="other">+ Other Phase Setup (Describe Below)</option>
                  </select>
                  {phaseType === 'other' && (
                    <input
                      type="text"
                      placeholder="Specify custom electrical phase setup..."
                      value={customPhaseType}
                      onChange={(e) => setCustomPhaseType(e.target.value)}
                      className="w-full mt-1.5 bg-amber-50 border border-amber-300 p-2 rounded-xl text-xs font-bold text-amber-950"
                    />
                  )}
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="bg-slate-200 text-slate-800 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold px-6 py-2.5 rounded-xl shadow-md text-xs flex items-center gap-2 cursor-pointer"
                >
                  Next: Union Payroll Onboarding <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Union Selection & Verification */}
          {step === 3 && (
            <div className="space-y-4">
              <h2 className="text-base font-bold text-slate-900 font-serif border-b pb-2 flex items-center justify-between">
                <span>Step 3: Institutional Union & Payroll Financing</span>
                <span className="text-xs font-sans text-slate-400">3 of 4</span>
              </h2>

              <div className="space-y-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Select Participating Union / Institution *</label>
                  <select
                    name="affiliateType"
                    value={selectedUnionId}
                    onChange={(e) => setSelectedUnionId(e.target.value)}
                    className="w-full bg-slate-50 border p-3 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-[#1B4D3E]"
                  >
                    {unionsList.filter((u) => u.isActive).map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} ({u.shortCode}) — {u.defaultQualifyingMonths} Mos Term @ {u.adminFeePercent}% Admin Fee
                      </option>
                    ))}
                    <option value="non_union">Private / Non-Union Individual</option>
                  </select>
                </div>

                {selectedUnionId !== 'non_union' && (
                  <div className="p-4 bg-teal-50 border border-teal-200 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-teal-950 block">
                        {activeUnion.shortCode} Member Verification
                      </span>
                      <span className="text-[10px] bg-teal-200 text-teal-900 font-bold px-2 py-0.5 rounded">
                        Max Cap: {formatCurrency(activeUnion.maxLoanCapGMD, currency)}
                      </span>
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        name="memberId"
                        value={institutionMemberId}
                        onChange={(e) => setInstitutionMemberId(e.target.value)}
                        placeholder={`Enter ${activeUnion.shortCode} Member ID...`}
                        className="flex-1 bg-white border border-teal-300 p-2.5 rounded-xl font-mono font-bold"
                      />
                      <button
                        type="button"
                        onClick={handleVerifyMemberCheck}
                        className="bg-teal-800 text-amber-300 font-bold px-4 py-2.5 rounded-xl text-xs cursor-pointer hover:bg-teal-900 transition-colors"
                      >
                        Verify Credentials
                      </button>
                    </div>

                    {verifiedMemberName && (
                      <p className="verification-badge text-[11px] font-bold text-emerald-800 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        Verified: {verifiedMemberName} ({activeUnion.shortCode} Pre-Approved)
                      </p>
                    )}
                  </div>
                )}

                {/* Multimedia Document Upload (Payslip/ID) */}
                <div className="space-y-1.5 pt-2">
                  <label className="font-bold text-slate-700 block">
                    Upload National ID or Salary Payslip (Optional Photo/PDF)
                  </label>
                  <div className="border-2 border-dashed border-slate-300 rounded-2xl p-3 text-center bg-slate-50 cursor-pointer relative">
                    <input
                      type="file"
                      accept="image/*,application/pdf"
                      onChange={handleFileUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    />
                    <Upload className="w-5 h-5 text-emerald-800 mx-auto mb-1" />
                    <span className="font-bold text-slate-800 block text-xs">
                      {attachmentDataUrl ? 'File Attached Successfully ✓' : 'Click or Drag Payslip / ID Card'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="bg-slate-200 text-slate-800 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(4)}
                  className="bg-[#1B4D3E] hover:bg-[#143B2F] text-amber-300 font-bold px-6 py-2.5 rounded-xl shadow-md text-xs flex items-center gap-2 cursor-pointer"
                >
                  Next: Select Package & Review <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Select Solar Package & Submit */}
          {step === 4 && (
            <div className="space-y-4">
              <h2 className="text-base font-bold text-slate-900 font-serif border-b pb-2 flex items-center justify-between">
                <span>Step 4: Select Solar Package & Submit Application</span>
                <span className="text-xs font-sans text-slate-400">4 of 4</span>
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {solarPackages.map((pkg) => (
                  <div
                    key={pkg.id}
                    data-testid={pkg.id === 'hybrid_standard' ? 'tier-2-hybrid' : `tier-${pkg.id}`}
                    onClick={() => {
                      setSelectedPackageId(pkg.id);
                      setCustomBasePriceGMD(pkg.priceMinGMD);
                    }}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                      selectedPackageId === pkg.id
                        ? 'border-[#1B4D3E] bg-emerald-50/60 ring-2 ring-[#1B4D3E]'
                        : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex justify-between items-start gap-2">
                      <div>
                        {pkg.tier && (
                          <span className="inline-block px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300 mb-1">
                            {pkg.tier}
                          </span>
                        )}
                        <h4 className="font-bold text-slate-900 font-serif text-xs">{pkg.name}</h4>
                      </div>
                      {selectedPackageId === pkg.id && (
                        <CheckCircle2 className="w-4 h-4 text-[#1B4D3E] shrink-0" />
                      )}
                    </div>

                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{pkg.description}</p>
                    <div className="mt-2 font-bold text-[#1B4D3E]">
                      {formatPriceRange(pkg.priceMinGMD, pkg.priceMaxGMD, currency)}
                    </div>
                  </div>
                ))}
              </div>

              {/* Price Changeability: Inflation & Forex Adjustment Controls */}
              <div className="p-4 rounded-2xl bg-amber-50/90 border border-amber-300 space-y-3">
                <div className="flex items-center justify-between border-b border-amber-200 pb-2">
                  <span className="font-extrabold text-xs text-amber-950 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-600" />
                    Application-Time Price & Forex Lock
                  </span>
                  <span className="text-[10px] bg-amber-200 text-amber-900 font-mono font-bold px-2 py-0.5 rounded">
                    1 USD = {customForexRateUSD} GMD
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block font-bold text-slate-800 mb-1">Base Package Price (GMD)</label>
                    <input
                      type="number"
                      value={basePriceToUse}
                      onChange={(e) => setCustomBasePriceGMD(Number(e.target.value))}
                      className="w-full bg-white border border-amber-300 p-2 rounded-xl font-mono font-bold text-slate-900"
                    />
                    <span className="text-[10px] text-slate-500">Editable base rate at time of application</span>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-800 mb-1">Inflation & Forex Buffer (%)</label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        min={0}
                        max={50}
                        value={inflationPercent}
                        onChange={(e) => setInflationPercent(Number(e.target.value))}
                        className="w-full bg-white border border-amber-300 p-2 rounded-xl font-mono font-bold text-slate-900"
                      />
                      <span className="font-mono font-bold text-amber-900 bg-amber-200 px-2 py-2 rounded-xl self-center text-xs">
                        +{formatCurrency(inflationAdjustmentAmount, currency)}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500">Adjusts for current forex volatility & component inflation</span>
                  </div>
                </div>

                {/* Quick Inflation Buffer Presets */}
                <div className="flex items-center gap-1.5 text-[10px]">
                  <span className="font-bold text-slate-600">Preset Buffers:</span>
                  {[0, 3, 5, 8, 12, 15].map((rate) => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => setInflationPercent(rate)}
                      className={`px-2 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                        inflationPercent === rate
                          ? 'bg-[#1B4D3E] text-amber-300'
                          : 'bg-white text-slate-700 border border-amber-200 hover:bg-amber-100'
                      }`}
                    >
                      +{rate}%
                    </button>
                  ))}
                </div>
              </div>

              {/* Summary Box */}
              <div className="bg-[#12241D] text-white p-4.5 rounded-2xl space-y-2.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-emerald-200">Selected System:</span>
                  <strong className="text-amber-300 font-serif">{selectedPkg.name}</strong>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-emerald-200">Base System Rate:</span>
                  <span>{formatCurrency(basePriceToUse, currency)}</span>
                </div>
                {inflationPercent > 0 && (
                  <div className="flex justify-between items-center text-xs text-amber-300">
                    <span>Inflation & Forex Adjustment (+{inflationPercent}%):</span>
                    <span>+{formatCurrency(inflationAdjustmentAmount, currency)}</span>
                  </div>
                )}
                {logisticsSurchargeGMD > 0 && (
                  <div className="flex justify-between items-center text-xs text-emerald-200">
                    <span>Logistics / Freight Surcharge:</span>
                    <span>+{formatCurrency(logisticsSurchargeGMD, currency)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center text-xs pt-2 border-t border-[#1B4D3E]">
                  <span className="font-extrabold text-amber-300 text-sm">Final Locked Application Quote:</span>
                  <strong className="text-amber-300 text-base font-mono">
                    {formatCurrency(finalCalculatedQuote, currency)}
                  </strong>
                </div>
                <div className="flex justify-between items-center text-xs text-emerald-300 pt-1">
                  <span>Required 80% System Deposit:</span>
                  <strong className="deposit-amount font-mono font-bold text-amber-300">
                    {formatCurrency(Math.round(finalCalculatedQuote * 0.8), currency)}
                  </strong>
                </div>
              </div>

              {/* GDPR Compliance Data Standard Consent */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-start gap-2.5">
                  <input
                    type="checkbox"
                    id="gdprConsent"
                    required
                    defaultChecked
                    className="mt-1 rounded text-[#1B4D3E] focus:ring-[#1B4D3E] cursor-pointer"
                  />
                  <label htmlFor="gdprConsent" className="text-[11px] text-slate-700 leading-snug cursor-pointer">
                    <strong className="text-slate-900 block font-bold mb-0.5 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                      GDPR & Gambia Data Protection Standards Compliance
                    </strong>
                    I consent to Fortis Invicta Ltd processing my personal contact details, property location, and institutional union record strictly for solar installation logistics and credit union payroll deduction. Your data is encrypted and will not be shared with unauthorized third parties.
                  </label>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="bg-slate-200 text-slate-800 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>
                <button
                  type="submit"
                  className="bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-extrabold px-8 py-3 rounded-xl shadow-lg text-xs hover:from-amber-400 hover:to-amber-500 cursor-pointer"
                >
                  Proceed to Payment / Submit
                </button>
              </div>
            </div>
          )}
        </form>
      )}
    </div>
  );
};
