/**
 * Official Company Information & Contact Specifications
 * Fortis Invicta Ltd - The Command HQ
 */
export const FORTIS_COMPANY_INFO = {
  companyName: 'FORTIS INVICTA LTD',
  tagline: 'Transforming Energy | Empowering Communities',
  headquarters: 'THE COMMAND HQ',
  fullTitle: 'FORTIS INVICTA LTD, THE COMMAND HQ',
  address: 'Tranquil Behind AGIB Bank, The Gambia',
  phone: '+220 257 2911',
  phoneFormatted: '+220 257 2911',
  phoneWhatsApp: '+220 257 2911',
  whatsAppClean: '2202572911',
  email: 'info@fortisinvicta.com',
  secondaryEmail: 'fortisinvictaltd@gmail.com',
  website: 'https://fortisinvicta.com',
  merchantCode: '505825057',
  terminalId: '32680928',
  accountNumber: '6254514448',
  accountNumberGMD: '6254514448',
  accountTypeGMD: 'Current Account Corporate LFCY',
  accountNumberEUR: '6254514972',
  accountTypeEUR: 'Current Account Corporate FCY',
  accountNumberUSD: '6254515293',
  accountTypeUSD: 'Current Account Embassies FCY',
  accountName: 'FORTIS INVICTA LTD',
  bankName: 'Ecobank Gambia',
  branch: 'EGM Ecobank Gambia Banjul Branch, Nelson Mandela Avenue, Banjul, The Gambia',
  swift: 'ECOCGMGM',
  intermediaryBankName: 'ECOBANK FRANCE (EBISA)',
  intermediaryBankAddress: "Bât F Les Collines de l'Arche, 76 Rte de la Demi-Lune, 92800 Puteaux",
  intermediarySwift: 'ECOCFRPP',
  registrationNumber: 'GMB-2025-FI9982',
  country: 'The Gambia',
  currency: 'GMD'
} as const;

export default FORTIS_COMPANY_INFO;
