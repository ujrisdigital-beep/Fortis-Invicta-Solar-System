import * as Sentry from '@sentry/node';
import { Express, Request, Response, NextFunction } from 'express';

export function initSentry(app?: Express) {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) {
    console.info('[Sentry Monitoring] SENTRY_DSN not set. Running in local monitoring fallback mode.');
    return;
  }

  Sentry.init({
    dsn,
    tracesSampleRate: 0.2,
    environment: process.env.NODE_ENV || 'development'
  });

  if (app && (Sentry as any).Handlers) {
    app.use((Sentry as any).Handlers.requestHandler());
    app.use((Sentry as any).Handlers.tracingHandler());
  }
}

export function sentryTracingMiddleware(req: Request, res: Response, next: NextFunction) {
  next();
}

export function captureException(error: any) {
  if (process.env.SENTRY_DSN) {
    Sentry.captureException(error);
  } else {
    console.error('[Telemetry Exception Capture]:', error);
  }
}
