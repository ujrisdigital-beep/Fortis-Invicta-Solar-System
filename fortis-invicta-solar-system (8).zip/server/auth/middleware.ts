import { Request, Response, NextFunction } from 'express';
import { verifyToken } from './jwt.js';
import { UserRole, AuthUser } from './types.js';

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const cookieToken = (req as any).cookies?.fortis_access_token;
  const token = header?.startsWith('Bearer ') ? header.split(' ')[1] : cookieToken;

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized: Authentication token is missing' });
  }

  try {
    const user = verifyToken(token);
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: 'Unauthorized: Invalid or expired token' });
  }
}

export function requireRole(...roles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const user = req.user;
    if (!user || !roles.includes(user.role)) {
      return res.status(403).json({ error: 'Forbidden: Insufficient privileges for this resource' });
    }
    next();
  };
}
