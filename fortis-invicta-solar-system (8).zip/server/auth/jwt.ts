import jwt from 'jsonwebtoken';
import { AuthUser } from './types.js';

const JWT_SECRET = process.env.JWT_SECRET || 'fortis-invicta-secure-jwt-secret-production-2026';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'fortis-invicta-refresh-secret-production-2026';

export function signAccessToken(user: AuthUser): string {
  return jwt.sign(user, JWT_SECRET, { expiresIn: '15m' });
}

export function signRefreshToken(user: AuthUser): string {
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_REFRESH_SECRET, { expiresIn: '7d' });
}

export function verifyToken(token: string): AuthUser {
  return jwt.verify(token, JWT_SECRET) as AuthUser;
}

export function verifyRefreshToken(token: string): AuthUser {
  return jwt.verify(token, JWT_REFRESH_SECRET) as AuthUser;
}
