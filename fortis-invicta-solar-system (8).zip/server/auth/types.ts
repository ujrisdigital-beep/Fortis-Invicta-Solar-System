export type UserRole = 'client' | 'engineer' | 'admin' | 'finance_officer' | 'project_manager' | 'institutional_admin';

export interface AuthUser {
  id: string;
  email: string;
  role: UserRole;
  fullName?: string;
  institutionId?: string;
}
