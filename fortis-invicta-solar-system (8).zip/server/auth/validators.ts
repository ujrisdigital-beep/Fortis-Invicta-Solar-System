import { z } from 'zod';

export const signupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  role: z.enum(['client', 'engineer', 'admin', 'finance_officer', 'project_manager', 'institutional_admin']).default('client'),
  fullName: z.string().min(2).optional(),
  phone: z.string().optional(),
  institutionId: z.string().optional()
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

export const refreshTokenSchema = z.object({
  refreshToken: z.string().min(10)
});
