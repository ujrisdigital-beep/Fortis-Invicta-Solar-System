/**
 * FORTIS INVICTA SOLAR SYSTEM - PRODUCTION READINESS CHECK GATE
 * Validates Environment, Security, Database Schema, Financial Integrity, and Solar Engineering
 */
import fs from 'fs';
import path from 'path';
import { calculateSolarRequirements, CALCULATION_ENGINE_VERSION } from '../src/utils/solarCalculations';
import { FORTIS_COMPANY_INFO } from '../src/data/companyConfig';

async function runProductionReadinessCheck() {
  console.log('\n=============================================================');
  console.log('  FORTIS INVICTA SOLAR PLATFORM - PRODUCTION READINESS AUDIT ');
  console.log('=============================================================\n');

  let checksPassed = 0;
  let checksFailed = 0;
  const issues: string[] = [];

  function recordCheck(name: string, success: boolean, details?: string) {
    if (success) {
      console.log(`[PASS] ✅ ${name}`);
      checksPassed++;
    } else {
      console.error(`[FAIL] ❌ ${name}: ${details || 'Validation error'}`);
      checksFailed++;
      if (details) issues.push(details);
    }
  }

  // 1. Company Profile & Command HQ Information Check
  const hasHQAddress = FORTIS_COMPANY_INFO.address.includes('Tranquil Behind AGIB Bank');
  const hasHQPhone = FORTIS_COMPANY_INFO.phoneWhatsApp === '+220 257 2911';
  const hasHQEmail = FORTIS_COMPANY_INFO.email === 'info@fortisinvicta.com';
  recordCheck(
    'Company Command HQ Specifications',
    hasHQAddress && hasHQPhone && hasHQEmail,
    'Company profile does not match required Command HQ address or contact info'
  );

  // 2. Database Schema Check
  const schemaPath = path.join(process.cwd(), 'src', 'db', 'schema.sql');
  const schemaExists = fs.existsSync(schemaPath);
  let schemaContent = '';
  if (schemaExists) {
    schemaContent = fs.readFileSync(schemaPath, 'utf-8');
  }

  recordCheck('PostgreSQL / Supabase Schema File Exists', schemaExists, 'src/db/schema.sql missing');
  recordCheck(
    'Row-Level Security (RLS) Policies Defined',
    schemaContent.includes('ENABLE ROW LEVEL SECURITY') && schemaContent.includes('CREATE POLICY'),
    'RLS policies missing from schema.sql'
  );
  recordCheck(
    'Immutable Audit Logs Table Defined',
    schemaContent.includes('CREATE TABLE IF NOT EXISTS audit_logs'),
    'audit_logs table missing from schema'
  );

  // 3. Solar Engineering Calculation Engine Check
  const testLoads = [
    {
      id: 'l1',
      name: 'Deep Freezer',
      category: 'refrigeration' as const,
      nominalWatts: 250,
      quantity: 1,
      surgeMultiplier: 3.2,
      operatingHoursPerDay: 24,
      daytimeUsagePercent: 50
    }
  ];
  const sizingRes = calculateSolarRequirements(testLoads);
  recordCheck(
    `Solar Sizing Engine Execution (${CALCULATION_ENGINE_VERSION})`,
    sizingRes.engineVersion === 'v1.0.0' && sizingRes.continuousPowerKW > 0 && sizingRes.recommendedPanels550W >= 2,
    'Solar sizing calculation output mismatch'
  );

  // 4. Security Configuration Check
  const securityPath = path.join(process.cwd(), 'server', 'security.ts');
  const securityExists = fs.existsSync(securityPath);
  recordCheck('Server Security Middleware Defined', securityExists, 'server/security.ts not found');

  // 5. Multi-Stage Dockerfile & Container Readiness
  const dockerfilePath = path.join(process.cwd(), 'Dockerfile');
  const dockerExists = fs.existsSync(dockerfilePath);
  let dockerContent = '';
  if (dockerExists) {
    dockerContent = fs.readFileSync(dockerfilePath, 'utf-8');
  }
  recordCheck(
    'Multi-Stage Non-Root Dockerfile Verified',
    dockerExists && dockerContent.includes('USER nodejs') && dockerContent.includes('HEALTHCHECK'),
    'Dockerfile missing non-root user or healthcheck'
  );

  // 6. CI/CD GitHub Actions Workflow
  const ciPath = path.join(process.cwd(), '.github', 'workflows', 'production-pipeline.yml');
  const ciExists = fs.existsSync(ciPath);
  recordCheck('GitHub Actions Production CI/CD Pipeline', ciExists, 'production-pipeline.yml workflow missing');

  console.log('\n-------------------------------------------------------------');
  console.log(`TOTAL CHECKS: ${checksPassed + checksFailed} | PASSED: ${checksPassed} | FAILED: ${checksFailed}`);
  console.log('-------------------------------------------------------------\n');

  if (checksFailed === 0) {
    console.log('=============================================================');
    console.log('  FORTIS INVICTA SOLAR SYSTEM: PRODUCTION READY (GO)         ');
    console.log('  VERSION: 1.0.0 (Enterprise Commercial Release)              ');
    console.log('=============================================================\n');
    process.exit(0);
  } else {
    console.error('=============================================================');
    console.error('  FORTIS INVICTA SOLAR SYSTEM: NOT PRODUCTION READY (NO-GO)  ');
    console.error('  Actionable Failures:');
    issues.forEach((i) => console.error(`   - ${i}`));
    console.error('=============================================================\n');
    process.exit(1);
  }
}

runProductionReadinessCheck();
