#!/usr/bin/env bash
# ==============================================================================
# Fortis Invicta Solar - Cloud Run Automated Deployment Script
# ==============================================================================
set -euo pipefail

# Configuration Defaults
GCP_PROJECT_ID="${GCP_PROJECT_ID:-fortis-invicta-production}"
GCP_REGION="${GCP_REGION:-europe-west2}"
SERVICE_NAME="${SERVICE_NAME:-fortis-invicta-solar}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
IMAGE_URI="gcr.io/${GCP_PROJECT_ID}/${SERVICE_NAME}:${IMAGE_TAG}"

echo "==================================================================="
echo "🚀 Deploying Fortis Invicta Enterprise Solar to Google Cloud Run"
echo "Project:  ${GCP_PROJECT_ID}"
echo "Region:   ${GCP_REGION}"
echo "Service:  ${SERVICE_NAME}"
echo "Image:    ${IMAGE_URI}"
echo "==================================================================="

# 1. Authenticate & Set Active Project
echo "Step 1: Setting GCP Project..."
gcloud config set project "${GCP_PROJECT_ID}"

# 2. Build Container Image using Google Cloud Build
echo "Step 2: Submitting Container Build to Cloud Build..."
gcloud builds submit --tag "${IMAGE_URI}" .

# 3. Deploy to Cloud Run with Production Resource Allocation & Secrets
echo "Step 3: Deploying container to Cloud Run..."
gcloud run deploy "${SERVICE_NAME}" \
  --image "${IMAGE_URI}" \
  --platform managed \
  --region "${GCP_REGION}" \
  --allow-unauthenticated \
  --port 3000 \
  --memory 1Gi \
  --cpu 1 \
  --min-instances 1 \
  --max-instances 10 \
  --timeout 300 \
  --set-env-vars "NODE_ENV=production,PORT=3000" \
  --set-secrets "\
JWT_SECRET=fortis-jwt-secret:latest,\
APP_SECRET=fortis-app-secret:latest,\
DATABASE_URL=fortis-database-url:latest,\
GEMINI_API_KEY=gemini-api-key:latest"

echo "==================================================================="
echo "✅ Deployment Successful!"
echo "Service URL: $(gcloud run services describe ${SERVICE_NAME} --platform managed --region ${GCP_REGION} --format 'value(status.url)')"
echo "==================================================================="
