/**
 * Payment State Machine & Financial Ledger Integrity Tests
 */
import { PaymentRecord, PaymentStatus } from '../src/types';

interface LedgerEntry {
  transactionId: string;
  clientId: string;
  amountGMD: number;
  type: 'DEBIT' | 'CREDIT';
  status: PaymentStatus;
  idempotencyKey: string;
  timestamp: string;
}

class TestPaymentLedger {
  private ledger: LedgerEntry[] = [];
  private processedKeys = new Set<string>();

  public processPayment(
    payment: Omit<PaymentRecord, 'id' | 'timestamp'>,
    idempotencyKey: string
  ): { success: boolean; error?: string; record?: PaymentRecord } {
    // 1. Idempotency Check
    if (this.processedKeys.has(idempotencyKey)) {
      return { success: false, error: 'DUPLICATE_TRANSACTION_KEY' };
    }

    if (payment.amountGMD <= 0) {
      return { success: false, error: 'INVALID_AMOUNT' };
    }

    const id = `PAY-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
    const timestamp = new Date().toISOString();

    const record: PaymentRecord = {
      ...payment,
      id,
      timestamp,
      status: payment.status || 'pending_verification'
    };

    this.processedKeys.add(idempotencyKey);
    this.ledger.push({
      transactionId: id,
      clientId: payment.clientId,
      amountGMD: payment.amountGMD,
      type: 'CREDIT',
      status: record.status,
      idempotencyKey,
      timestamp
    });

    return { success: true, record };
  }

  public transitionStatus(
    transactionId: string,
    targetStatus: PaymentStatus,
    authorizedRole: string
  ): { success: boolean; error?: string } {
    // RBAC check: only finance_officer or admin/super_admin can approve or reject
    const allowedRoles = ['finance_officer', 'super_admin', 'admin', 'project_manager'];
    if (!allowedRoles.includes(authorizedRole)) {
      return { success: false, error: 'UNAUTHORIZED_ROLE' };
    }

    const entry = this.ledger.find((l) => l.transactionId === transactionId);
    if (!entry) {
      return { success: false, error: 'TRANSACTION_NOT_FOUND' };
    }

    // State machine transitions: PENDING_VERIFICATION -> APPROVED/REJECTED -> SETTLED
    if (entry.status === 'approved' && targetStatus === 'pending_verification') {
      return { success: false, error: 'INVALID_STATE_TRANSITION' };
    }

    entry.status = targetStatus;
    return { success: true };
  }

  public getBalanceForClient(clientId: string): number {
    return this.ledger
      .filter((l) => l.clientId === clientId && (l.status === 'approved' || l.status === 'confirmed'))
      .reduce((sum, l) => sum + l.amountGMD, 0);
  }
}

function runPaymentTests() {
  console.log('--- RUNNING PAYMENT LEDGER & IDEMPOTENCY TESTS ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName}`);
      failed++;
    }
  }

  const ledger = new TestPaymentLedger();

  // Test 1: Record initial bank teller payment
  const p1 = ledger.processPayment(
    {
      clientId: 'cli-001',
      clientName: 'Amara Jobe',
      amountGMD: 50000,
      currency: 'GMD',
      paymentDate: '2026-08-19',
      paymentMethod: 'bank_transfer',
      referenceNumber: 'ECO-TLR-99881',
      status: 'pending_verification',
      notes: 'Direct transfer via Ecobank'
    },
    'idemp-key-001'
  );

  assert(p1.success === true, 'Payment recorded with status pending_verification');
  assert(ledger.getBalanceForClient('cli-001') === 0, 'Unapproved payment does not credit client balance prematurely');

  // Test 2: Idempotency protection prevents duplicate submissions
  const p1Duplicate = ledger.processPayment(
    {
      clientId: 'cli-001',
      clientName: 'Amara Jobe',
      amountGMD: 50000,
      currency: 'GMD',
      paymentDate: '2026-08-19',
      paymentMethod: 'bank_transfer',
      referenceNumber: 'ECO-TLR-99881',
      status: 'pending_verification'
    },
    'idemp-key-001'
  );
  assert(p1Duplicate.success === false && p1Duplicate.error === 'DUPLICATE_TRANSACTION_KEY', 'Duplicate idempotency key rejected');

  // Test 3: Unauthorized role cannot approve payment
  const unauthorizedApproval = ledger.transitionStatus(p1.record!.id, 'approved', 'site_inspector');
  assert(unauthorizedApproval.success === false && unauthorizedApproval.error === 'UNAUTHORIZED_ROLE', 'Site inspector cannot approve payment');

  // Test 4: Finance officer approves payment
  const authorizedApproval = ledger.transitionStatus(p1.record!.id, 'approved', 'finance_officer');
  assert(authorizedApproval.success === true, 'Finance officer successfully approves payment');
  assert(ledger.getBalanceForClient('cli-001') === 50000, 'Approved payment updates verified client credit ledger');

  console.log(`\nPayment Tests Summary: ${passed} passed, ${failed} failed.\n`);
  if (failed > 0) process.exit(1);
}

runPaymentTests();
