/**
 * Authentication & RBAC Unit Tests
 */
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { isDisposableEmail } from '../src/server/tempMailValidator.js';

const TEST_JWT_SECRET = 'fortis-test-jwt-secret-key-32-chars-long-min!';

interface UserPayload {
  id: string;
  email: string;
  role: string;
  fullName: string;
}

function runAuthTests() {
  console.log('--- RUNNING AUTHENTICATION, RBAC & TEMP-MAIL TESTS ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName}`);
      failed++;
    }
  }

  // Test 1: Bcrypt Password Hashing
  const rawPassword = 'FortisSolarPassword2026!';
  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(rawPassword, salt);

  assert(bcrypt.compareSync(rawPassword, hash), 'Bcrypt correctly verifies valid password');
  assert(!bcrypt.compareSync('WrongPassword', hash), 'Bcrypt rejects incorrect password');

  // Test 2: JWT Access Token Generation and Verification
  const user: UserPayload = {
    id: 'usr-fin-001',
    email: 'finance@fortisinvicta.com',
    role: 'finance_officer',
    fullName: 'Fatoumatta Ceesay'
  };

  const token = jwt.sign(user, TEST_JWT_SECRET, { expiresIn: '15m' });
  const decoded = jwt.verify(token, TEST_JWT_SECRET) as UserPayload;

  assert(decoded.id === user.id, 'Decoded token ID matches payload');
  assert(decoded.role === 'finance_officer', 'Decoded token role matches payload');

  // Test 3: Rejection of Tampered Token
  let tamperedRejected = false;
  try {
    jwt.verify(token, 'wrong-secret-key');
  } catch {
    tamperedRejected = true;
  }
  assert(tamperedRejected, 'Tampered token signature is safely rejected');

  // Test 4: Role-Based Authorization Policy Matrix
  const rolePermissions: Record<string, string[]> = {
    super_admin: ['view_dashboard', 'manage_users', 'approve_payments', 'conduct_assessments', 'manage_projects'],
    finance_officer: ['view_dashboard', 'approve_payments', 'view_reports', 'reconcile_bank'],
    site_inspector: ['view_dashboard', 'conduct_assessments', 'upload_photos'],
    client: ['view_portal', 'upload_teller_slip', 'view_quotes']
  };

  function hasPermission(role: string, permission: string): boolean {
    return rolePermissions[role]?.includes(permission) || false;
  }

  assert(hasPermission('finance_officer', 'approve_payments'), 'Finance officer has permission to approve payments');
  assert(!hasPermission('client', 'approve_payments'), 'Client does NOT have permission to approve payments');
  assert(!hasPermission('site_inspector', 'approve_payments'), 'Site inspector cannot approve payments');
  assert(hasPermission('site_inspector', 'conduct_assessments'), 'Site inspector can conduct assessments');

  // Test 5: Disposable / Temp Mail Detection & Blocking
  const blockedEmails = [
    'user@mailinator.com',
    'test@tempmail.com',
    'bot@guerrillamail.com',
    'fake@10minutemail.com',
    'trash@yopmail.com',
    'spam@sharklasers.com',
    'scam@dispostable.com',
    'hacker@temp-mail.org'
  ];

  blockedEmails.forEach((email) => {
    const check = isDisposableEmail(email);
    assert(check.isDisposable, `Temp mail domain correctly blocked: ${email}`);
  });

  // Test 6: Valid Email Acceptance
  const validEmails = [
    'amadou.jallow@fortisinvicta.gm',
    'teacher.fatou@gtu.gm',
    'client.jobe@gmail.com',
    'accountant@ecobank.com',
    'solar.survey@yahoo.co.uk'
  ];

  validEmails.forEach((email) => {
    const check = isDisposableEmail(email);
    assert(!check.isDisposable, `Legitimate email accepted: ${email}`);
  });

  console.log(`\nAuth, RBAC & Temp-Mail Tests Summary: ${passed} passed, ${failed} failed.\n`);
  if (failed > 0) process.exit(1);
}

runAuthTests();
