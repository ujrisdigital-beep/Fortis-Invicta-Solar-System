import { ApiOrchestrator, ORCHESTRATOR_ENV } from '../src/services/api/orchestrator';

async function runOrchestratorTests() {
  console.log('\n--- Running API Orchestrator & Error Handling Unit Tests ---');
  let passed = 0;
  let failed = 0;

  function assert(name: string, condition: boolean, details?: string) {
    if (condition) {
      console.log(`[PASS] ${name}`);
      passed++;
    } else {
      console.error(`[FAIL] ${name}: ${details || ''}`);
      failed++;
    }
  }

  // 1. Check environment variables
  assert(
    'Orchestrator environment contains Docker host configs',
    ORCHESTRATOR_ENV.DIRECTUS_URL.includes('8055') &&
    ORCHESTRATOR_ENV.ERPNEXT_URL.includes('8000') &&
    ORCHESTRATOR_ENV.MOODLE_URL.includes('8080') &&
    ORCHESTRATOR_ENV.THINGSBOARD_URL.includes('9090') &&
    ORCHESTRATOR_ENV.POSTAL_API_URL.includes('5000') &&
    ORCHESTRATOR_ENV.OPENSEARCH_URL.includes('9200')
  );

  // 2. Fetch staff roster returns typed structure or explicit offline message
  const staffRes = await ApiOrchestrator.fetchStaffRoster();
  assert(
    'Staff roster call produces a typed ApiResponse',
    typeof staffRes === 'object' && ('success' in staffRes)
  );

  // 3. Directus Content fetch
  const directusRes = await ApiOrchestrator.fetchDirectusContent('solar_packages');
  assert(
    'Directus content query produces a valid response object',
    typeof directusRes === 'object' && ('success' in directusRes)
  );

  // 4. ThingsBoard Telemetry fetch
  const telemetryRes = await ApiOrchestrator.fetchTelemetry('a1b2c3d4-e5f6-7890-abcd-ef1234567890');
  assert(
    'ThingsBoard telemetry produces typed telemetry or explicit service error',
    typeof telemetryRes === 'object' && ('success' in telemetryRes)
  );

  // 5. Moodle Certifications
  const moodleRes = await ApiOrchestrator.fetchCertifications();
  assert(
    'Moodle certification query produces typed certification list',
    typeof moodleRes === 'object' && ('success' in moodleRes)
  );

  // 6. OpenSearch Audit Logging
  const auditRes = await ApiOrchestrator.logAuditEvent({
    action: 'UNIT_TEST_VERIFY',
    category: 'AUDIT',
    severity: 'INFO',
    details: 'Testing Orchestrator OpenSearch connectivity'
  });
  assert(
    'OpenSearch audit logger returns typed ApiResponse',
    typeof auditRes === 'object' && ('success' in auditRes)
  );

  console.log(`\nAPI Orchestrator Tests Finished: ${passed} Passed, ${failed} Failed\n`);
  if (failed > 0) process.exit(1);
}

runOrchestratorTests().catch((err) => {
  console.error('Unhandled error in orchestrator tests:', err);
  process.exit(1);
});
