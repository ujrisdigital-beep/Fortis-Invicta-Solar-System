import { calculateSolarRequirements, CALCULATION_ENGINE_VERSION, PRESET_APPLIANCES, LoadItem } from '../src/utils/solarCalculations';

function runTests() {
  console.log('--- RUNNING SOLAR ENGINEERING ENGINE TESTS ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName}`);
      failed++;
    }
  }

  // Test 1: Calculation Engine Version is stamped
  const emptyRes = calculateSolarRequirements([]);
  assert(emptyRes.engineVersion === CALCULATION_ENGINE_VERSION, 'Engine version is accurately stamped (v1.0.0)');
  assert(emptyRes.totalConnectedWatts === 0, 'Zero loads produce zero power');

  // Test 2: Standard Residential Appliances
  const sampleLoads: LoadItem[] = [
    {
      id: 'l1',
      name: 'LED Lighting',
      category: 'lighting_electronic',
      nominalWatts: 10,
      quantity: 10,
      surgeMultiplier: 1.0,
      operatingHoursPerDay: 6,
      daytimeUsagePercent: 0
    },
    {
      id: 'l2',
      name: 'Refrigerator',
      category: 'refrigeration',
      nominalWatts: 200,
      quantity: 1,
      surgeMultiplier: 3.5,
      operatingHoursPerDay: 24,
      daytimeUsagePercent: 50
    }
  ];

  const res = calculateSolarRequirements(sampleLoads);
  assert(res.totalConnectedWatts === 300, 'Total connected watts calculated accurately (300W)');
  assert(res.continuousPowerKW > 0, 'Continuous power calculated with diversity factor');
  assert(res.maxIndividualSurgeWatts === 700, 'Max individual surge identified (700W for fridge)');
  assert(res.recommendedPanels550W >= 2, 'Recommended solar PV array requires at least 2 Tier-1 panels');
  assert(res.recommendedBatteryKWh > 0, 'Recommended battery storage calculated with DoD derating');

  // Test 3: Inductive Motor Surge Detection
  const motorLoad: LoadItem[] = [
    {
      id: 'm1',
      name: 'Submersible Agricultural Borehole Pump (1.5HP)',
      category: 'agricultural_pump',
      nominalWatts: 1100,
      quantity: 1,
      surgeMultiplier: 6.0,
      operatingHoursPerDay: 4,
      daytimeUsagePercent: 90
    }
  ];

  const motorRes = calculateSolarRequirements(motorLoad);
  assert(motorRes.motorSurgeWarning !== undefined, 'Heavy inductive motor triggers mandatory surge warning');
  assert(motorRes.maxIndividualSurgeWatts === 6600, 'Motor surge reaches 6.6kW peak starting surge');

  console.log(`\nSolar Engine Tests Summary: ${passed} passed, ${failed} failed.\n`);
  if (failed > 0) process.exit(1);
}

runTests();
