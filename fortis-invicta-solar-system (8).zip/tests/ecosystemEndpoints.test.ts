/**
 * Corporate Ecosystem Endpoints Integration Unit Test
 */
import { DirectusService } from '../src/server/integrations/directusService.js';
import { ERPNextService } from '../src/server/integrations/erpnextService.js';
import { MoodleService } from '../src/server/integrations/moodleService.js';
import { ThingsBoardService } from '../src/server/integrations/thingsboardService.js';
import { PostalService } from '../src/server/integrations/postalService.js';
import { OpenSearchService } from '../src/server/integrations/opensearchService.js';

async function runEcosystemTests() {
  console.log('--- RUNNING CORPORATE ECOSYSTEM 6-ENDPOINT TESTS ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName}`);
      failed++;
    }
  }

  // 1. Directus CMS Service Test
  try {
    const packages = await DirectusService.getSolarPackages();
    assert(Array.isArray(packages), 'Directus CMS returns valid solar package array or resilient mirror');
  } catch {
    assert(false, 'Directus service threw unexpected exception');
  }

  // 2. ERPNext Customer Sync Test
  try {
    const res = await ERPNextService.syncCustomer({
      customer_name: 'Amara Jobe',
      customer_type: 'Individual',
      customer_group: 'Institutional Members',
      territory: 'The Gambia',
      email_id: 'amara.jobe@gtu.gm'
    });
    assert(res !== null && typeof res === 'object', 'ERPNext customer sync handles REST transaction');
  } catch {
    assert(false, 'ERPNext service threw unexpected exception');
  }

  // 3. Moodle LMS Technician Certifications Test
  try {
    const certs = await MoodleService.getTechnicianCertifications('tech@fortisinvicta.co.uk');
    assert(Array.isArray(certs) && certs.length > 0, 'Moodle LMS returns verified technician certifications');
    assert(certs[0].certificationStatus === 'certified', 'Technician has certified credential status');
  } catch {
    assert(false, 'Moodle service threw unexpected exception');
  }

  // 4. ThingsBoard IoT Live Inverter Telemetry Test
  try {
    const telemetry = await ThingsBoardService.getLiveTelemetry('solar-inv-001');
    assert(telemetry.pvPowerWatts > 0, 'ThingsBoard telemetry returns positive PV generation wattage');
    assert(telemetry.batterySocPercent >= 0 && telemetry.batterySocPercent <= 100, 'ThingsBoard battery SoC is within 0-100% bounds');
  } catch {
    assert(false, 'ThingsBoard service threw unexpected exception');
  }

  // 5. Postal Transactional Email Test
  try {
    const emailRes = await PostalService.sendEmail({
      to: ['client@fortisinvicta.co.uk'],
      subject: 'Test Solar Quotation Notice',
      htmlBody: '<p>Test Quotation</p>'
    });
    assert(emailRes.success === true, 'Postal email service processes transactional delivery request');
  } catch {
    assert(false, 'Postal service threw unexpected exception');
  }

  // 6. OpenSearch Central Audit Indexing Test
  try {
    const indexed = await OpenSearchService.indexAuditEvent({
      id: `test-audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'SYSTEM_AUDIT_VERIFIED',
      category: 'AUDIT',
      severity: 'INFO',
      details: 'All 6 enterprise endpoints verified.'
    });
    assert(indexed === true, 'OpenSearch indexes audit event to cluster');
  } catch {
    assert(false, 'OpenSearch service threw unexpected exception');
  }

  console.log(`\nCorporate Ecosystem Tests Summary: ${passed} passed, ${failed} failed.\n`);
  if (failed > 0) process.exit(1);
}

runEcosystemTests();
