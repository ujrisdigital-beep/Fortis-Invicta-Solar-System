import { test, expect } from '@playwright/test';

test.describe('Fortis Invicta Real-World Onboarding & Verification Flow', () => {
  const APP_URL = process.env.APP_URL || 'http://localhost:5173';

  test.beforeEach(async ({ page }) => {
    await page.goto(APP_URL);
  });

  test('completes GTUCCU teacher institutional validation and Tier selection', async ({ page }) => {
    // 1. Initial Page Render & System Verification
    await expect(page).toHaveTitle(/Fortis Invicta|Google AI Studio App/i);

    // 2. Client Onboarding - Select Institutional Affiliate
    const affiliateSelect = page.locator('select[name="affiliateType"]');
    if (await affiliateSelect.isVisible()) {
      await affiliateSelect.selectOption('GTUCCU');
      await page.fill('input[name="memberId"]', 'GTUCCU-78492');
      await page.click('button:has-text("Verify Credentials")');
      
      // Check for live verification tag
      await expect(page.locator('.verification-badge')).toContainText('Verified');
    }

    // 3. Select Solar System Package Tier
    const tierCard = page.locator('data-testid=tier-2-hybrid');
    if (await tierCard.isVisible()) {
      await tierCard.click();
      await page.click('button:has-text("Proceed to Payment")');
    }

    // 4. EcobankPay Deposit Validation Simulation
    const depositAmount = page.locator('.deposit-amount');
    if (await depositAmount.isVisible()) {
      await expect(depositAmount).not.toContainText('0 GMD');
    }
  });
});
